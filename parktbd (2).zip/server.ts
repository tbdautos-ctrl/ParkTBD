import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true }));

// Initial Seed Data with Real Generated Imagery
const initialVehicles = [
  {
    id: 'veh-1',
    vin: 'WAUZZZGY4NA029481',
    registration: 'GH-892-XT',
    brand: 'Audi',
    model: 'RS3 Sportback',
    version: '2.5 TFSI 400 ch Quattro S tronic 7',
    year: 2023,
    firstRegistrationDate: '2023-04-18',
    mileage: 18450,
    fuel: 'Essence',
    gearbox: 'Automatique',
    powerDin: 400,
    powerFiscal: 29,
    co2: 206,
    critAir: 1,
    colorExterior: 'Gris Nardo métallisé',
    colorInterior: 'Cuir Nappa fin Noir avec surpiqûres Gris Express',
    doors: 5,
    seats: 5,
    businessType: 'achat_revente',
    status: 'en_stock',
    location: 'Showroom Principal - Place Prestige',
    costs: {
      purchasePrice: 62500,
      transport: 450,
      reconditioning: 780,
      detailing: 400,
      inspection: 90,
      adminFees: 150,
      warrantyCost: 890,
      customCosts: [{ label: 'Traitement céramique carrosserie', amount: 350 }]
    },
    sellingPrice: 72900,
    tvaRegime: 'marge',
    monthlyEstimate: 789,
    guarantee: 'Garantie 12 Mois Constructeur Audi Plus',
    keyOptions: [
      'Échappement Sport RS avec embouts noirs',
      'Toit ouvrant panoramique électrique',
      'Affichage tête haute (HUD)',
      'Système audio Bang & Olufsen 3D Sound',
      'Jantes alliage 19" style rotor noir brillant',
      'Phares Matrix LED teintés dynamiques'
    ],
    detailedEquipment: [
      {
        category: 'Performance & Châssis',
        items: ['Quattro avec répartiteur de couple RS Torque Splitter', 'Suspension Sport RS réglable', 'Modes de conduite RS Individual']
      },
      {
        category: 'Confort & Infodivertissement',
        items: ['Virtual Cockpit Plus 12,3"', 'MMI Navigation Plus avec écran tactile 10,1"', 'Apple CarPlay & Android Auto sans fil', 'Chargeur smartphone à induction']
      },
      {
        category: 'Sécurité & Aides à la conduite',
        items: ['Caméra de recul haute définition avec radars 360°', 'Régulateur adaptatif avec Stop&Go', 'Alerte franchissement de ligne']
      }
    ],
    history: {
      origin: 'Origine France - 1ère main concessionnaire',
      firstOwner: true,
      serviceBookComplete: true,
      lastServiceDate: '2024-03-12',
      lastServiceKm: 15200
    },
    documents: {
      carteGrise: 'complet',
      certificatCession: 'complet',
      certificatNonGage: 'complet',
      controleTechnique: 'non_requis',
      bonCommande: 'en_attente',
      factureAchat: 'complet',
      factureVente: 'en_attente',
      mandatVente: 'non_requis',
      doubleDesCles: true,
      carnetEntretien: true,
      notes: 'Dossier administratif 100% conforme. Carte grise garage enregistrée SIV.',
      files: [
        { id: 'f-1', name: 'Carte_Grise_GH892XT.pdf', type: 'application/pdf', uploadDate: '2024-09-10', size: '1.2 Mo' },
        { id: 'f-2', name: 'Certificat_Non_Gage_Valide.pdf', type: 'application/pdf', uploadDate: '2024-10-01', size: '420 Ko' },
        { id: 'f-3', name: 'Historique_Entretien_Audi.pdf', type: 'application/pdf', uploadDate: '2024-09-12', size: '2.8 Mo' }
      ]
    },
    images: ['/src/assets/images/car_audi_rs3_sportback_1791554397291.jpg'],
    entryDate: '2024-09-08',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'veh-2',
    vin: 'WP1ZZZ95ZNLB12894',
    registration: 'FK-421-MP',
    brand: 'Porsche',
    model: 'Macan',
    version: 'GTS 2.9 V6 Biturbo 440 ch PDK',
    year: 2022,
    firstRegistrationDate: '2022-09-15',
    mileage: 34100,
    fuel: 'Essence',
    gearbox: 'Automatique',
    powerDin: 440,
    powerFiscal: 34,
    co2: 254,
    critAir: 1,
    colorExterior: 'Noir Intense métallisé',
    colorInterior: 'Pack cuir GTS Noir avec surpiqûres Craie',
    doors: 5,
    seats: 5,
    businessType: 'depot_vente',
    sellerDesiredPrice: 79000,
    brokerageFee: 6205, // Marge nette = 87900 (vente) - 79000 (net vendeur) - 2695 (frais engagés garage)
    status: 'en_stock',
    location: 'Showroom Principal - Entrée',
    costs: {
      purchasePrice: 79000, // Montant net souhaité par le client vendeur
      transport: 0,
      reconditioning: 650,
      detailing: 550,
      inspection: 95,
      adminFees: 200,
      warrantyCost: 1200,
      customCosts: []
    },
    sellingPrice: 87900,
    tvaRegime: 'marge',
    monthlyEstimate: 940,
    guarantee: 'Garantie 12 Mois Porsche Approved / Opteven Élite',
    keyOptions: [
      'Pack Sport Chrono avec sélecteur de mode',
      'Suspension pneumatique PASM adaptative',
      'Toit panoramique ouvrant en verre',
      'Sièges Sport adaptatifs 18 positions à mémoire',
      'Système Hi-Fi Bose Surround Sound',
      'Caméras surround 360° avec ParkAssist'
    ],
    detailedEquipment: [
      {
        category: 'Performance',
        items: ['Échappement sport Porsche à clapets actifs', 'Freins PSCB avec étriers rouges', 'Boîte PDK 7 rapports double embrayage']
      },
      {
        category: 'Équipements de Luxe',
        items: ['Volant Sport GT multifonctions en Alcantara chauffant', 'Climatisation automatique 3 zones', 'Vitrage arrière teinté athermique']
      }
    ],
    history: {
      origin: 'Origine France - Centre Porsche Nantes',
      firstOwner: false,
      serviceBookComplete: true,
      lastServiceDate: '2024-05-20',
      lastServiceKm: 31000
    },
    documents: {
      carteGrise: 'complet',
      certificatCession: 'en_attente',
      certificatNonGage: 'complet',
      controleTechnique: 'complet',
      bonCommande: 'en_attente',
      factureAchat: 'non_requis',
      factureVente: 'en_attente',
      mandatVente: 'complet',
      doubleDesCles: true,
      carnetEntretien: true,
      notes: 'Mandat de vente exclusif signé jusqu au 15/12/2026. Contrôle technique vierge du 02/10/2026.',
      files: [
        { id: 'f-4', name: 'Mandat_Depot_Vente_Exclusif.pdf', type: 'application/pdf', uploadDate: '2024-09-18', size: '1.5 Mo' },
        { id: 'f-5', name: 'Controle_Technique_OK.pdf', type: 'application/pdf', uploadDate: '2024-10-02', size: '920 Ko' }
      ]
    },
    images: ['/src/assets/images/car_porsche_macan_gts_1791554422386.jpg'],
    mediaItems: [
      { id: 'med-1', type: 'photo', url: '/src/assets/images/car_porsche_macan_gts_1791554422386.jpg', title: 'Vue de 3/4 avant gauche extérieure', createdAt: '2024-09-18T10:00:00Z' }
    ],
    documentFiles: [
      { id: 'doc-1', name: 'Mandat_Depot_Vente_Exclusif.pdf', type: 'application/pdf', category: 'mandat', url: '#', uploadDate: '2024-09-18', size: '1.5 Mo', notes: 'Mandat exclusif signé avec M. De Broglie à 79 000 € net vendeur' },
      { id: 'doc-2', name: 'Certificat_Situation_Administrative_Non_Gage.pdf', type: 'application/pdf', category: 'non_gage', url: '#', uploadDate: '2024-10-02', size: '380 Ko', notes: 'Vierge de tout gage' },
      { id: 'doc-3', name: 'Controle_Technique_OK.pdf', type: 'application/pdf', category: 'ct', url: '#', uploadDate: '2024-10-02', size: '920 Ko', notes: 'Zéro défaut soumis à contre-visite' }
    ],
    damages: [
      { id: 'dmg-1', title: 'Léger frottement superficiel vernis pare-chocs ARG', location: 'Pare-chocs arrière gauche', severity: 'mineur', estimatedRepairCost: 150, repaired: false, notes: 'Non perforant, polissage prévu ou vendu en l état avec accord client', createdAt: '2024-09-18T11:00:00Z' },
      { id: 'dmg-2', title: 'Bordure jante avant droite légèrement râpée trottoir', location: 'Jante AVD 21"', severity: 'mineur', estimatedRepairCost: 200, repaired: true, notes: 'Remise à neuf par tournage carrossier effectuée', createdAt: '2024-09-18T11:15:00Z' }
    ],
    entryDate: '2024-09-18',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'veh-3',
    vin: 'VF3MCYHZRMS091234',
    registration: 'GL-194-BN',
    brand: 'Peugeot',
    model: '3008',
    version: 'II Phase 2 1.5 BlueHDi 130 ch EAT8 GT',
    year: 2022,
    firstRegistrationDate: '2022-03-24',
    mileage: 48900,
    fuel: 'Diesel',
    gearbox: 'Automatique',
    powerDin: 130,
    powerFiscal: 7,
    co2: 136,
    critAir: 2,
    colorExterior: 'Blanc Nacré métallisé',
    colorInterior: 'Sellerie Alcantara / TEP Mistral avec surpiqûres Aikinite',
    doors: 5,
    seats: 5,
    businessType: 'achat_revente',
    status: 'en_stock',
    location: 'Parc Extérieur - Place 8',
    costs: {
      purchasePrice: 20400,
      transport: 300,
      reconditioning: 520,
      detailing: 250,
      inspection: 85,
      adminFees: 120,
      warrantyCost: 450,
      customCosts: [{ label: 'Changement 2 pneumatiques avant Michelin', amount: 280 }]
    },
    sellingPrice: 24900,
    tvaRegime: 'marge',
    monthlyEstimate: 299,
    guarantee: 'Garantie 12 Mois Pièces et Main d’œuvre Europe',
    keyOptions: [
      'Toit ouvrant panoramique électrique avec vélum',
      'Pack Drive Assist Plus (Conduite semi-autonome niveau 2)',
      'Hayon motorisé mains libres',
      'Projecteurs Peugeot Full LED Technology',
      'Caméra de recul VisioPark 360°',
      'Accès et démarrage mains libres Proximity'
    ],
    detailedEquipment: [
      {
        category: 'Poste de conduite',
        items: ['Peugeot i-Cockpit avec combiné tête haute numérique 12,3"', 'Écran tactile HD capacitif 10"', 'Navigation GPS 3D connectée']
      },
      {
        category: 'Confort',
        items: ['Sièges avant chauffants', 'Éclairage d’ambiance LED bleu', 'Rétroviseurs rabattables électriquement avec éclairage d accueil']
      }
    ],
    history: {
      origin: 'Origine France - Retour de leasing professionnel',
      firstOwner: true,
      serviceBookComplete: true,
      lastServiceDate: '2024-06-15',
      lastServiceKm: 45000
    },
    documents: {
      carteGrise: 'complet',
      certificatCession: 'complet',
      certificatNonGage: 'complet',
      controleTechnique: 'complet',
      bonCommande: 'en_attente',
      factureAchat: 'complet',
      factureVente: 'en_attente',
      mandatVente: 'non_requis',
      doubleDesCles: true,
      carnetEntretien: true,
      notes: 'Révision complète effectuée avant mise en parc. Rien à prévoir.',
      files: [
        { id: 'f-6', name: 'Facture_Revision_Constructeur.pdf', type: 'application/pdf', uploadDate: '2024-09-01', size: '850 Ko' }
      ]
    },
    images: ['/src/assets/images/car_peugeot_3008_gt_1791554434791.jpg'],
    entryDate: '2024-09-05',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'veh-4',
    vin: 'W1K1770511J849201',
    registration: 'FS-603-KL',
    brand: 'Mercedes-Benz',
    model: 'Classe A',
    version: 'A 35 AMG 4MATIC 306 ch Speedshift 7G-DCT',
    year: 2021,
    firstRegistrationDate: '2021-11-10',
    mileage: 41200,
    fuel: 'Essence',
    gearbox: 'Automatique',
    powerDin: 306,
    powerFiscal: 20,
    co2: 188,
    critAir: 1,
    colorExterior: 'Gris Montagne mat designo',
    colorInterior: 'Cuir bicolore Noir & Rouge classique AMG',
    doors: 5,
    seats: 5,
    businessType: 'achat_revente',
    status: 'reserve',
    location: 'Atelier Préparation - Finition livraison',
    costs: {
      purchasePrice: 38500,
      transport: 400,
      reconditioning: 850,
      detailing: 450,
      inspection: 90,
      adminFees: 150,
      warrantyCost: 750,
      customCosts: []
    },
    sellingPrice: 45900,
    soldPrice: 45500,
    buyerName: 'Alexandre Renard',
    buyerPhone: '06 18 42 90 12',
    tvaRegime: 'marge',
    monthlyEstimate: 519,
    guarantee: 'Garantie 12 Mois Mercedes-Benz Certified',
    keyOptions: [
      'Pack Aérodynamique AMG avec aileron arrière fixe',
      'Pack Sport Black AMG',
      'Système audio Burmester Surround Sound',
      'Toit ouvrant panoramique',
      'Affichage tête haute HUD',
      'Éclairage d’ambiance 64 couleurs'
    ],
    detailedEquipment: [
      {
        category: 'Châssis & Moteur',
        items: ['Transmission intégrale AMG Performance 4MATIC', 'Échappement sport commutable AMG', 'AMG DYNAMIC SELECT']
      },
      {
        category: 'Technologie MBUX',
        items: ['Double écran widescreen 10,25"', 'Réalité augmentée pour la navigation MBUX', 'Commande vocale "Hey Mercedes"']
      }
    ],
    history: {
      origin: 'Origine France',
      firstOwner: false,
      serviceBookComplete: true,
      lastServiceDate: '2024-04-05',
      lastServiceKm: 38900
    },
    documents: {
      carteGrise: 'complet',
      certificatCession: 'complet',
      certificatNonGage: 'complet',
      controleTechnique: 'complet',
      bonCommande: 'complet',
      factureAchat: 'complet',
      factureVente: 'en_attente',
      mandatVente: 'non_requis',
      doubleDesCles: true,
      carnetEntretien: true,
      notes: 'Acompte de 2 500 € reçu. Livraison programmée ce samedi.',
      files: []
    },
    images: ['/src/assets/images/car_mercedes_a35_amg_1791554446804.jpg'],
    entryDate: '2024-08-20',
    saleDate: '2024-10-07',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

const initialAppointments = [
  {
    id: 'apt-1',
    vehicleId: 'veh-1',
    vehicleName: 'Audi RS3 Sportback 400 ch',
    clientName: 'Marc Delorme',
    clientPhone: '06 45 88 12 30',
    clientEmail: 'marc.delorme75@gmail.com',
    type: 'essai_routier',
    date: new Date(Date.now() + 2 * 3600 * 1000).toISOString(), // Dans 2h
    durationMinutes: 45,
    status: 'confirme',
    driverLicenseChecked: true,
    depositLeft: true,
    notes: 'Client très motivé, possède actuellement une S3 2018. Permis B vérifié et caution empreinte CB 1500€ prise.',
    assignedTo: 'Daniel Balogun',
    createdAt: new Date().toISOString()
  },
  {
    id: 'apt-2',
    vehicleId: 'veh-2',
    vehicleName: 'Porsche Macan GTS 440 ch',
    clientName: 'Dr. Sophie Laurent',
    clientPhone: '06 12 99 44 21',
    clientEmail: 's.laurent@cabinet-medical.fr',
    type: 'visite_commerciale',
    date: new Date(Date.now() + 26 * 3600 * 1000).toISOString(), // Demain
    durationMinutes: 60,
    status: 'confirme',
    driverLicenseChecked: true,
    depositLeft: false,
    notes: 'Souhaite une présentation complète de l historique Porsche et simulation de reprise sur BMW X3.',
    assignedTo: 'Daniel Balogun',
    createdAt: new Date().toISOString()
  },
  {
    id: 'apt-3',
    vehicleId: 'veh-4',
    vehicleName: 'Mercedes-Benz A 35 AMG',
    clientName: 'Alexandre Renard',
    clientPhone: '06 18 42 90 12',
    clientEmail: 'alex.renard@outlook.fr',
    type: 'livraison',
    date: new Date(Date.now() + 48 * 3600 * 1000).toISOString(), // Après-demain
    durationMinutes: 45,
    status: 'confirme',
    driverLicenseChecked: true,
    depositLeft: true,
    notes: 'Livraison finale du véhicule avec explication des commandes et signature du certificat de cession.',
    assignedTo: 'Daniel Balogun',
    createdAt: new Date().toISOString()
  }
];

const initialUsers = [
  {
    id: 'usr-1',
    name: 'Daniel Balogun',
    email: 'danielbalogun01@gmail.com',
    role: 'admin',
    phone: '06 10 20 30 40',
    active: true,
    createdAt: '2024-01-01T08:00:00Z'
  },
  {
    id: 'usr-2',
    name: 'Julien Mercier',
    email: 'j.mercier@parktbd.fr',
    role: 'commercial',
    phone: '06 55 44 33 22',
    active: true,
    createdAt: '2024-02-15T09:30:00Z'
  },
  {
    id: 'usr-3',
    name: 'Claire Fontaine',
    email: 'c.fontaine@parktbd.fr',
    role: 'gestionnaire_parc',
    phone: '06 77 88 99 00',
    active: true,
    createdAt: '2024-03-01T10:00:00Z'
  }
];

const initialSentEmails = [
  {
    id: 'em-1',
    from: 'tbdautos@gmail.com',
    fromName: 'TBD AUTOS',
    to: 'comptabilite@cabinet-expert.fr',
    recipientName: 'Cabinet Comptable TBD AUTOS',
    vehicleId: 'veh-1',
    vehicleName: 'Audi RS3 Sportback (GH-892-XT)',
    docType: 'facture_achat',
    subject: '[TBD AUTOS] Facture d\'achat acquittée & Bordereau d\'acquisition - Audi RS3 Sportback (GH-892-XT)',
    message: `Bonjour,\n\nVeuillez trouver ci-joint la facture d'achat acquittée ainsi que le dossier d'acquisition pour le véhicule entré sur le parc TBD AUTOS :\n\n• Véhicule : Audi RS3 Sportback 2.5 TFSI 400 ch\n• Immatriculation : GH-892-XT\n• VIN : WAUZZZGY4NA029481\n• Montant d'achat réglé : 62 500 €\n• Régime fiscal : TVA sur la marge (Art. 297 A du CGI)\n\nDocuments joints : Facture d'achat acquittée, certificat de cession et rapport de conformité SIV.\nCe document atteste du règlement intégral et du transfert de propriété au bénéfice de TBD AUTOS.\n\nRestant à votre entière disposition pour tout complément comptable ou administratif.\n\nBien cordialement,\nL'équipe TBD AUTOS\nEmail : tbdautos@gmail.com\nTéléphone : 06 12 34 56 78`,
    attachments: [
      { name: 'Facture_Achat_Audi_RS3_GH892XT.pdf', size: '1.4 Mo' },
      { name: 'Certificat_Cession_Signe.pdf', size: '480 Ko' }
    ],
    sentAt: '2024-10-02T14:30:00Z',
    status: 'envoye'
  },
  {
    id: 'em-2',
    from: 'tbdautos@gmail.com',
    fromName: 'TBD AUTOS',
    to: 'julien.martinez@email.fr',
    recipientName: 'M. Julien Martinez',
    vehicleId: 'veh-2',
    vehicleName: 'Porsche Macan GTS (FK-421-MP)',
    docType: 'mandat_depot_vente',
    subject: '[TBD AUTOS] Mandat de dépôt-vente & Engagement de commercialisation - Porsche Macan GTS',
    message: `Bonjour M. Martinez,\n\nDans le cadre de l'intermédiation de vente confiée à TBD AUTOS, vous trouverez ci-joint votre mandat de dépôt-vente officiel :\n\n• Véhicule confié : Porsche Macan GTS (FK-421-MP)\n• Montant net vendeur garanti : 79 000 €\n• Prix public affiché sur parc : 87 900 €\n• Commission d'intermédiation TBD AUTOS : 6 205 €\n\nEngagements de TBD AUTOS :\n- Contrôle complet et préparation esthétique\n- Shooting photo studio HD et multidiffusion sur nos portails partenaires\n- Sécurisation du paiement et gestion de toutes les démarches SIV\n\nMerci de nous retourner votre mandat paraphé et signé.\n\nBien cordialement,\nTBD AUTOS\nEmail : tbdautos@gmail.com`,
    attachments: [
      { name: 'Mandat_Depot_Vente_TBD_AUTOS_Macan.pdf', size: '650 Ko' },
      { name: 'Fiche_Etat_Lieux_Vehicule.pdf', size: '1.1 Mo' }
    ],
    sentAt: '2024-10-05T09:15:00Z',
    status: 'envoye'
  }
];

const initialSellers = [
  {
    id: 'sel-1',
    type: 'particulier',
    name: 'M. Julien Martinez',
    phone: '06 45 12 78 90',
    email: 'julien.martinez@email.fr',
    address: '14 Rue des Acacias',
    postalCode: '69003',
    city: 'Lyon',
    idDocumentType: 'cni',
    idDocumentNumber: '210569103452',
    idDocumentFile: {
      name: 'CNI_Julien_Martinez_RectoVerso.pdf',
      type: 'application/pdf',
      uploadDate: '2024-09-28',
      size: '1.2 Mo'
    },
    rib: 'FR76 3000 4012 3456 7890 1234 567',
    notes: 'Client particulier fidèle. Propriétaire soigneux de la Porsche Macan GTS.',
    createdAt: '2024-09-28T10:00:00Z'
  },
  {
    id: 'sel-2',
    type: 'professionnel',
    name: 'SARL Alpha Invest Auto',
    companyName: 'SARL Alpha Invest Auto',
    siren: '849 321 456',
    siret: '849 321 456 00018',
    managerName: 'Pierre Dupré',
    phone: '01 42 68 90 11',
    email: 'direction@alphainvest.fr',
    address: '28 Boulevard Haussmann',
    postalCode: '75008',
    city: 'Paris',
    idDocumentType: 'kbis',
    idDocumentNumber: 'RCS Paris 849 321 456',
    kbisFile: {
      name: 'Extrait_KBIS_SARL_Alpha_Invest.pdf',
      type: 'application/pdf',
      uploadDate: '2024-10-01',
      size: '850 Ko'
    },
    idDocumentFile: {
      name: 'Passeport_Gerant_Pierre_Dupre.pdf',
      type: 'application/pdf',
      uploadDate: '2024-10-01',
      size: '980 Ko'
    },
    rib: 'FR76 1005 7000 9876 5432 1098 765',
    notes: 'Société de gestion de flotte patrimoniale. Plusieurs véhicules haut de gamme en dépôt régulier.',
    createdAt: '2024-10-01T14:20:00Z'
  }
];

// Persistent File Storage in ./data/database.json
const dataDir = path.join(__dirname, 'data');
const dbFile = path.join(dataDir, 'database.json');

interface AppDatabase {
  vehicles: any[];
  appointments: any[];
  users: any[];
  sentEmails: any[];
  sellers: any[];
}

function loadDatabase(): AppDatabase {
  try {
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    if (fs.existsSync(dbFile)) {
      const content = fs.readFileSync(dbFile, 'utf-8');
      const parsed = JSON.parse(content);
      if (!parsed.sentEmails) {
        parsed.sentEmails = initialSentEmails;
      }
      if (!parsed.sellers) {
        parsed.sellers = initialSellers;
      }
      return parsed;
    }
  } catch (err) {
    console.error('Error reading database file:', err);
  }

  // Fallback to initial seeds
  const initialDb: AppDatabase = {
    vehicles: initialVehicles,
    appointments: initialAppointments,
    users: initialUsers,
    sentEmails: initialSentEmails,
    sellers: initialSellers
  };
  saveDatabase(initialDb);
  return initialDb;
}

function saveDatabase(db: AppDatabase) {
  try {
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(dbFile, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving database file:', err);
  }
}

let db = loadDatabase();

// Real-Time Server-Sent Events (SSE) connections
const sseClients: Response[] = [];

function broadcastSse(eventType: string, payload: any) {
  const message = `event: ${eventType}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (let i = sseClients.length - 1; i >= 0; i--) {
    try {
      sseClients[i].write(message);
    } catch {
      sseClients.splice(i, 1);
    }
  }
}

// SSE endpoint for live multi-device syncing
app.get('/api/sync/events', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  res.write(`event: connected\ndata: ${JSON.stringify({ timestamp: Date.now() })}\n\n`);
  sseClients.push(res);

  req.on('close', () => {
    const idx = sseClients.indexOf(res);
    if (idx !== -1) {
      sseClients.splice(idx, 1);
    }
  });
});

// GET all vehicles
app.get('/api/cars', (req: Request, res: Response) => {
  res.json(db.vehicles);
});

// POST add vehicle
app.post('/api/cars', (req: Request, res: Response) => {
  const newCar = {
    ...req.body,
    id: req.body.id || `veh-${Date.now()}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  db.vehicles.unshift(newCar);
  saveDatabase(db);
  broadcastSse('vehicle_created', newCar);
  res.status(201).json(newCar);
});

// PUT update vehicle
app.put('/api/cars/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  const idx = db.vehicles.findIndex(v => v.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Véhicule non trouvé' });
    return;
  }
  const updatedCar = {
    ...db.vehicles[idx],
    ...req.body,
    updatedAt: new Date().toISOString()
  };
  db.vehicles[idx] = updatedCar;
  saveDatabase(db);
  broadcastSse('vehicle_updated', updatedCar);
  res.json(updatedCar);
});

// DELETE vehicle
app.delete('/api/cars/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  const idx = db.vehicles.findIndex(v => v.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Véhicule non trouvé' });
    return;
  }
  const deleted = db.vehicles.splice(idx, 1)[0];
  saveDatabase(db);
  broadcastSse('vehicle_deleted', { id });
  res.json({ success: true, deleted });
});

// GET appointments
app.get('/api/appointments', (req: Request, res: Response) => {
  res.json(db.appointments);
});

// POST appointment
app.post('/api/appointments', (req: Request, res: Response) => {
  const newApt = {
    ...req.body,
    id: req.body.id || `apt-${Date.now()}`,
    createdAt: new Date().toISOString()
  };
  db.appointments.unshift(newApt);
  saveDatabase(db);
  broadcastSse('appointment_created', newApt);
  res.status(201).json(newApt);
});

// PUT appointment
app.put('/api/appointments/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  const idx = db.appointments.findIndex(a => a.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Rendez-vous non trouvé' });
    return;
  }
  const updatedApt = {
    ...db.appointments[idx],
    ...req.body
  };
  db.appointments[idx] = updatedApt;
  saveDatabase(db);
  broadcastSse('appointment_updated', updatedApt);
  res.json(updatedApt);
});

// DELETE appointment
app.delete('/api/appointments/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  const idx = db.appointments.findIndex(a => a.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Rendez-vous non trouvé' });
    return;
  }
  const deleted = db.appointments.splice(idx, 1)[0];
  saveDatabase(db);
  broadcastSse('appointment_deleted', { id });
  res.json({ success: true, deleted });
});

// GET users
app.get('/api/users', (req: Request, res: Response) => {
  res.json(db.users);
});

// POST user
app.post('/api/users', (req: Request, res: Response) => {
  const newUser = {
    ...req.body,
    id: req.body.id || `usr-${Date.now()}`,
    createdAt: new Date().toISOString()
  };
  db.users.push(newUser);
  saveDatabase(db);
  broadcastSse('user_created', newUser);
  res.status(201).json(newUser);
});

// PUT user
app.put('/api/users/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  const idx = db.users.findIndex(u => u.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Utilisateur non trouvé' });
    return;
  }
  const updatedUser = {
    ...db.users[idx],
    ...req.body
  };
  db.users[idx] = updatedUser;
  saveDatabase(db);
  broadcastSse('user_updated', updatedUser);
  res.json(updatedUser);
});

// DELETE user
app.delete('/api/users/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  const idx = db.users.findIndex(u => u.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Utilisateur non trouvé' });
    return;
  }
  const deleted = db.users.splice(idx, 1)[0];
  saveDatabase(db);
  broadcastSse('user_deleted', { id });
  res.json({ success: true, deleted });
});

// GET emails
app.get('/api/emails', (req: Request, res: Response) => {
  res.json(db.sentEmails || []);
});

// POST send / record email
app.post('/api/emails', (req: Request, res: Response) => {
  const newEmail = {
    ...req.body,
    id: req.body.id || `em-${Date.now()}`,
    from: 'tbdautos@gmail.com',
    fromName: 'TBD AUTOS',
    sentAt: req.body.sentAt || new Date().toISOString(),
    status: 'envoye'
  };
  db.sentEmails = db.sentEmails || [];
  db.sentEmails.unshift(newEmail);
  saveDatabase(db);
  broadcastSse('email_sent', newEmail);
  res.status(201).json(newEmail);
});

// DELETE email record
app.delete('/api/emails/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  db.sentEmails = db.sentEmails || [];
  const idx = db.sentEmails.findIndex(e => e.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Email non trouvé' });
    return;
  }
  const deleted = db.sentEmails.splice(idx, 1)[0];
  saveDatabase(db);
  broadcastSse('email_deleted', { id });
  res.json({ success: true, deleted });
});

// Sellers endpoints (Dépôt-vente)
app.get('/api/sellers', (req: Request, res: Response) => {
  res.json(db.sellers || []);
});

app.post('/api/sellers', (req: Request, res: Response) => {
  const newSeller = {
    ...req.body,
    id: req.body.id || `sel-${Date.now()}`,
    createdAt: new Date().toISOString()
  };
  db.sellers = db.sellers || [];
  db.sellers.unshift(newSeller);
  saveDatabase(db);
  broadcastSse('seller_created', newSeller);
  res.status(201).json(newSeller);
});

app.put('/api/sellers/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  db.sellers = db.sellers || [];
  const idx = db.sellers.findIndex(s => s.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Vendeur non trouvé' });
    return;
  }
  db.sellers[idx] = {
    ...db.sellers[idx],
    ...req.body,
    updatedAt: new Date().toISOString()
  };
  saveDatabase(db);
  broadcastSse('seller_updated', db.sellers[idx]);
  res.json(db.sellers[idx]);
});

app.delete('/api/sellers/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  db.sellers = db.sellers || [];
  const idx = db.sellers.findIndex(s => s.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Vendeur non trouvé' });
    return;
  }
  const deleted = db.sellers.splice(idx, 1)[0];
  saveDatabase(db);
  broadcastSse('seller_deleted', { id });
  res.json({ success: true, deleted });
});

// RESET demo data endpoint
app.post('/api/reset-demo', (req: Request, res: Response) => {
  db = {
    vehicles: initialVehicles,
    appointments: initialAppointments,
    users: initialUsers,
    sentEmails: initialSentEmails,
    sellers: initialSellers
  };
  saveDatabase(db);
  broadcastSse('database_reset', { timestamp: Date.now() });
  res.json({ success: true, message: 'Données de démonstration réinitialisées' });
});

// POST /api/generate-description (Gemini AI Ad Description Generator)
app.post('/api/generate-description', async (req: Request, res: Response) => {
  try {
    const { vehicle, platform, tone } = req.body;
    if (!vehicle) {
      res.status(400).json({ error: 'Véhicule manquant' });
      return;
    }

    const platformName = platform || 'Leboncoin';
    const styleTone = tone || 'Professionnel et vendeur';

    const prompt = `Tu es l'assistant commercial et marketing de mon garage automobile "TBD AUTOS". Ta mission est de rédiger des fiches d'annonces de vente de véhicules d'occasion optimisées pour la publication sur internet (Leboncoin, La Centrale, réseaux sociaux, site web).

### 1. RÈGLES COMMERCIALES & POLITIQUE DU GARAGE (OBLIGATOIRES)
- Transparence totale : Mets en avant les qualités du véhicule, mais indique clairement et sans détours les défauts esthétiques ou petits travaux restant à la charge de l'acquéreur (pare-brise, rayures, etc.).
- Structure des coûts & préparation : N'utilise jamais de termes effrayants ou d'emojis d'avertissement type ⚠️. Utilise des emojis accueillants (ex: ✨). Mentionne toujours que les frais de nettoyage et de préparation de base sont déjà INCLUS dans le prix de vente affiché.
- Packs de livraison en supplément (au choix du client) : Propose toujours systématiquement les deux formules optionnelles :
    • Pack 1 : Nettoyage professionnel complet + 20 litres de carburant (indiquer 150 €).
    • Pack 2 : Plein d'essence complet + prise en charge des démarches administratives + taxe de la carte grise (indiquer 250 € + Prix de la carte grise).
- Politique de négociation : Ajoute impérativement en remarque : "Aucune négociation par téléphone. Les échanges sur le prix se font uniquement sur place devant le véhicule."

### 2. STRUCTURE TYPE DE L'ANNONCE À GÉNÉRER
À partir des informations brutes ci-dessous, génère l'annonce en respectant scrupuleusement la structure Markdown suivante :

1. Entête du véhicule :
   • MARQUE / MODÈLE / FINITION / ANNÉE
   • MOTEUR / PUISSANCE (${vehicle.powerDin || '[À préciser]'} cv et ${vehicle.powerFiscal || '[À préciser]'} CV fiscaux) / ÉNERGIE / KILOMÉTRAGE / BOÎTE

2. Bloc Tarification & Packs :
   ✨ Frais de préparation & nettoyage inclus dans le prix de vente ✨
   Packs de livraison (en supplément, au choix) :
   • Pack 1 — 150 € : Nettoyage professionnel complet + 20 litres de carburant.
   • Pack 2 — 250 € + Prix carte grise : Plein d'essence complet + prise en charge intégrale des démarches administratives et immatriculation.
   (Note : Aucune négociation par téléphone. Les échanges sur le prix se font uniquement sur place devant le véhicule).

3. 🌟 Les + du véhicule (3 à 5 points forts majeurs : moteur, suivi, finition, consommation, entretien fait, etc.).
4. Garantie & Statut (Garantie incluse : ${vehicle.guarantee || 'Garantie 12 Mois'}, extension possible, statut : ${vehicle.businessType === 'depot_vente' ? 'Dépôt-vente certifié' : 'Véhicule en stock révisé'}).
5. État du véhicule & Entretien (Séparer clairement les réparations récentes/mécanique et les éventuels défauts à noter).
6. Options & Équipements (Liste à puces des équipements principaux selon la finition).
7. Modalités de la vente (Transparence, visites et essais sur rendez-vous chez TBD AUTOS - Courriel : tbdautos@gmail.com).

Données réelles du véhicule :
- Marque : ${vehicle.brand}
- Modèle : ${vehicle.model}
- Version : ${vehicle.version}
- Année : ${vehicle.year}
- Kilométrage : ${Number(vehicle.mileage || 0).toLocaleString('fr-FR')} km
- Carburant : ${vehicle.fuel}
- Boîte : ${vehicle.gearbox}
- Puissance : ${vehicle.powerDin} ch (${vehicle.powerFiscal} CV fiscaux)
- Teinte : ${vehicle.colorExterior} (Intérieur : ${vehicle.colorInterior})
- Prix affiché TTC : ${Number(vehicle.sellingPrice || 0).toLocaleString('fr-FR')} €
- Options connues : ${(vehicle.keyOptions || []).join(', ') || 'Finition soignée'}
- Défauts signalés : ${(vehicle.damages || []).map((d: any) => d.title).join(', ') || 'Aucun défaut majeur constaté, très bon état d\'usage'}
- Historique : ${vehicle.history?.origin || 'Origine France certifiée'}, carnet d'entretien disponible.
- Plateforme cible : ${platformName}`;

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      const ai = new GoogleGenAI();
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt
      });

      const generatedText = response.text || '';
      res.json({ text: generatedText, provider: 'gemini-3.8-flash' });
      return;
    }

    // High quality algorithmic fallback matching the exact requested prompt structure
    const fallbackText = `### 1. ${vehicle.brand.toUpperCase()} ${vehicle.model.toUpperCase()} ${vehicle.version} — ${vehicle.year}
• Motorisation : ${vehicle.powerDin} ch (${vehicle.powerFiscal} CV fiscaux) · ${vehicle.fuel}
• Kilométrage : ${Number(vehicle.mileage || 0).toLocaleString('fr-FR')} km d'origine certifié
• Transmission : Boîte ${vehicle.gearbox}

---

### 2. Tarification & Packs de livraison
**Prix de vente affiché : ${Number(vehicle.sellingPrice || 0).toLocaleString('fr-FR')} € TTC**
✨ Frais de préparation & nettoyage inclus dans le prix de vente ✨

Packs de livraison (en supplément, au choix) :
• **Pack 1 — 150 €** : Nettoyage professionnel complet + 20 litres de carburant.
• **Pack 2 — 250 € + Prix carte grise** : Plein d'essence complet + prise en charge des démarches administratives.
*(Note : Aucune négociation par téléphone. Les échanges sur le prix se font uniquement sur place devant le véhicule).*

---

### 3. 🌟 Les + du véhicule
• Historique limpide avec carnet d'entretien et double des clés
• Motorisation performante, fiable et économique
• Finition haut de gamme ${vehicle.version}
• Contrôle technique valide et révision effectuée avant livraison

---

### 4. Garantie & Statut
• ${vehicle.guarantee || 'Garantie 12 Mois incluse (extension possible de 4 à 36 mois)'}
• Statut : ${vehicle.businessType === 'depot_vente' ? 'Dépôt-vente rigoureusement sélectionné' : 'Véhicule en stock propre révisé'}

---

### 5. État du véhicule & Entretien
• **Mécanique & récents travaux** : Entretien à jour, pneumatiques et freinage contrôlés, zéro frais immédiat à prévoir.
• **Carrosserie & intérieur** : ${vehicle.damages?.length ? vehicle.damages.map((d: any) => d.title).join(', ') : 'Très bel état de présentation esthétique, traces d\'usage minimes conformes au kilométrage.'}

---

### 6. Options & Équipements
${(vehicle.keyOptions || []).map((opt: string) => `• ${opt}`).join('\n') || '• Équipement complet de série'}

---

### 7. Modalités de la vente
• Vente en toute transparence par **TBD AUTOS**
• Visites et essais routiers uniquement sur rendez-vous
• Contact : **tbdautos@gmail.com**`;

    res.json({ text: fallbackText, provider: 'template-tbd' });
  } catch (error: any) {
    console.error('Error generating AI description:', error);
    res.status(500).json({ error: error.message || 'Erreur lors de la génération' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ParkTBD Server] Running on http://localhost:${PORT} in ${isProduction ? 'production' : 'development'} mode`);
  });
}

startServer();
