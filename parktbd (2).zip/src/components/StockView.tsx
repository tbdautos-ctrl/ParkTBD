import React, { useState } from 'react';
import { Vehicle, VehicleStatus, BusinessType, FuelType, EmailDocType } from '../types';
import { 
  Search, 
  Filter, 
  Printer, 
  FileText, 
  Sparkles, 
  Edit3, 
  Trash2, 
  LayoutGrid, 
  Table as TableIcon, 
  Plus, 
  Calendar, 
  Fuel, 
  Gauge, 
  DollarSign, 
  Eye, 
  FileCheck,
  Car,
  Camera,
  AlertTriangle,
  Mail,
  BookmarkCheck,
  FileSignature
} from 'lucide-react';

interface StockViewProps {
  vehicles: Vehicle[];
  onOpenVehicleModal: (vehicle?: Vehicle) => void;
  onOpenVehicleShow: (vehicle: Vehicle) => void;
  onOpenVehicleDetail?: (vehicle: Vehicle) => void;
  onOpenReservation: (vehicle: Vehicle) => void;
  onOpenSalesMandate?: (vehicle: Vehicle) => void;
  onOpenWindowSticker: (vehicle: Vehicle) => void;
  onOpenBrochure: (vehicle: Vehicle) => void;
  onOpenAiAd: (vehicle: Vehicle) => void;
  onOpenMediaDamages: (vehicle: Vehicle) => void;
  onOpenSendEmail?: (vehicle: Vehicle, docType?: EmailDocType) => void;
  onDeleteVehicle: (id: string) => void;
}

export const StockView: React.FC<StockViewProps> = ({
  vehicles,
  onOpenVehicleModal,
  onOpenVehicleShow,
  onOpenVehicleDetail,
  onOpenReservation,
  onOpenSalesMandate,
  onOpenWindowSticker,
  onOpenBrochure,
  onOpenAiAd,
  onOpenMediaDamages,
  onOpenSendEmail,
  onDeleteVehicle
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [fuelFilter, setFuelFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Filter vehicles
  const filteredVehicles = vehicles.filter((car) => {
    const matchesSearch = 
      car.brand.toLowerCase().includes(search.toLowerCase()) ||
      car.model.toLowerCase().includes(search.toLowerCase()) ||
      car.version.toLowerCase().includes(search.toLowerCase()) ||
      car.registration.toLowerCase().includes(search.toLowerCase()) ||
      car.vin.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = statusFilter === 'all' || car.status === statusFilter;
    const matchesType = typeFilter === 'all' || car.businessType === typeFilter;
    const matchesFuel = fuelFilter === 'all' || car.fuel === fuelFilter;

    return matchesSearch && matchesStatus && matchesType && matchesFuel;
  });

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Header & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Gestion du Stock Automobile
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {filteredVehicles.length} véhicule(s) affiché(s) sur {vehicles.length} au total
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Switch Grid / Table */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${
                viewMode === 'grid' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="Vue Grille Visuelle"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${
                viewMode === 'table' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="Vue Tableau Synthétique"
            >
              <TableIcon className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => onOpenVehicleModal()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Ajouter Véhicule</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
        
        {/* Search */}
        <div className="lg:col-span-4 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher marque, modèle, immat, VIN..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>

        {/* Status */}
        <div className="lg:col-span-3">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">Tous les Statuts</option>
            <option value="en_stock">En Stock (Disponible)</option>
            <option value="en_preparation">En Préparation</option>
            <option value="en_arrivage">En Arrivage</option>
            <option value="reserve">Réservé</option>
            <option value="vendu">Vendu</option>
          </select>
        </div>

        {/* Business Type */}
        <div className="lg:col-span-3">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">Toutes Activités</option>
            <option value="achat_revente">Achat - Revente (Propre)</option>
            <option value="depot_vente">Dépôt - Vente (Mandat)</option>
          </select>
        </div>

        {/* Fuel */}
        <div className="lg:col-span-2">
          <select
            value={fuelFilter}
            onChange={(e) => setFuelFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">Tous Carburants</option>
            <option value="Essence">Essence</option>
            <option value="Diesel">Diesel</option>
            <option value="Hybride">Hybride</option>
            <option value="Électrique">Électrique</option>
          </select>
        </div>

      </div>

      {/* Empty State */}
      {filteredVehicles.length === 0 ? (
        <div className="p-12 text-center bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
          <Car className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">Aucun véhicule trouvé</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Aucun résultat ne correspond à vos filtres. Essayez de réinitialiser la recherche ou ajoutez un nouveau véhicule.
          </p>
          <button
            onClick={() => { setSearch(''); setStatusFilter('all'); setTypeFilter('all'); setFuelFilter('all'); }}
            className="px-4 py-2 text-xs font-semibold text-amber-400 bg-slate-800 rounded-lg hover:bg-slate-700 cursor-pointer"
          >
            Réinitialiser les filtres
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        
        /* GRID VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVehicles.map((car) => {
            const photo = car.images?.[0] || car.mediaItems?.find(m => m.type === 'photo')?.url || null;
            const totalCost = car.costs.purchasePrice + car.costs.transport + car.costs.reconditioning + car.costs.detailing + car.costs.inspection + car.costs.adminFees + car.costs.warrantyCost;
            const margin = car.sellingPrice - totalCost;
            const marginPct = totalCost > 0 ? (margin / totalCost) * 100 : 0;

            return (
              <div
                key={car.id}
                className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden flex flex-col justify-between hover:border-slate-700 transition-all shadow-md group"
              >
                <div>
                  {/* Photo with Overlay Badges - Click to open Vehicle Detail Sheet */}
                  <div 
                    onClick={() => (onOpenVehicleDetail ? onOpenVehicleDetail(car) : onOpenVehicleShow(car))}
                    className="relative aspect-16/9 overflow-hidden bg-slate-950 flex items-center justify-center cursor-pointer group/photo"
                    title="Cliquer pour ouvrir la Fiche Véhicule détaillée de l'état de la vente"
                  >
                    {photo ? (
                      <img
                        src={photo}
                        alt={`${car.brand} ${car.model}`}
                        className="w-full h-full object-cover group-hover/photo:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-600 bg-slate-950/80">
                        <Car className="w-10 h-10 mb-1 text-slate-700" />
                        <span className="text-[11px] font-medium text-slate-500">Aucune photo enregistrée</span>
                      </div>
                    )}

                    {/* Show Mode Badge Overlay */}
                    <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover/photo:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                      <span className="bg-slate-950/90 backdrop-blur-md text-amber-400 text-xs font-bold px-3 py-1.5 rounded-full border border-amber-500/40 shadow-xl flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5" /> Fiche Véhicule & Vente
                      </span>
                    </div>
                    
                    <div className="absolute top-3 left-3 flex items-center gap-2 pointer-events-none">
                      <span className="bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded text-xs font-bold text-white font-mono">
                        {car.registration}
                      </span>
                      <span className="bg-slate-900/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-semibold text-slate-300 uppercase">
                        {car.businessType === 'depot_vente' ? 'Dépôt-Vente' : 'Achat-Revente'}
                      </span>
                    </div>

                    <div className="absolute top-3 right-3 pointer-events-none">
                      <span className={`px-2.5 py-1 rounded text-xs font-bold uppercase ${
                        car.status === 'en_stock' ? 'bg-emerald-500 text-slate-950' :
                        car.status === 'reserve' ? 'bg-blue-500 text-white' :
                        car.status === 'en_preparation' ? 'bg-amber-400 text-slate-950' :
                        car.status === 'vendu' ? 'bg-purple-600 text-white' : 'bg-slate-700 text-white'
                      }`}>
                        {car.status === 'en_stock' ? 'En stock' :
                         car.status === 'reserve' ? 'Réservé' :
                         car.status === 'en_preparation' ? 'En préparation' :
                         car.status === 'vendu' ? 'Vendu' : car.status}
                      </span>
                    </div>
                  </div>

                  {/* Body Specs */}
                  <div className="p-5 space-y-3">
                    <div>
                      <h3 
                        onClick={() => (onOpenVehicleDetail ? onOpenVehicleDetail(car) : onOpenVehicleShow(car))}
                        className="text-lg font-bold text-white hover:text-amber-400 transition-colors cursor-pointer flex items-center justify-between"
                        title="Ouvrir la fiche détaillée de l'état de la vente"
                      >
                        <span>{car.brand} {car.model}</span>
                        <FileText className="w-4 h-4 text-slate-500 hover:text-amber-400" />
                      </h3>
                      <p className="text-xs text-slate-400 font-medium truncate">
                        {car.version}
                      </p>
                    </div>

                    {/* Specs Pills Unboxed */}
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span>{car.year}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{Number(car.mileage).toLocaleString('fr-FR')} km</span>
                      <span aria-hidden="true">·</span>
                      <span>{car.fuel}</span>
                      <span aria-hidden="true">·</span>
                      <span>{car.powerDin} ch</span>
                    </div>

                    {/* Key Options (top 3) */}
                    <div className="space-y-1 pt-1">
                      {(car.keyOptions || []).slice(0, 3).map((opt, i) => (
                        <div key={i} className="text-[11px] text-slate-300 flex items-center gap-1.5 truncate">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 flex-shrink-0"></span>
                          <span className="truncate">{opt}</span>
                        </div>
                      ))}
                    </div>

                    {/* Financial Summary */}
                    <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl space-y-1.5">
                      <div className="flex items-baseline justify-between">
                        <span className="text-xs text-slate-400">Prix affiché TTC :</span>
                        <span className="text-base font-extrabold text-white tabular-nums">
                          {Number(car.sellingPrice).toLocaleString('fr-FR')} €
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/80">
                        <span className="text-slate-500">
                          {car.businessType === 'depot_vente' ? 'Net vendeur souhaité :' : 'Prix achat net :'}
                        </span>
                        <span className="text-slate-300 tabular-nums font-semibold">
                          {(car.sellerDesiredPrice || car.costs.purchasePrice).toLocaleString('fr-FR')} €
                        </span>
                      </div>

                      {car.businessType === 'depot_vente' && (
                        <div className="flex items-center justify-between text-[11px] text-slate-400">
                          <span>Frais engagés garage :</span>
                          <span className="tabular-nums">
                            {(car.costs.transport + car.costs.reconditioning + car.costs.detailing + car.costs.inspection + car.costs.adminFees + car.costs.warrantyCost).toLocaleString('fr-FR')} €
                          </span>
                        </div>
                      )}

                      <div className="flex items-center justify-between text-xs pt-0.5">
                        <span className="text-slate-500">
                          {car.businessType === 'depot_vente' ? 'Commission nette :' : 'Marge nette estimée :'}
                        </span>
                        <span className={`font-bold tabular-nums ${margin >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          +{margin.toLocaleString('fr-FR')} € ({marginPct.toFixed(1)}%)
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="p-4 pt-0 space-y-2.5">
                  {/* Primary Dual Actions: Fiche Vente (Détaillée) + Mode Présentation Client */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => (onOpenVehicleDetail ? onOpenVehicleDetail(car) : onOpenVehicleShow(car))}
                      className="py-2 px-2 bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow transition-colors cursor-pointer border border-amber-500/20"
                      title="Ouvrir la fiche véhicule complète (état de la vente, chiffres, marges, documents)"
                    >
                      <FileText className="w-3.5 h-3.5 text-amber-400" />
                      <span>Fiche Vente</span>
                    </button>

                    <button
                      onClick={() => onOpenVehicleShow(car)}
                      className="py-2 px-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer"
                      title="Ouvrir le Mode Présentation Client pour montrer au client (sans marge interne)"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Showcase Client</span>
                    </button>
                  </div>

                  {/* Secondary Actions: Réserver + Modifier */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onOpenReservation(car)}
                      className="py-1.5 px-2 bg-blue-600 hover:bg-blue-500 text-white font-extrabold rounded-lg text-xs flex items-center justify-center gap-1 shadow transition-colors cursor-pointer"
                      title="Réserver le véhicule et pré-remplir le Bon de Commande officiel"
                    >
                      <BookmarkCheck className="w-3.5 h-3.5" />
                      <span>{car.status === 'reserve' ? 'Réservé (Bon)' : 'Réserver'}</span>
                    </button>

                    <button
                      onClick={() => onOpenVehicleModal(car)}
                      className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold rounded-lg text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      title="Modifier les informations du véhicule"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-slate-400" />
                      <span>Modifier</span>
                    </button>
                  </div>

                  {/* Dedicated Media & Damages Banner Button */}
                  <button
                    onClick={() => onOpenMediaDamages(car)}
                    className="w-full py-1.5 px-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-lg text-xs font-semibold text-slate-300 hover:text-white flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5">
                      <Camera className="w-3.5 h-3.5 text-amber-400" />
                      <span>Photos & Vidéos ({car.mediaItems?.length || car.images?.length || 0})</span>
                    </span>
                    <span className="flex items-center gap-1 text-[11px] text-slate-400">
                      <AlertTriangle className={`w-3 h-3 ${car.damages && car.damages.length > 0 ? 'text-amber-400' : 'text-slate-500'}`} />
                      <span>{car.damages?.length || 0} dommage(s)</span>
                    </span>
                  </button>

                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => onOpenWindowSticker(car)}
                      className="px-2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-amber-400 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      title="Affiche Pare-Brise Parc A4"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Vitrine</span>
                    </button>
                    <button
                      onClick={() => onOpenBrochure(car)}
                      className="px-2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-amber-400 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      title="Fiche PDF Client"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>PDF Client</span>
                    </button>
                    <button
                      onClick={() => onOpenAiAd(car)}
                      className="px-2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-amber-400 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      title="Générateur d'Annonce IA"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Annonce IA</span>
                    </button>
                  </div>

                  {/* Dépôt-Vente Mandate Quick Link */}
                  {car.businessType === 'depot_vente' && onOpenSalesMandate && (
                    <button
                      onClick={() => onOpenSalesMandate(car)}
                      className="w-full py-1.5 px-2 bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold text-slate-200 hover:text-amber-300 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      title="Établir ou imprimer le Mandat de Vente officiel conforme"
                    >
                      <FileSignature className="w-3.5 h-3.5 text-amber-400" />
                      <span>Mandat de Vente Automobile (Dépôt-Vente)</span>
                    </button>
                  )}

                  {/* Send Invoices & Documents Email button */}
                  {onOpenSendEmail && (
                    <button
                      onClick={() => onOpenSendEmail(car, car.businessType === 'achat_revente' ? 'facture_achat' : 'mandat_depot_vente')}
                      className="w-full py-2 px-2 bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/30 hover:border-amber-400 rounded-lg text-xs font-bold text-amber-300 hover:text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      title="Envoyer la facture d'achat ou les documents par email avec tbdautos@gmail.com"
                    >
                      <Mail className="w-3.5 h-3.5 text-amber-400" />
                      <span>Envoyer Facture & Docs (TBD AUTOS)</span>
                    </button>
                  )}

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                    <button
                      onClick={() => onOpenVehicleModal(car)}
                      className="text-xs font-medium text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Modifier coûts & statut
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer ${car.brand} ${car.model} du stock ?`)) {
                          onDeleteVehicle(car.id);
                        }
                      }}
                      className="text-xs text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                      title="Supprimer du stock"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      ) : (

        /* HIGH-DENSITY TABLE VIEW */
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Véhicule</th>
                  <th className="py-3 px-4">Immatriculation</th>
                  <th className="py-3 px-4">MEC / Km</th>
                  <th className="py-3 px-4">Statut</th>
                  <th className="py-3 px-4">Régime</th>
                  <th className="py-3 px-4 text-right">Prix Achat</th>
                  <th className="py-3 px-4 text-right">Coût Total</th>
                  <th className="py-3 px-4 text-right">Prix Vente TTC</th>
                  <th className="py-3 px-4 text-right">Marge Nette</th>
                  <th className="py-3 px-4 text-center">Actions Rapides</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredVehicles.map((car) => {
                  const totalCost = car.costs.purchasePrice + car.costs.transport + car.costs.reconditioning + car.costs.detailing + car.costs.inspection + car.costs.adminFees + car.costs.warrantyCost;
                  const margin = car.sellingPrice - totalCost;

                  return (
                    <tr key={car.id} className="hover:bg-slate-800/50 transition-colors">
                      <td className="py-3 px-4">
                        <div 
                          onClick={() => (onOpenVehicleDetail ? onOpenVehicleDetail(car) : onOpenVehicleShow(car))}
                          className="font-bold text-white hover:text-amber-400 cursor-pointer flex items-center gap-1.5"
                          title="Cliquer pour ouvrir la Fiche Véhicule détaillée de l'état de la vente"
                        >
                          <span>{car.brand} {car.model}</span>
                          <FileText className="w-3.5 h-3.5 text-slate-500" />
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-xs">{car.version}</div>
                      </td>
                      <td className="py-3 px-4 font-mono font-semibold text-slate-300">
                        {car.registration}
                      </td>
                      <td className="py-3 px-4">
                        <div>{car.year}</div>
                        <div className="text-slate-400 tabular-nums">{Number(car.mileage).toLocaleString('fr-FR')} km</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          car.status === 'en_stock' ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' :
                          car.status === 'reserve' ? 'bg-blue-500/15 text-blue-400 border border-blue-500/30' :
                          car.status === 'en_preparation' ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30' :
                          'bg-slate-800 text-slate-300'
                        }`}>
                          {car.status === 'en_stock' ? 'En stock' : car.status === 'reserve' ? 'Réservé' : car.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[11px] text-slate-400">
                        {car.businessType === 'depot_vente' ? 'Dépôt-vente' : 'Achat-revente'}
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums text-slate-400">
                        {car.costs.purchasePrice.toLocaleString('fr-FR')} €
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums font-medium text-slate-300">
                        {totalCost.toLocaleString('fr-FR')} €
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums font-bold text-white">
                        {Number(car.sellingPrice).toLocaleString('fr-FR')} €
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums font-bold">
                        <span className={margin >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          +{margin.toLocaleString('fr-FR')} €
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => (onOpenVehicleDetail ? onOpenVehicleDetail(car) : onOpenVehicleShow(car))}
                            title="Fiche Véhicule Détaillée (État de la Vente, Marges & Documents)"
                            className="p-1.5 hover:bg-slate-800 text-amber-300 hover:text-amber-200 rounded cursor-pointer"
                          >
                            <FileText className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onOpenVehicleShow(car)}
                            title="Mode Présentation Client"
                            className="p-1.5 hover:bg-slate-800 text-amber-400 hover:text-amber-300 rounded cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onOpenReservation(car)}
                            title="Réserver & Bon de Commande"
                            className="p-1.5 hover:bg-slate-800 text-blue-400 hover:text-blue-300 rounded cursor-pointer"
                          >
                            <BookmarkCheck className="w-4 h-4" />
                          </button>
                          {car.businessType === 'depot_vente' && onOpenSalesMandate && (
                            <button
                              onClick={() => onOpenSalesMandate(car)}
                              title="Mandat de Vente Automobile"
                              className="p-1.5 hover:bg-slate-800 text-emerald-400 hover:text-emerald-300 rounded cursor-pointer"
                            >
                              <FileSignature className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => onOpenWindowSticker(car)}
                            title="Affiche Parc"
                            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-amber-400 rounded cursor-pointer"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onOpenBrochure(car)}
                            title="Brochure PDF"
                            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-amber-400 rounded cursor-pointer"
                          >
                            <FileText className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onOpenAiAd(car)}
                            title="Annonce IA"
                            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-amber-400 rounded cursor-pointer"
                          >
                            <Sparkles className="w-4 h-4 text-amber-400" />
                          </button>
                          <button
                            onClick={() => onOpenMediaDamages(car)}
                            title="Photos, Vidéos & Dommages"
                            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-amber-400 rounded cursor-pointer"
                          >
                            <Camera className="w-4 h-4" />
                          </button>
                          {onOpenSendEmail && (
                            <button
                              onClick={() => onOpenSendEmail(car, car.businessType === 'achat_revente' ? 'facture_achat' : 'mandat_depot_vente')}
                              title="Envoyer Facture d'Achat & Documents (tbdautos@gmail.com)"
                              className="p-1.5 hover:bg-slate-800 text-amber-400 hover:text-amber-300 rounded cursor-pointer"
                            >
                              <Mail className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => onOpenVehicleModal(car)}
                            title="Modifier"
                            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

      )}

    </div>
  );
};
