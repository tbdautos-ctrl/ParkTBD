import React, { useState } from 'react';
import { Vehicle, ReservationBuyerInfo, BuyerType } from '../types';
import { X, CheckCircle2, DollarSign, Calendar, User, Building2, Phone, Mail, MapPin, ShieldCheck, FileText, Sparkles } from 'lucide-react';

interface ReservationModalProps {
  vehicle: Vehicle | null;
  onClose: () => void;
  onConfirmReservation: (vehicleId: string, reservation: ReservationBuyerInfo) => void;
}

export const ReservationModal: React.FC<ReservationModalProps> = ({
  vehicle,
  onClose,
  onConfirmReservation
}) => {
  if (!vehicle) return null;

  const existingRes = vehicle.reservation;

  // Form State
  const [buyerType, setBuyerType] = useState<BuyerType>(existingRes?.buyerType || 'particulier');
  const [name, setName] = useState(existingRes?.name || vehicle.buyerName || '');
  const [firstName, setFirstName] = useState(existingRes?.firstName || '');
  const [sirenSiret, setSirenSiret] = useState(existingRes?.sirenSiret || '');
  const [phone, setPhone] = useState(existingRes?.phone || vehicle.buyerPhone || '');
  const [email, setEmail] = useState(existingRes?.email || '');
  const [address, setAddress] = useState(existingRes?.address || '');
  const [postalCodeCity, setPostalCodeCity] = useState(existingRes?.postalCodeCity || '');
  
  // Dates
  const [orderDate, setOrderDate] = useState(
    existingRes?.orderDate || new Date().toISOString().slice(0, 10)
  );
  const [deliveryDeadlineDate, setDeliveryDeadlineDate] = useState(
    existingRes?.deliveryDeadlineDate || 
    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10)
  );

  // Financial details
  const [vehiclePriceTTC, setVehiclePriceTTC] = useState<number>(
    existingRes?.vehiclePriceTTC ?? vehicle.sellingPrice ?? 0
  );
  const [deliveryPackChosen, setDeliveryPackChosen] = useState<'aucun' | 'pack_1' | 'pack_2'>(
    existingRes?.deliveryPackChosen || 'aucun'
  );

  // Pack prices
  const pack1Price = 150; // Nettoyage pro + 20L carburant
  const pack2Price = 250; // Plein d'essence + gestion admin
  const carteGriseEstimated = vehicle.powerFiscal ? vehicle.powerFiscal * 45 : 250;

  const getPackCost = () => {
    if (deliveryPackChosen === 'pack_1') return pack1Price;
    if (deliveryPackChosen === 'pack_2') return pack2Price + carteGriseEstimated;
    return 0;
  };

  const [adminPrepFees, setAdminPrepFees] = useState<number>(
    existingRes?.adminPrepFees ?? (deliveryPackChosen === 'pack_1' ? pack1Price : deliveryPackChosen === 'pack_2' ? pack2Price : 0)
  );
  const [regFeesCarteGrise, setRegFeesCarteGrise] = useState<number>(
    existingRes?.regFeesCarteGrise ?? (deliveryPackChosen === 'pack_2' ? carteGriseEstimated : 0)
  );

  // When pack choice changes, update defaults
  const handlePackChange = (newPack: 'aucun' | 'pack_1' | 'pack_2') => {
    setDeliveryPackChosen(newPack);
    if (newPack === 'pack_1') {
      setAdminPrepFees(pack1Price);
      setRegFeesCarteGrise(0);
    } else if (newPack === 'pack_2') {
      setAdminPrepFees(pack2Price);
      setRegFeesCarteGrise(carteGriseEstimated);
    } else {
      setAdminPrepFees(0);
      setRegFeesCarteGrise(0);
    }
  };

  const totalPriceToPayTTC = vehiclePriceTTC + adminPrepFees + regFeesCarteGrise;

  const [depositAmount, setDepositAmount] = useState<number>(
    existingRes?.depositAmount ?? Math.min(1000, Math.round(totalPriceToPayTTC * 0.1) || 500)
  );
  const [depositDate, setDepositDate] = useState(
    existingRes?.depositDate || new Date().toISOString().slice(0, 10)
  );
  const [depositPaymentMethod, setDepositPaymentMethod] = useState<'virement' | 'cheque_banque' | 'carte_bancaire' | 'especes'>(
    existingRes?.depositPaymentMethod || 'virement'
  );

  const balanceRemaining = Math.max(0, totalPriceToPayTTC - depositAmount);

  // Order Number
  const orderNumber = existingRes?.orderNumber || `BDC-${vehicle.registration.replace(/-/g, '')}-${new Date().getFullYear()}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Veuillez renseigner le nom du client acheteur.');
      return;
    }

    const reservationData: ReservationBuyerInfo = {
      buyerType,
      name: name.trim(),
      firstName: firstName.trim() || undefined,
      sirenSiret: buyerType === 'professionnel' ? sirenSiret.trim() : undefined,
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
      postalCodeCity: postalCodeCity.trim(),
      orderNumber,
      orderDate,
      deliveryDeadlineDate: deliveryDeadlineDate || undefined,
      vehiclePriceTTC,
      adminPrepFees,
      regFeesCarteGrise,
      totalPriceToPayTTC,
      depositAmount,
      depositDate,
      depositPaymentMethod,
      balanceRemaining,
      deliveryPackChosen
    };

    onConfirmReservation(vehicle.id, reservationData);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-8 flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-400"></span>
              <h2 className="text-base font-bold text-white">
                Réserver ce Véhicule & Établir le Bon de Commande
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {vehicle.brand} {vehicle.model} ({vehicle.registration}) — Remplissage automatique du bon de commande officiel.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto max-h-[82vh]">
          
          {/* Section 1: Client Acheteur */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <User className="w-4 h-4 text-amber-400" />
                Informations du Client Acquéreur
              </h3>

              {/* Type Toggle */}
              <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setBuyerType('particulier')}
                  className={`px-3 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                    buyerType === 'particulier' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Particulier
                </button>
                <button
                  type="button"
                  onClick={() => setBuyerType('professionnel')}
                  className={`px-3 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                    buyerType === 'professionnel' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Professionnel / Société
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {buyerType === 'particulier' ? 'Nom de famille *' : 'Raison Sociale de l\'entreprise *'}
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={buyerType === 'particulier' ? 'ex: MARTIN' : 'ex: SAS AUTO TRANSPORTS'}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              {buyerType === 'particulier' ? (
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Prénom</label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="ex: Jean-Christophe"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">N° SIREN / SIRET</label>
                  <input
                    type="text"
                    value={sirenSiret}
                    onChange={(e) => setSirenSiret(e.target.value)}
                    placeholder="ex: 123 456 789 00012"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Téléphone de contact *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="ex: 06 00 00 00 00"
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Adresse E-mail</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="client@domaine.fr"
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Adresse postale</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="ex: 14 rue de la Liberté"
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Code Postal & Ville</label>
                <input
                  type="text"
                  value={postalCodeCity}
                  onChange={(e) => setPostalCodeCity(e.target.value)}
                  placeholder="ex: 75011 Paris"
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Packs de Livraison */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Packs de Livraison Optionnels (Politique TBD AUTOS)
            </h3>
            <p className="text-[11px] text-slate-400">
              ✨ La préparation et le nettoyage de base sont déjà inclus dans le prix de vente affiché.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <label
                onClick={() => handlePackChange('aucun')}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  deliveryPackChosen === 'aucun'
                    ? 'bg-amber-400/10 border-amber-400 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="pack"
                  className="hidden"
                  checked={deliveryPackChosen === 'aucun'}
                  onChange={() => {}}
                />
                <div className="font-bold text-xs text-white">Sans pack additionnel</div>
                <div className="text-[11px] text-slate-400 mt-1">Formule standard</div>
                <div className="text-xs font-extrabold text-amber-400 mt-2">0 €</div>
              </label>

              <label
                onClick={() => handlePackChange('pack_1')}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  deliveryPackChosen === 'pack_1'
                    ? 'bg-amber-400/10 border-amber-400 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="pack"
                  className="hidden"
                  checked={deliveryPackChosen === 'pack_1'}
                  onChange={() => {}}
                />
                <div className="font-bold text-xs text-white">Pack 1 — Nettoyage & 20L</div>
                <div className="text-[11px] text-slate-400 mt-1">Nettoyage complet pro + 20L carburant</div>
                <div className="text-xs font-extrabold text-amber-400 mt-2">+{pack1Price} €</div>
              </label>

              <label
                onClick={() => handlePackChange('pack_2')}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  deliveryPackChosen === 'pack_2'
                    ? 'bg-amber-400/10 border-amber-400 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="pack"
                  className="hidden"
                  checked={deliveryPackChosen === 'pack_2'}
                  onChange={() => {}}
                />
                <div className="font-bold text-xs text-white">Pack 2 — Clés en main</div>
                <div className="text-[11px] text-slate-400 mt-1">Plein carburant + démarches carte grise</div>
                <div className="text-xs font-extrabold text-amber-400 mt-2">+{pack2Price + carteGriseEstimated} €</div>
              </label>
            </div>
          </div>

          {/* Section 3: Chiffrage Financier & Acompte */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              Modalités Financières & Versement de l'Acompte
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Prix Véhicule TTC (€) *</label>
                <input
                  type="number"
                  required
                  value={vehiclePriceTTC}
                  onChange={(e) => setVehiclePriceTTC(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Frais de dossier / Prépa (€)</label>
                <input
                  type="number"
                  value={adminPrepFees}
                  onChange={(e) => setAdminPrepFees(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Carte Grise & Immat (€)</label>
                <input
                  type="number"
                  value={regFeesCarteGrise}
                  onChange={(e) => setRegFeesCarteGrise(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>
            </div>

            {/* Total Highlight */}
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-baseline justify-between">
              <span className="text-xs font-bold text-slate-300">TOTAL TTC À PAYER :</span>
              <span className="text-xl font-extrabold text-white font-mono">
                {totalPriceToPayTTC.toLocaleString('fr-FR')} € TTC
              </span>
            </div>

            {/* Deposit Section */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-800">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Acompte versé (€) *</label>
                <input
                  type="number"
                  required
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-emerald-400 font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Moyen de règlement</label>
                <select
                  value={depositPaymentMethod}
                  onChange={(e) => setDepositPaymentMethod(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="virement">Virement bancaire</option>
                  <option value="cheque_banque">Chèque de banque</option>
                  <option value="carte_bancaire">Carte bancaire</option>
                  <option value="especes">Espèces (selon plafond légal)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Date limite de livraison</label>
                <input
                  type="date"
                  value={deliveryDeadlineDate}
                  onChange={(e) => setDeliveryDeadlineDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>
            </div>

            {/* Balance Remaining Display */}
            <div className="p-3 bg-amber-400/10 border border-amber-400/30 rounded-xl flex items-baseline justify-between">
              <span className="text-xs font-bold text-amber-300">Solde restant dû à la livraison :</span>
              <span className="text-lg font-black text-amber-300 font-mono">
                {balanceRemaining.toLocaleString('fr-FR')} € TTC
              </span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
            >
              Annuler
            </button>

            <button
              type="submit"
              className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>Valider la Réservation & Établir le Bon de Commande</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
