import React from 'react';
import { Vehicle } from '../types';
import { Printer, X, ShieldCheck, CheckCircle2, Car, Calendar, Gauge, Fuel, Cog, FileText, Phone, Mail, Award } from 'lucide-react';

interface ClientBrochureModalProps {
  vehicle: Vehicle | null;
  onClose: () => void;
}

export const ClientBrochureModal: React.FC<ClientBrochureModalProps> = ({ vehicle, onClose }) => {
  if (!vehicle) return null;

  const handlePrint = () => {
    window.print();
  };

  const mainPhoto = vehicle.images?.[0] || vehicle.mediaItems?.find(m => m.type === 'photo')?.url || null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        
        {/* Modal Toolbar (hidden when printing) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70">
          <div>
            <h2 className="text-lg font-bold text-white">Dossier Présentation Détaillée Client (Brochure PDF)</h2>
            <p className="text-xs text-slate-400">
              Fiche technique complète avec photo, équipements, historique et garantie pour remise client ou export PDF.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Imprimer / Enregistrer en PDF
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Container */}
        <div className="p-8 md:p-12 bg-white text-slate-900 font-sans printable-client-sheet">
          
          {/* Header */}
          <div className="flex items-start justify-between pb-6 border-b-2 border-slate-900">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-slate-950 text-amber-400 flex items-center justify-center font-black text-2xl tracking-tighter">
                T
              </div>
              <div>
                <div className="text-2xl font-black text-slate-950 uppercase tracking-tight">TBD AUTOS</div>
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Négoce Automobile & Vente Intermédiaire · PARKTBD
                </div>
              </div>
            </div>
            <div className="text-right text-xs text-slate-600 space-y-0.5">
              <div className="font-bold text-slate-900 text-sm">Service Commercial TBD AUTOS</div>
              <div className="flex items-center justify-end gap-1 font-mono">
                <Mail className="w-3.5 h-3.5 text-slate-700" /> tbdautos@gmail.com
              </div>
              <div className="text-slate-400">Dossier généré le {new Date().toLocaleDateString('fr-FR')}</div>
            </div>
          </div>

          {/* Vehicle Main Presentation & Hero Photo */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            <div className="md:col-span-7 space-y-4">
              <div>
                <span className="text-xs font-bold text-amber-700 uppercase tracking-widest bg-amber-50 px-2.5 py-1 rounded">
                  Fiche Technique Officielle
                </span>
                <h1 className="text-3xl md:text-4xl font-extrabold text-slate-950 uppercase tracking-tight mt-2">
                  {vehicle.brand} {vehicle.model}
                </h1>
                <p className="text-lg font-semibold text-slate-700 mt-1">
                  {vehicle.version}
                </p>
                <div className="text-xs text-slate-400 mt-1 font-mono">
                  Immatriculation : {vehicle.registration} · VIN : {vehicle.vin}
                </div>
              </div>

              {/* Photo Display */}
              <div className="w-full aspect-16/9 rounded-xl overflow-hidden border border-slate-200 shadow-sm relative bg-slate-100 flex items-center justify-center">
                {mainPhoto ? (
                  <img
                    src={mainPhoto}
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="text-center p-6 space-y-2 text-slate-400">
                    <Car className="w-12 h-12 text-slate-300 mx-auto" />
                    <span className="text-xs font-medium block">Aucune photo enregistrée</span>
                  </div>
                )}
              </div>

              {/* Gallery Thumbnails (if multiple media exist) */}
              {((vehicle.mediaItems && vehicle.mediaItems.length > 1) || (vehicle.images && vehicle.images.length > 1)) && (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {(vehicle.mediaItems?.filter(m => m.type === 'photo').map(m => m.url) || vehicle.images || []).slice(0, 5).map((imgUrl, i) => (
                    <div key={i} className="w-20 h-14 rounded-lg overflow-hidden border border-slate-200 shrink-0 bg-slate-100">
                      <img src={imgUrl} alt={`Vue ${i + 1}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Price & Commercial Package Summary */}
            <div className="md:col-span-5 bg-slate-50 border border-slate-200 rounded-2xl p-6 flex flex-col justify-between h-full">
              <div>
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Prix de Vente Conseillé TTC
                </div>
                <div className="text-4xl font-black text-slate-950 tabular-nums my-1">
                  {Number(vehicle.sellingPrice).toLocaleString('fr-FR')} €
                </div>
                {vehicle.monthlyEstimate > 0 && (
                  <div className="text-sm font-semibold text-amber-700 mt-0.5">
                    Simulation de financement dès {vehicle.monthlyEstimate} € / mois
                  </div>
                )}
                <div className="text-[11px] text-slate-500 mt-1">
                  Régime de taxe : {vehicle.tvaRegime === 'marge' ? 'TVA sur marge d\'occasion (Art. 297A CGI)' : 'TVA 20% récupérable'}
                </div>

                <div className="mt-6 pt-6 border-t border-slate-200 space-y-3">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                    <div className="text-xs">
                      <div className="font-bold text-slate-900">Garantie Contractuelle</div>
                      <div className="text-slate-600">{vehicle.guarantee}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Award className="w-5 h-5 text-amber-600 flex-shrink-0" />
                    <div className="text-xs">
                      <div className="font-bold text-slate-900">Origine & Traçabilité</div>
                      <div className="text-slate-600">{vehicle.history.origin}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
                    <div className="text-xs">
                      <div className="font-bold text-slate-900">Préparation Complète</div>
                      <div className="text-slate-600">100 points de contrôle, révision à jour & essai sur route</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-200 text-[11px] text-slate-500">
                Véhicule disponible et visible à : <span className="font-semibold text-slate-800">{vehicle.location}</span>
              </div>
            </div>
          </div>

          {/* Technical Specifications Matrix */}
          <div className="mt-8">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
              <Car className="w-4 h-4 text-slate-700" /> Caractéristiques Techniques
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-500 block">Date 1ère mise en circ.</span>
                <span className="font-bold text-slate-900 text-sm">
                  {new Date(vehicle.firstRegistrationDate).toLocaleDateString('fr-FR')}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Kilométrage certifié</span>
                <span className="font-bold text-slate-900 text-sm tabular-nums">
                  {Number(vehicle.mileage).toLocaleString('fr-FR')} km
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Motorisation & Énergie</span>
                <span className="font-bold text-slate-900 text-sm">
                  {vehicle.fuel} · {vehicle.powerDin} ch
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Boîte de vitesses</span>
                <span className="font-bold text-slate-900 text-sm">
                  {vehicle.gearbox}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Puissance fiscale</span>
                <span className="font-bold text-slate-900 text-sm">
                  {vehicle.powerFiscal} CV
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Teinte carrosserie</span>
                <span className="font-bold text-slate-900 text-sm">
                  {vehicle.colorExterior}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Intérieur & Finition</span>
                <span className="font-bold text-slate-900 text-sm">
                  {vehicle.colorInterior}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Certificat Crit'Air</span>
                <span className="font-bold text-slate-900 text-sm">
                  Classe {vehicle.critAir} {vehicle.co2 ? `(${vehicle.co2} g/km)` : ''}
                </span>
              </div>
            </div>
          </div>

          {/* Options & Equipment Details */}
          <div className="mt-8">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700" /> Équipements de Série & Options Notables
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-700 uppercase">Options Phares</div>
                <ul className="space-y-1.5 text-xs text-slate-800">
                  {(vehicle.keyOptions || []).map((opt, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-emerald-700 font-bold">•</span>
                      <span>{opt}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-3">
                {(vehicle.detailedEquipment || []).map((group, idx) => (
                  <div key={idx}>
                    <div className="text-xs font-bold text-slate-700 uppercase">{group.category}</div>
                    <ul className="space-y-1 text-xs text-slate-700 mt-1">
                      {group.items.map((it, j) => (
                        <li key={j} className="flex items-start gap-2">
                          <span className="text-slate-400">-</span>
                          <span>{it}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* History & Administrative Guarantees */}
          <div className="mt-8 pt-6 border-t border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-700" /> Transparence & Historique Administratif
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-slate-700">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900 block">Entretien & Carnet</span>
                {vehicle.history.serviceBookComplete ? 'Carnet à jour avec factures d\'entretien' : 'Suivi partiel'}
                {vehicle.history.lastServiceDate && (
                  <div className="text-[11px] text-slate-500 mt-1">
                    Dernière révision : {vehicle.history.lastServiceDate} ({vehicle.history.lastServiceKm} km)
                  </div>
                )}
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900 block">Situation Administrative</span>
                Certificat de non-gage vierge daté de moins de 15 jours. Véhicule libre de tout gage.
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900 block">État des Lieux & Carrosserie</span>
                {vehicle.damages && vehicle.damages.length > 0 ? (
                  <span>
                    {vehicle.damages.length} élément(s) tracé(s) ({vehicle.damages.filter(d => d.repaired).length} réparé(s)).
                  </span>
                ) : (
                  <span>Contrôle 100 points validé : Aucun défaut carrosserie constaté.</span>
                )}
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="font-bold text-slate-900 block">Démarches & Reprise</span>
                Gestion intégrale de la carte grise sur place et reprise possible de votre ancien véhicule.
              </div>
            </div>
          </div>

          {/* Footer Signature */}
          <div className="mt-8 pt-4 border-t-2 border-slate-900 flex items-center justify-between text-xs text-slate-500">
            <div>
              Document officiel TBD AUTOS (PARKTBD) · Offre sous réserve de disponibilité du véhicule en stock
            </div>
            <div>
              Page 1 / 1
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
