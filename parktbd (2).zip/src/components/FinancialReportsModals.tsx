import React, { useState } from 'react';
import { Vehicle, FinancialStats } from '../types';
import { 
  Printer, 
  X, 
  Download, 
  FileText, 
  DollarSign, 
  TrendingUp, 
  CheckCircle2, 
  Building2, 
  User, 
  ShieldCheck, 
  Truck, 
  Wrench, 
  Sparkles, 
  Car, 
  Calendar,
  CreditCard,
  Receipt,
  Scale
} from 'lucide-react';

// ==========================================
// 1. GLOBAL FINANCIAL REPORT MODAL
// ==========================================
interface GlobalFinancialReportModalProps {
  vehicles: Vehicle[];
  stats: FinancialStats;
  onClose: () => void;
}

export const GlobalFinancialReportModal: React.FC<GlobalFinancialReportModalProps> = ({
  vehicles,
  stats,
  onClose
}) => {
  const handlePrint = () => {
    window.print();
  };

  const soldVehicles = vehicles.filter(v => v.status === 'vendu' || v.status === 'livre');
  const stockVehicles = vehicles.filter(v => v.status !== 'vendu' && v.status !== 'livre');

  const totalCAVendu = soldVehicles.reduce((acc, v) => acc + (v.soldPrice || v.sellingPrice || 0), 0);
  const totalCostVendu = soldVehicles.reduce((acc, v) => {
    const c = v.costs;
    return acc + (c.purchasePrice + c.transport + c.reconditioning + c.detailing + c.inspection + c.adminFees + c.warrantyCost);
  }, 0);
  const totalMarginVendu = totalCAVendu - totalCostVendu;

  const totalPurchase = vehicles.reduce((acc, v) => acc + (v.costs.purchasePrice || 0), 0);
  const totalTransport = vehicles.reduce((acc, v) => acc + (v.costs.transport || 0), 0);
  const totalMeca = vehicles.reduce((acc, v) => acc + (v.costs.reconditioning || 0), 0);
  const totalDetailing = vehicles.reduce((acc, v) => acc + (v.costs.detailing || 0), 0);
  const totalCtAdmin = vehicles.reduce((acc, v) => acc + (v.costs.inspection || 0) + (v.costs.adminFees || 0), 0);
  const totalWarranty = vehicles.reduce((acc, v) => acc + (v.costs.warrantyCost || 0), 0);
  const totalPrepaGlobal = totalTransport + totalMeca + totalDetailing + totalCtAdmin + totalWarranty;

  // TVA sur marge
  const totalTvaCollectee = vehicles.reduce((acc, v) => {
    const totalCost = v.costs.purchasePrice + v.costs.transport + v.costs.reconditioning + v.costs.detailing + v.costs.inspection + v.costs.adminFees + v.costs.warrantyCost;
    const margin = v.sellingPrice - totalCost;
    if (margin > 0) {
      const rate = v.tvaRate ?? 20;
      const tva = margin - (margin / (1 + rate / 100));
      return acc + tva;
    }
    return acc;
  }, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-8 flex flex-col">
        
        {/* Controls */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Compte-Rendu Financier Global des Ventes — TBD AUTOS</span>
            </h2>
            <p className="text-xs text-slate-400">
              Synthèse d'activité commerciale, marges brutes & nettes, TVA sur marge et engagements de coûts.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimer / Exporter PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Sheet */}
        <div className="p-8 sm:p-12 bg-white text-slate-900 font-sans printable-client-sheet space-y-8 overflow-y-auto max-h-[85vh]">
          
          {/* Header */}
          <div className="flex items-start justify-between border-b-2 border-slate-900 pb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-slate-950 text-amber-400 font-black text-3xl flex items-center justify-center">
                T
              </div>
              <div>
                <h1 className="text-2xl font-black uppercase tracking-tight text-slate-950">TBD AUTOS</h1>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Négoce Automobile, Dépôt-Vente & Vente Intermédiaire · Siret TBD AUTOS
                </p>
                <p className="text-xs text-slate-600 font-mono">Contact financier : tbdautos@gmail.com</p>
              </div>
            </div>
            <div className="text-right text-xs space-y-1">
              <span className="inline-block bg-slate-900 text-amber-400 px-3 py-1 rounded font-bold uppercase tracking-wider text-[11px]">
                RAPPORT FINANCIER GLOBAL
              </span>
              <div className="text-slate-600">Exercice en cours · Date d'édition : {new Date().toLocaleDateString('fr-FR')}</div>
              <div className="font-mono text-slate-400 text-[10px]">Réf. RF-{new Date().getFullYear()}-{new Date().getMonth() + 1}</div>
            </div>
          </div>

          {/* Section 1: KPI Dashboard Grid */}
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-2 mb-4">
              1. Synthèse Clé des Chiffres & Ratios Financiers
            </h2>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[11px] font-semibold text-slate-500 uppercase block">Chiffre d'Affaires Réalisé</span>
                <span className="text-2xl font-black text-slate-950 block mt-1 tabular-nums">
                  {totalCAVendu.toLocaleString('fr-FR')} €
                </span>
                <span className="text-[11px] text-slate-600 mt-1 block font-medium">
                  {soldVehicles.length} véhicule(s) vendu(s)
                </span>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[11px] font-semibold text-slate-500 uppercase block">Chiffre d'Affaires En Parc</span>
                <span className="text-2xl font-black text-slate-950 block mt-1 tabular-nums">
                  {stats.totalStockValueTTC.toLocaleString('fr-FR')} €
                </span>
                <span className="text-[11px] text-slate-600 mt-1 block font-medium">
                  {stockVehicles.length} véhicule(s) en stock/réservé
                </span>
              </div>

              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl">
                <span className="text-[11px] font-semibold text-emerald-800 uppercase block">Marge Nette Potentielle</span>
                <span className="text-2xl font-black text-emerald-700 block mt-1 tabular-nums">
                  +{stats.potentialNetMargin.toLocaleString('fr-FR')} €
                </span>
                <span className="text-[11px] text-emerald-800 mt-1 block font-medium">
                  Taux moyen : {stats.averageMarginPercentage.toFixed(1)}%
                </span>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
                <span className="text-[11px] font-semibold text-amber-900 uppercase block">TVA s/ Marge Estimée</span>
                <span className="text-2xl font-black text-amber-900 block mt-1 tabular-nums">
                  {Math.round(totalTvaCollectee).toLocaleString('fr-FR')} €
                </span>
                <span className="text-[11px] text-amber-800 mt-1 block font-medium">
                  Régime art. 297 A CGI
                </span>
              </div>
            </div>
          </div>

          {/* Section 2: Reconditioning & Preparation Costs Breakdown */}
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-2 mb-4">
              2. Ventilation des Coûts de Remise en État & Préparation ({totalPrepaGlobal.toLocaleString('fr-FR')} €)
            </h2>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[11px] text-slate-500 block">Transport / Convoyage</span>
                <span className="text-lg font-bold text-slate-900 tabular-nums">{totalTransport.toLocaleString('fr-FR')} €</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[11px] text-slate-500 block">Révision & Mécanique</span>
                <span className="text-lg font-bold text-slate-900 tabular-nums">{totalMeca.toLocaleString('fr-FR')} €</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[11px] text-slate-500 block">Carrosserie & Detailing</span>
                <span className="text-lg font-bold text-slate-900 tabular-nums">{totalDetailing.toLocaleString('fr-FR')} €</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[11px] text-slate-500 block">CT & Démarches SIV</span>
                <span className="text-lg font-bold text-slate-900 tabular-nums">{totalCtAdmin.toLocaleString('fr-FR')} €</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="text-[11px] text-slate-500 block">Garanties Commerciales</span>
                <span className="text-lg font-bold text-slate-900 tabular-nums">{totalWarranty.toLocaleString('fr-FR')} €</span>
              </div>
            </div>
          </div>

          {/* Section 3: Summary Table by Vehicle */}
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-2 mb-3">
              3. Détail Véhicule par Véhicule
            </h2>

            <table className="w-full text-left text-xs border border-slate-200">
              <thead className="bg-slate-100 text-slate-700 uppercase font-bold text-[10px] border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Véhicule & Immat</th>
                  <th className="py-2.5 px-3">Régime</th>
                  <th className="py-2.5 px-3">Statut</th>
                  <th className="py-2.5 px-3 text-right">Prix Achat / Net</th>
                  <th className="py-2.5 px-3 text-right">Frais Prépa</th>
                  <th className="py-2.5 px-3 text-right">Prix Vente TTC</th>
                  <th className="py-2.5 px-3 text-right">Marge Nette</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {vehicles.map((v) => {
                  const prepa = v.costs.transport + v.costs.reconditioning + v.costs.detailing + v.costs.inspection + v.costs.adminFees + v.costs.warrantyCost;
                  const totalCost = v.costs.purchasePrice + prepa;
                  const margin = v.sellingPrice - totalCost;

                  return (
                    <tr key={v.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3">
                        <div className="font-bold text-slate-900">{v.brand} {v.model}</div>
                        <div className="font-mono text-[11px] text-slate-500">{v.registration}</div>
                      </td>
                      <td className="py-2 px-3 text-[11px]">
                        {v.businessType === 'depot_vente' ? 'Dépôt-vente' : 'Achat-revente'}
                      </td>
                      <td className="py-2 px-3 text-[11px] font-semibold">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          v.status === 'vendu' ? 'bg-purple-100 text-purple-800' :
                          v.status === 'reserve' ? 'bg-blue-100 text-blue-800' :
                          'bg-emerald-100 text-emerald-800'
                        }`}>
                          {v.status === 'vendu' ? 'Vendu' : v.status === 'reserve' ? 'Réservé' : 'En stock'}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right tabular-nums">{v.costs.purchasePrice.toLocaleString('fr-FR')} €</td>
                      <td className="py-2 px-3 text-right tabular-nums text-slate-600">{prepa.toLocaleString('fr-FR')} €</td>
                      <td className="py-2 px-3 text-right tabular-nums font-bold text-slate-950">{v.sellingPrice.toLocaleString('fr-FR')} €</td>
                      <td className={`py-2 px-3 text-right tabular-nums font-bold ${margin >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                        +{margin.toLocaleString('fr-FR')} €
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Legal Signatures */}
          <div className="pt-6 border-t border-slate-300 grid grid-cols-2 gap-8 text-xs text-slate-600">
            <div>
              <div className="font-bold text-slate-900">Direction Commerciale TBD AUTOS</div>
              <div className="mt-12 text-[11px] border-t border-slate-300 pt-1">Signature & Cachet</div>
            </div>
            <div className="text-right">
              <div className="font-bold text-slate-900">Service Comptabilité & Contrôle de Gestion</div>
              <div className="mt-12 text-[11px] border-t border-slate-300 pt-1">Validation & Date</div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};


// ==========================================
// 2. ACCOUNTING LEDGER MODAL (EXPERT-COMPTABLE)
// ==========================================
interface AccountingLedgerModalProps {
  vehicles: Vehicle[];
  onClose: () => void;
}

export const AccountingLedgerModal: React.FC<AccountingLedgerModalProps> = ({
  vehicles,
  onClose
}) => {
  const handlePrint = () => {
    window.print();
  };

  const totalAchat = vehicles.reduce((acc, v) => acc + (v.costs.purchasePrice || 0), 0);
  const totalVente = vehicles.reduce((acc, v) => acc + (v.sellingPrice || 0), 0);

  const totalMarge = vehicles.reduce((acc, v) => {
    const totalCost = v.costs.purchasePrice + v.costs.transport + v.costs.reconditioning + v.costs.detailing + v.costs.inspection + v.costs.adminFees + v.costs.warrantyCost;
    return acc + (v.sellingPrice - totalCost);
  }, 0);

  const totalTvaMarge = vehicles.reduce((acc, v) => {
    const totalCost = v.costs.purchasePrice + v.costs.transport + v.costs.reconditioning + v.costs.detailing + v.costs.inspection + v.costs.adminFees + v.costs.warrantyCost;
    const margin = v.sellingPrice - totalCost;
    if (margin > 0) {
      const rate = v.tvaRate ?? 20;
      return acc + (margin - (margin / (1 + rate / 100)));
    }
    return acc;
  }, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-6xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-8 flex flex-col">
        
        {/* Controls */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Fiche Comptable & Grand Livre des Marges — TBD AUTOS</span>
            </h2>
            <p className="text-xs text-slate-400">
              Document officiel pour l'expert-comptable avec ventilation TVA sur marge (Article 297 A du CGI).
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimer / PDF Paysage</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Sheet */}
        <div className="p-8 sm:p-10 bg-white text-slate-900 font-sans printable-client-sheet space-y-6 overflow-y-auto max-h-[85vh]">
          
          <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4">
            <div>
              <div className="text-2xl font-black text-slate-950 uppercase">TBD AUTOS — FICHE COMPTABLE ANALYTIQUE</div>
              <div className="text-xs font-semibold text-slate-600">
                RÉGIME PARTICULIER DE LA TVA SUR LA MARGE · BIENS D'OCCASION (ART. 297 A CGI)
              </div>
            </div>
            <div className="text-right text-xs text-slate-600">
              <div className="font-bold">Grand Livre des Opérations</div>
              <div>Date d'arrêté : {new Date().toLocaleDateString('fr-FR')}</div>
            </div>
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900">
            <strong>Mention fiscale obligatoire :</strong> Les véhicules d'occasion sont soumis au régime particulier de la taxe sur la valeur ajoutée sur marge bénéficiaire. La TVA n'est pas déductible par l'acquéreur (sauf véhicules éligibles TVA sur encaissement direct).
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11px] border border-slate-300">
              <thead className="bg-slate-100 text-slate-800 uppercase font-bold border-b border-slate-300">
                <tr>
                  <th className="py-2 px-2.5">Date / Réf</th>
                  <th className="py-2 px-2.5">Immatriculation</th>
                  <th className="py-2 px-2.5">Véhicule</th>
                  <th className="py-2 px-2.5">Régime</th>
                  <th className="py-2 px-2.5 text-right">Prix Achat (€)</th>
                  <th className="py-2 px-2.5 text-right">Frais Prépa (€)</th>
                  <th className="py-2 px-2.5 text-right">Prix Vente TTC (€)</th>
                  <th className="py-2 px-2.5 text-right">Marge Brute (€)</th>
                  <th className="py-2 px-2.5 text-right">Taux TVA</th>
                  <th className="py-2 px-2.5 text-right">TVA s/ Marge (€)</th>
                  <th className="py-2 px-2.5 text-right">Marge Nette (€)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {vehicles.map((v) => {
                  const prepa = v.costs.transport + v.costs.reconditioning + v.costs.detailing + v.costs.inspection + v.costs.adminFees + v.costs.warrantyCost;
                  const totalCost = v.costs.purchasePrice + prepa;
                  const margin = v.sellingPrice - totalCost;
                  const rate = v.tvaRate ?? 20;
                  const tvaMarge = margin > 0 ? (margin - (margin / (1 + rate / 100))) : 0;
                  const netMargin = margin - tvaMarge;

                  return (
                    <tr key={v.id} className="hover:bg-slate-50">
                      <td className="py-2 px-2.5 font-mono">{v.entryDate || '2026-01-01'}</td>
                      <td className="py-2 px-2.5 font-mono font-bold text-slate-900">{v.registration}</td>
                      <td className="py-2 px-2.5">{v.brand} {v.model}</td>
                      <td className="py-2 px-2.5">{v.businessType === 'depot_vente' ? 'Dépôt-Vente' : 'Achat-Revente'}</td>
                      <td className="py-2 px-2.5 text-right tabular-nums">{v.costs.purchasePrice.toLocaleString('fr-FR')} €</td>
                      <td className="py-2 px-2.5 text-right tabular-nums text-slate-600">{prepa.toLocaleString('fr-FR')} €</td>
                      <td className="py-2 px-2.5 text-right tabular-nums font-bold">{v.sellingPrice.toLocaleString('fr-FR')} €</td>
                      <td className="py-2 px-2.5 text-right tabular-nums font-semibold">{(v.sellingPrice - v.costs.purchasePrice).toLocaleString('fr-FR')} €</td>
                      <td className="py-2 px-2.5 text-right tabular-nums font-mono">{rate}%</td>
                      <td className="py-2 px-2.5 text-right tabular-nums font-bold text-amber-800">{Math.round(tvaMarge).toLocaleString('fr-FR')} €</td>
                      <td className={`py-2 px-2.5 text-right tabular-nums font-bold ${netMargin >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                        +{Math.round(netMargin).toLocaleString('fr-FR')} €
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-900 text-slate-950">
                <tr>
                  <td colSpan={4} className="py-2.5 px-2.5 uppercase">Totaux Consolidés ({vehicles.length} véhicules)</td>
                  <td className="py-2.5 px-2.5 text-right tabular-nums">{totalAchat.toLocaleString('fr-FR')} €</td>
                  <td className="py-2.5 px-2.5 text-right tabular-nums">—</td>
                  <td className="py-2.5 px-2.5 text-right tabular-nums">{totalVente.toLocaleString('fr-FR')} €</td>
                  <td className="py-2.5 px-2.5 text-right tabular-nums">—</td>
                  <td className="py-2.5 px-2.5 text-right">—</td>
                  <td className="py-2.5 px-2.5 text-right tabular-nums text-amber-900">{Math.round(totalTvaMarge).toLocaleString('fr-FR')} €</td>
                  <td className="py-2.5 px-2.5 text-right tabular-nums text-emerald-800">+{Math.round(totalMarge - totalTvaMarge).toLocaleString('fr-FR')} €</td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div className="pt-6 border-t border-slate-300 flex justify-between text-xs text-slate-500">
            <div>Attestation établie pour le cabinet d'expertise comptable.</div>
            <div className="font-mono">TBD AUTOS SARL · SIREN 123 456 789</div>
          </div>

        </div>

      </div>
    </div>
  );
};


// ==========================================
// 3. SELLER SETTLEMENT MODAL (DÉPÔT-VENTE)
// ==========================================
interface SellerSettlementModalProps {
  vehicles: Vehicle[];
  initialVehicle?: Vehicle | null;
  onClose: () => void;
}

export const SellerSettlementModal: React.FC<SellerSettlementModalProps> = ({
  vehicles,
  initialVehicle,
  onClose
}) => {
  // Only depot-vente vehicles
  const depotVehicles = vehicles.filter(v => v.businessType === 'depot_vente');
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>(
    initialVehicle?.id || depotVehicles[0]?.id || ''
  );

  const vehicle = vehicles.find(v => v.id === selectedVehicleId) || initialVehicle || depotVehicles[0];

  // Editable settlement parameters
  const [sellingPriceEffectif, setSellingPriceEffectif] = useState<number>(
    vehicle?.soldPrice || vehicle?.sellingPrice || 0
  );

  const garageCosts = vehicle ? (
    vehicle.costs.transport + vehicle.costs.reconditioning + vehicle.costs.detailing + vehicle.costs.inspection + vehicle.costs.adminFees + vehicle.costs.warrantyCost
  ) : 0;

  const [prepaCostsRecharged, setPrepaCostsRecharged] = useState<number>(garageCosts);
  const [garageCommission, setGarageCommission] = useState<number>(
    Math.max(500, Math.round((vehicle?.sellingPrice || 0) - (vehicle?.sellerDesiredPrice || 0) - garageCosts))
  );

  const [paymentRef, setPaymentRef] = useState<string>(`VIR-${new Date().getFullYear()}-001`);
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().slice(0, 10));

  const netToPaySeller = Math.max(0, sellingPriceEffectif - garageCommission - prepaCostsRecharged);

  const handlePrint = () => {
    window.print();
  };

  if (!vehicle) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-md text-center space-y-3">
          <Car className="w-8 h-8 text-amber-400 mx-auto" />
          <h3 className="text-sm font-bold text-white">Aucun véhicule en dépôt-vente</h3>
          <p className="text-xs text-slate-400">
            Pour générer un compte de reddition vendeur, vous devez avoir au moins un véhicule en formule dépôt-vente.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    );
  }

  const seller = vehicle.seller;
  const mandate = vehicle.salesMandate;
  const sellerName = mandate?.mandantName || seller?.name || 'Client Propriétaire Vendeur';
  const sellerFirstName = mandate?.mandantFirstName || '';
  const sellerPhone = mandate?.phone || seller?.phone || '';
  const sellerAddress = mandate?.address || seller?.address || '';
  const sellerCity = mandate?.postalCodeCity || (seller ? `${seller.postalCode || ''} ${seller.city || ''}`.trim() : '');
  const sellerIban = seller?.rib || 'FR76 1234 5678 9012 3456 7890 123';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-8 flex flex-col">
        
        {/* Controls */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Compte de Reddition & Règlement Vendeur (Dépôt-Vente)</span>
            </h2>
            <p className="text-xs text-slate-400">
              Attestation financière formelle et décompte de versement net pour le propriétaire du véhicule.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimer l'exemplaire</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Vehicle Switcher Bar (Screen only) */}
        {depotVehicles.length > 1 && (
          <div className="no-print px-6 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center gap-3 text-xs">
            <span className="text-slate-400 font-medium">Sélectionner un véhicule en dépôt-vente :</span>
            <select
              value={selectedVehicleId}
              onChange={(e) => setSelectedVehicleId(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white"
            >
              {depotVehicles.map(d => (
                <option key={d.id} value={d.id}>
                  {d.brand} {d.model} ({d.registration}) — {d.seller?.name || 'Vendeur'}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Printable Document Sheet */}
        <div className="p-8 sm:p-12 bg-white text-slate-900 font-sans printable-client-sheet space-y-6 overflow-y-auto max-h-[85vh]">
          
          {/* Header */}
          <div className="flex items-start justify-between border-b-2 border-slate-900 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-slate-950 text-amber-400 font-black text-2xl flex items-center justify-center">
                T
              </div>
              <div>
                <div className="text-xl font-black text-slate-950 uppercase tracking-tight">TBD AUTOS</div>
                <div className="text-xs font-semibold text-slate-600 uppercase">
                  Service Gestion des Dépôt-Ventes & Mandats Automobiles
                </div>
                <div className="text-xs text-slate-500 font-mono">tbdautos@gmail.com</div>
              </div>
            </div>
            <div className="text-right text-xs">
              <span className="bg-slate-900 text-amber-400 font-bold px-3 py-1 rounded uppercase tracking-wider text-[11px] block">
                COMPTE DE REDDITION OFFICIEL
              </span>
              <div className="text-slate-500 mt-1">Dossier N° RED-{vehicle.registration.replace(/-/g, '')}</div>
              <div className="text-slate-500">Date : {new Date(paymentDate).toLocaleDateString('fr-FR')}</div>
            </div>
          </div>

          {/* Parties Grid */}
          <div className="grid grid-cols-2 gap-6 p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs">
            <div>
              <span className="font-bold text-slate-900 uppercase block mb-1">Le Mandataire (Garage dépositaire) :</span>
              <div className="font-semibold text-slate-900">TBD AUTOS SARL</div>
              <div className="text-slate-600">Négoce et intermédiation automobile</div>
              <div className="text-slate-600 font-mono">Email : tbdautos@gmail.com</div>
            </div>
            <div>
              <span className="font-bold text-slate-900 uppercase block mb-1">Le Mandant (Client Propriétaire Vendeur) :</span>
              <div className="font-bold text-slate-900">{sellerName} {sellerFirstName}</div>
              {sellerAddress && <div className="text-slate-600">{sellerAddress}</div>}
              {sellerCity && <div className="text-slate-600">{sellerCity}</div>}
              {sellerPhone && <div className="text-slate-600 font-mono">Tél : {sellerPhone}</div>}
            </div>
          </div>

          {/* Vehicle Info Box */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
            <span className="font-bold text-slate-900 uppercase block mb-1">Véhicule Objet du Mandat de Vente :</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>Marque / Modèle : <strong>{vehicle.brand} {vehicle.model}</strong></div>
              <div>Immatriculation : <strong className="font-mono">{vehicle.registration}</strong></div>
              <div>Kilométrage : <strong className="tabular-nums">{Number(vehicle.mileage).toLocaleString('fr-FR')} km</strong></div>
              <div>N° VIN : <strong className="font-mono text-[11px]">{vehicle.vin}</strong></div>
            </div>
          </div>

          {/* Financial Breakdown Table */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-2 mb-3">
              Décompte Financier & Solde Net Vendeur
            </h3>

            <div className="border border-slate-300 rounded-xl overflow-hidden text-xs">
              <div className="flex items-center justify-between p-3.5 bg-slate-50 border-b border-slate-200 font-medium">
                <div>
                  <div className="font-bold text-slate-900">1. Prix de Vente Effectif TTC du Véhicule</div>
                  <div className="text-[11px] text-slate-500">Montant payé par l'acquéreur final</div>
                </div>
                <div className="text-base font-extrabold text-slate-950 font-mono tabular-nums">
                  +{sellingPriceEffectif.toLocaleString('fr-FR')} €
                </div>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-white border-b border-slate-200 font-medium">
                <div>
                  <div className="font-bold text-rose-700">2. Commission d'Intermédiation Garage TBD AUTOS (TTC)</div>
                  <div className="text-[11px] text-slate-500">Frais d'agence, mandat et commercialisation convenue</div>
                </div>
                <div className="text-base font-extrabold text-rose-700 font-mono tabular-nums">
                  -{garageCommission.toLocaleString('fr-FR')} €
                </div>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-white border-b border-slate-200 font-medium">
                <div>
                  <div className="font-bold text-rose-700">3. Frais de Préparation & Remise en État Déduits</div>
                  <div className="text-[11px] text-slate-500">Nettoyage, contrôle technique, réparations atelier convenues</div>
                </div>
                <div className="text-base font-extrabold text-rose-700 font-mono tabular-nums">
                  -{prepaCostsRecharged.toLocaleString('fr-FR')} €
                </div>
              </div>

              {/* NET TOTAL */}
              <div className="flex items-center justify-between p-4 bg-emerald-50 border-t-2 border-emerald-600">
                <div>
                  <div className="text-sm font-black text-emerald-900 uppercase">
                    MONTANT NET TOTAL REVERSÉ AU CLIENT VENDEUR
                  </div>
                  <div className="text-xs text-emerald-700">
                    Solde crédité sur le compte bancaire du mandant propriétaire
                  </div>
                </div>
                <div className="text-2xl font-black text-emerald-800 font-mono tabular-nums">
                  {netToPaySeller.toLocaleString('fr-FR')} €
                </div>
              </div>
            </div>
          </div>

          {/* Payment Details & Quittance */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-2">
            <span className="font-bold text-slate-900 uppercase block">Modalités du Règlement & Quittance :</span>
            <div className="grid grid-cols-2 gap-3 text-slate-700">
              <div>Moyen de paiement : <strong>Virement bancaire</strong></div>
              <div>Date d'exécution : <strong>{new Date(paymentDate).toLocaleDateString('fr-FR')}</strong></div>
              <div className="col-span-2 font-mono text-[11px]">
                IBAN de destination : <strong>{sellerIban}</strong>
              </div>
            </div>
            <p className="text-[11px] text-slate-500 pt-1 border-t border-slate-200">
              Ce document vaut reddition de comptes définitive au sens des articles 1993 et suivants du Code Civil. Les parties déclarent être remplies de tous leurs droits et se consentent mutuellement quittance pleine et entière.
            </p>
          </div>

          {/* Signatures */}
          <div className="pt-8 border-t border-slate-300 grid grid-cols-2 gap-8 text-xs text-slate-600">
            <div>
              <div className="font-bold text-slate-900">Pour le Mandant (Le Propriétaire)</div>
              <div className="text-[11px] text-slate-500 italic">"Bon pour accord et acceptation de la reddition"</div>
              <div className="mt-14 text-[11px] border-t border-slate-300 pt-1">Date et Signature</div>
            </div>
            <div className="text-right">
              <div className="font-bold text-slate-900">Pour le Mandataire (TBD AUTOS)</div>
              <div className="text-[11px] text-slate-500 italic">"Attestation de virement délivrée"</div>
              <div className="mt-14 text-[11px] border-t border-slate-300 pt-1">Cachet et Signature</div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
