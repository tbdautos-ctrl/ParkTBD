import React, { useState } from 'react';
import { UserAccount, UserRole } from '../types';
import { 
  Users, 
  UserPlus, 
  ShieldCheck, 
  Briefcase, 
  Calculator, 
  Car, 
  Trash2, 
  Check, 
  Lock, 
  UserCheck 
} from 'lucide-react';

interface UsersViewProps {
  users: UserAccount[];
  currentUser: { name: string; role: string; email?: string };
  onAddUser: (user: Partial<UserAccount>) => void;
  onUpdateUser: (id: string, user: Partial<UserAccount>) => void;
  onDeleteUser: (id: string) => void;
  onSwitchUser: (user: UserAccount) => void;
}

export const UsersView: React.FC<UsersViewProps> = ({
  users,
  currentUser,
  onAddUser,
  onUpdateUser,
  onDeleteUser,
  onSwitchUser
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('commercial');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    onAddUser({
      name,
      email,
      phone,
      role,
      active: true
    });

    setName('');
    setEmail('');
    setPhone('');
    setIsAdding(false);
  };

  const getRoleLabel = (r: UserRole) => {
    switch (r) {
      case 'admin':
        return 'Administrateur (Tous droits)';
      case 'commercial':
        return 'Commercial (Ventes & Essais)';
      case 'gestionnaire_parc':
        return 'Gestionnaire de Parc (Prépa & Stock)';
      case 'comptable':
        return 'Comptabilité (Marges & Factures)';
    }
  };

  const getRoleIcon = (r: UserRole) => {
    switch (r) {
      case 'admin':
        return <ShieldCheck className="w-4 h-4 text-amber-400" />;
      case 'commercial':
        return <Briefcase className="w-4 h-4 text-blue-400" />;
      case 'gestionnaire_parc':
        return <Car className="w-4 h-4 text-emerald-400" />;
      case 'comptable':
        return <Calculator className="w-4 h-4 text-purple-400" />;
    }
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Équipe & Gestion des Accès Collaborateurs
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Ajoutez vos collaborateurs (commerciaux, préparateurs, comptables) et gérez les permissions du logiciel.
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>{isAdding ? 'Fermer le formulaire' : 'Inviter un Utilisateur'}</span>
        </button>
      </div>

      {/* Add User Drawer / Form */}
      {isAdding && (
        <form onSubmit={handleSubmit} className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 shadow-xl">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <UserPlus className="w-4 h-4 text-amber-400" />
            Nouveau Collaborateur ParkTBD
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Nom complet *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="ex: Julien Mercier"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Adresse Email *</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="collaborateur@parktbd.fr"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Téléphone direct</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="06 12 34 56 78"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Rôle & Permissions *</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="commercial">Commercial (Ventes & Essais)</option>
                <option value="gestionnaire_parc">Gestionnaire de Parc (Stock & Atelier)</option>
                <option value="comptable">Comptable (Marges & Factures)</option>
                <option value="admin">Administrateur (Accès Intégral)</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 text-xs text-slate-400 hover:text-white"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg cursor-pointer"
            >
              Créer le compte collaborateur
            </button>
          </div>
        </form>
      )}

      {/* Users List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {users.map((user) => {
          const isCurrent = user.name === currentUser.name;

          return (
            <div
              key={user.id}
              className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                isCurrent 
                  ? 'bg-slate-900 border-amber-500/40 shadow-lg' 
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 text-white font-bold flex items-center justify-center text-sm">
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        {user.name}
                        {isCurrent && (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-400/10 border border-amber-400/30 px-1.5 py-0.2 rounded">
                            Vous
                          </span>
                        )}
                      </h3>
                      <p className="text-xs text-slate-400">{user.email}</p>
                    </div>
                  </div>

                  {user.role !== 'admin' && (
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer l'accès de ${user.name} ?`)) {
                          onDeleteUser(user.id);
                        }
                      }}
                      className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                      title="Supprimer l'accès"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-semibold text-slate-300">
                    {getRoleIcon(user.role)}
                    <span>{getRoleLabel(user.role)}</span>
                  </div>
                  {user.phone && (
                    <span className="text-slate-500 text-[11px]">{user.phone}</span>
                  )}
                </div>
              </div>

              {/* Quick switch button to test session */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  Compte {user.active ? 'Actif' : 'Désactivé'}
                </span>
                {!isCurrent && (
                  <button
                    onClick={() => onSwitchUser(user)}
                    className="text-xs text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
                  >
                    Basculer sur cette session →
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Permissions Matrix Table */}
      <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-2xl space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Lock className="w-4 h-4 text-amber-400" />
          Matrice des Permissions & Rôles ParkTBD
        </h2>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Fonctionnalité & Module</th>
                <th className="py-3 px-4 text-center">Administrateur</th>
                <th className="py-3 px-4 text-center">Commercial</th>
                <th className="py-3 px-4 text-center">Gestionnaire Parc</th>
                <th className="py-3 px-4 text-center">Comptabilité</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-300">
              <tr>
                <td className="py-2.5 px-4 font-medium">Consulter le stock et les fiches vitrine / PDF</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-medium">Générer les annonces IA (Leboncoin, La Centrale)</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-slate-500">- Non</td>
                <td className="py-2.5 px-4 text-center text-slate-500">- Non</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-medium">Créer et valider des essais routiers & livraisons</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-slate-500">- Non</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-medium">Visualiser les prix d'achat et marges nettes réelles</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-slate-500">- Restreint</td>
                <td className="py-2.5 px-4 text-center text-slate-500">- Non</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-medium">Gestion des utilisateurs et autorisations</td>
                <td className="py-2.5 px-4 text-center text-emerald-400">✓ Oui</td>
                <td className="py-2.5 px-4 text-center text-slate-500">- Non</td>
                <td className="py-2.5 px-4 text-center text-slate-500">- Non</td>
                <td className="py-2.5 px-4 text-center text-slate-500">- Non</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
