import React, { useState } from 'react';
import { Appointment, Vehicle, AppointmentType, AppointmentStatus } from '../types';
import { X, Calendar, User, Phone, Mail, FileText, CheckSquare } from 'lucide-react';

interface AppointmentModalProps {
  isOpen: boolean;
  appointment: Appointment | null;
  vehicles: Vehicle[];
  onClose: () => void;
  onSave: (aptData: Partial<Appointment>) => void;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  appointment,
  vehicles,
  onClose,
  onSave
}) => {
  const isEditing = !!appointment;

  const [vehicleId, setVehicleId] = useState(appointment?.vehicleId || (vehicles[0]?.id || ''));
  const [clientName, setClientName] = useState(appointment?.clientName || '');
  const [clientPhone, setClientPhone] = useState(appointment?.clientPhone || '');
  const [clientEmail, setClientEmail] = useState(appointment?.clientEmail || '');
  const [type, setType] = useState<AppointmentType>(appointment?.type || 'essai_routier');
  const [date, setDate] = useState(
    appointment?.date 
      ? new Date(appointment.date).toISOString().slice(0, 16)
      : new Date(Date.now() + 4 * 3600 * 1000).toISOString().slice(0, 16)
  );
  const [durationMinutes, setDurationMinutes] = useState(appointment?.durationMinutes || 45);
  const [status, setStatus] = useState<AppointmentStatus>(appointment?.status || 'confirme');
  const [driverLicenseChecked, setDriverLicenseChecked] = useState(appointment?.driverLicenseChecked ?? true);
  const [depositLeft, setDepositLeft] = useState(appointment?.depositLeft ?? false);
  const [notes, setNotes] = useState(appointment?.notes || '');
  const [assignedTo, setAssignedTo] = useState(appointment?.assignedTo || 'Daniel Balogun');

  const selectedVehicle = vehicles.find(v => v.id === vehicleId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const vehicleName = selectedVehicle 
      ? `${selectedVehicle.brand} ${selectedVehicle.model} ${selectedVehicle.powerDin}ch`
      : 'Véhicule en parc';

    onSave({
      ...(appointment || {}),
      vehicleId,
      vehicleName,
      clientName,
      clientPhone,
      clientEmail,
      type,
      date: new Date(date).toISOString(),
      durationMinutes: Number(durationMinutes),
      status,
      driverLicenseChecked,
      depositLeft,
      notes,
      assignedTo
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                {isEditing ? 'Modifier le Rendez-vous' : 'Planifier un Essai Routier ou Rendez-vous'}
              </h2>
              <p className="text-xs text-slate-400">
                Suivi des essais clients, vérification du permis et relance commerciale.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Véhicule Cible en Parc *</label>
            <select
              required
              value={vehicleId}
              onChange={(e) => setVehicleId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.brand} {v.model} - {v.registration} ({v.sellingPrice.toLocaleString('fr-FR')} €)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Nom du Client *</label>
              <div className="relative">
                <User className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="ex: Jean Dupont"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Téléphone Client *</label>
              <div className="relative">
                <Phone className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="tel"
                  required
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  placeholder="ex: 06 12 34 56 78"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Email Client</label>
              <div className="relative">
                <Mail className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="email"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  placeholder="client@email.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Type de Visite *</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as AppointmentType)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="essai_routier">Essai Routier (Sur route)</option>
                <option value="visite_commerciale">Visite & Présentation en Showroom</option>
                <option value="livraison">Livraison & Remise des Clés</option>
                <option value="expertise_reprise">Expertise & Estimation Reprise</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Date & Heure *</label>
              <input
                type="datetime-local"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Durée (min)</label>
              <input
                type="number"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Statut *</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as AppointmentStatus)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="confirme">Confirmé</option>
                <option value="en_attente">En attente de confirmation</option>
                <option value="effectue">Effectué</option>
                <option value="annule">Annulé</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Conseiller Assigné</label>
              <input
                type="text"
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          {/* Legal and Security Checklist for Test Drives */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
            <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <CheckSquare className="w-3.5 h-3.5" />
              Sécurité & Conformité Essai Véhicule
            </div>
            <div className="flex flex-col gap-2 pt-1">
              <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={driverLicenseChecked}
                  onChange={(e) => setDriverLicenseChecked(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-700 text-amber-500 focus:ring-0"
                />
                Permis de conduire B en cours de validité vérifié
              </label>
              <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={depositLeft}
                  onChange={(e) => setDepositLeft(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-700 text-amber-500 focus:ring-0"
                />
                Caution ou pré-autorisation bancaire enregistrée (si véhicule haute performance)
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Notes & Attentes Client</label>
            <div className="relative">
              <FileText className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="ex: Client intéressé par un financement en LOA 48 mois, dispose d'un véhicule à faire reprendre..."
                rows={3}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500 resize-none"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-md cursor-pointer"
            >
              {isEditing ? 'Enregistrer' : 'Confirmer le Rendez-vous'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
