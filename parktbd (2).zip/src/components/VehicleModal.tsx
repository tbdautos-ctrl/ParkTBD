import React, { useState, useEffect } from 'react';
import { 
  Vehicle, 
  DocumentStatus, 
  BusinessType, 
  VehicleStatus, 
  FuelType, 
  GearboxType,
  VehicleMediaItem,
  VehicleDocumentFile,
  VehicleDamageItem,
  DocumentCategory,
  EmailDocType,
  Seller,
  PhotoLocationTag
} from '../types';
import { 
  X, 
  Plus, 
  Trash2, 
  Calculator, 
  FileCheck, 
  Car, 
  DollarSign, 
  Camera, 
  Video, 
  Upload, 
  AlertTriangle, 
  CheckCircle2, 
  FileText, 
  Eye, 
  Wrench, 
  Clock, 
  Sparkles,
  Mail,
  ArrowLeft,
  ArrowRight,
  Star,
  Tag,
  Shield,
  ShieldCheck,
  Building2,
  User,
  ExternalLink,
  Percent,
  GripVertical,
  FileSignature
} from 'lucide-react';

interface VehicleModalProps {
  vehicle: Vehicle | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (carData: Partial<Vehicle>) => void;
  onOpenSendEmail?: (vehicle: Vehicle, docType?: EmailDocType) => void;
  sellers?: Seller[];
  onQuickAddSeller?: (seller: Partial<Seller>) => Promise<Seller | void>;
  onOpenSalesMandate?: (vehicle: Vehicle) => void;
}

export const VehicleModal: React.FC<VehicleModalProps> = ({
  vehicle,
  isOpen,
  onClose,
  onSave,
  onOpenSendEmail,
  sellers = [],
  onQuickAddSeller,
  onOpenSalesMandate
}) => {
  const isEditing = !!vehicle;

  type WizardStep = 1 | 2 | 3 | 4 | 5;
  const [step, setStep] = useState<WizardStep>(1);
  const [activeTab, setActiveTab] = useState<'general' | 'costs' | 'media' | 'damages' | 'docs' | 'options'>('general');

  // General Identification
  const [brand, setBrand] = useState(vehicle?.brand || '');
  const [model, setModel] = useState(vehicle?.model || '');
  const [version, setVersion] = useState(vehicle?.version || '');
  const [registration, setRegistration] = useState(vehicle?.registration || '');
  const [vin, setVin] = useState(vehicle?.vin || '');
  const [yearStr, setYearStr] = useState<string>(vehicle?.year !== undefined ? String(vehicle.year) : String(new Date().getFullYear()));
  const [firstRegistrationDate, setFirstRegistrationDate] = useState(vehicle?.firstRegistrationDate || '2023-01-01');
  const [mileageStr, setMileageStr] = useState<string>(vehicle?.mileage !== undefined ? String(vehicle.mileage) : '0');
  const [fuel, setFuel] = useState<FuelType>(vehicle?.fuel || 'Essence');
  const [gearbox, setGearbox] = useState<GearboxType>(vehicle?.gearbox || 'Automatique');
  const [powerDinStr, setPowerDinStr] = useState<string>(vehicle?.powerDin !== undefined ? String(vehicle.powerDin) : '0');
  const [powerFiscalStr, setPowerFiscalStr] = useState<string>(vehicle?.powerFiscal !== undefined ? String(vehicle.powerFiscal) : '0');
  const [critAir, setCritAir] = useState<number>(vehicle?.critAir || 1);
  const [colorExterior, setColorExterior] = useState(vehicle?.colorExterior || 'Gris métallisé');
  const [colorInterior, setColorInterior] = useState(vehicle?.colorInterior || 'Tissu / Cuir Noir');
  const [businessType, setBusinessType] = useState<BusinessType>(vehicle?.businessType || 'achat_revente');
  const [status, setStatus] = useState<VehicleStatus>(vehicle?.status || 'en_stock');
  const [location, setLocation] = useState(vehicle?.location || 'Showroom Principal');

  // Consignor / Seller for Dépôt-Vente
  const [sellerId, setSellerId] = useState<string>(vehicle?.sellerId || '');
  const [sellerMode, setSellerMode] = useState<'existing' | 'new'>('existing');
  const [newSellerType, setNewSellerType] = useState<'particulier' | 'professionnel'>('particulier');
  const [newSellerName, setNewSellerName] = useState('');
  const [newSellerFirstName, setNewSellerFirstName] = useState('');
  const [newSellerPhone, setNewSellerPhone] = useState('');
  const [newSellerEmail, setNewSellerEmail] = useState('');
  const [newSellerAddress, setNewSellerAddress] = useState('');
  const [newSellerCity, setNewSellerCity] = useState('');
  const [newSellerPostalCode, setNewSellerPostalCode] = useState('');
  const [newSellerIdNumber, setNewSellerIdNumber] = useState('');
  const [newSellerRib, setNewSellerRib] = useState('');
  const [newSellerCompanyName, setNewSellerCompanyName] = useState('');
  const [newSellerSiret, setNewSellerSiret] = useState('');
  const [sellerSavedSuccess, setSellerSavedSuccess] = useState(false);

  // Financials & Costs
  // Default to 0 for a new vehicle, and keep inputs empty when user deletes digits!
  const [sellerDesiredPriceStr, setSellerDesiredPriceStr] = useState<string>(
    vehicle?.sellerDesiredPrice !== undefined ? String(vehicle.sellerDesiredPrice) :
    (vehicle?.costs.purchasePrice !== undefined && vehicle?.businessType === 'depot_vente' ? String(vehicle.costs.purchasePrice) : '0')
  );
  const [purchasePriceStr, setPurchasePriceStr] = useState<string>(
    vehicle?.costs.purchasePrice !== undefined ? String(vehicle.costs.purchasePrice) : '0'
  );
  const [transportStr, setTransportStr] = useState<string>(
    vehicle?.costs.transport !== undefined ? String(vehicle.costs.transport) : '0'
  );
  const [reconditioningStr, setReconditioningStr] = useState<string>(
    vehicle?.costs.reconditioning !== undefined ? String(vehicle.costs.reconditioning) : '0'
  );
  const [detailingStr, setDetailingStr] = useState<string>(
    vehicle?.costs.detailing !== undefined ? String(vehicle.costs.detailing) : '0'
  );
  const [inspectionStr, setInspectionStr] = useState<string>(
    vehicle?.costs.inspection !== undefined ? String(vehicle.costs.inspection) : '0'
  );
  const [adminFeesStr, setAdminFeesStr] = useState<string>(
    vehicle?.costs.adminFees !== undefined ? String(vehicle.costs.adminFees) : '0'
  );
  const [warrantyCostStr, setWarrantyCostStr] = useState<string>(
    vehicle?.costs.warrantyCost !== undefined ? String(vehicle.costs.warrantyCost) : '0'
  );
  const [sellingPriceStr, setSellingPriceStr] = useState<string>(
    vehicle?.sellingPrice !== undefined ? String(vehicle.sellingPrice) : '0'
  );
  const [monthlyEstimateStr, setMonthlyEstimateStr] = useState<string>(
    vehicle?.monthlyEstimate !== undefined ? String(vehicle.monthlyEstimate) : '0'
  );

  // TVA Regime & French Tax DGFiP Rates
  const [tvaRegime, setTvaRegime] = useState<'marge' | 'standard'>(vehicle?.tvaRegime || 'marge');
  const [tvaRate, setTvaRate] = useState<number>(vehicle?.tvaRate ?? 20);

  // Commercial Warranty Levers
  const [warrantyInitialMonths, setWarrantyInitialMonths] = useState<number>(
    vehicle?.warrantyInitialMonths || 12
  );
  const [hasWarrantyExtension, setHasWarrantyExtension] = useState<boolean>(
    (vehicle?.warrantyExtensionMonths || 0) > 0
  );
  const [warrantyExtensionMonths, setWarrantyExtensionMonths] = useState<number>(
    vehicle?.warrantyExtensionMonths || 12
  );
  const [warrantyExtensionCostStr, setWarrantyExtensionCostStr] = useState<string>(
    vehicle?.warrantyExtensionCost !== undefined ? String(vehicle.warrantyExtensionCost) : '0'
  );
  const [warrantyProvider, setWarrantyProvider] = useState<string>(
    vehicle?.warrantyProvider || 'Opteven Premium'
  );
  const [guarantee, setGuarantee] = useState(
    vehicle?.guarantee || 'Garantie 12 Mois Pièces et Main d’œuvre'
  );

  // Lightbox for CNI / KBIS viewer
  const [viewingSellerDoc, setViewingSellerDoc] = useState<{ title: string; url?: string; type: string } | null>(null);

  // Media (Photos & Videos)
  const [mediaItems, setMediaItems] = useState<VehicleMediaItem[]>(
    vehicle?.mediaItems || (vehicle?.images?.map((img, idx) => ({
      id: `med-${idx}`,
      type: 'photo' as const,
      url: img,
      title: idx === 0 ? 'Photo principale véhicule' : `Photo ${idx + 1}`,
      createdAt: new Date().toISOString()
    })) || [])
  );
  const [newMediaTitle, setNewMediaTitle] = useState('');

  // Scanned Document Files
  const [documentFiles, setDocumentFiles] = useState<VehicleDocumentFile[]>(
    vehicle?.documentFiles || (vehicle?.documents?.files?.map(f => ({
      id: f.id,
      name: f.name,
      type: f.type,
      category: 'autre' as DocumentCategory,
      url: '#',
      uploadDate: f.uploadDate,
      size: f.size
    })) || [])
  );
  const [selectedDocCategory, setSelectedDocCategory] = useState<DocumentCategory>('carte_grise');
  const [newDocNotes, setNewDocNotes] = useState('');

  // Damages & Inspection Items
  const [damages, setDamages] = useState<VehicleDamageItem[]>(vehicle?.damages || []);
  const [damageTitle, setDamageTitle] = useState('');
  const [damageLocation, setDamageLocation] = useState('');
  const [damageSeverity, setDamageSeverity] = useState<'mineur' | 'moyen' | 'important'>('mineur');
  const [damageRepairCost, setDamageRepairCost] = useState<number>(0);
  const [damageRepaired, setDamageRepaired] = useState(false);
  const [damageNotes, setDamageNotes] = useState('');
  const [damageMediaUrl, setDamageMediaUrl] = useState<string | null>(null);

  // Administrative checklist status
  const [carteGrise, setCarteGrise] = useState<DocumentStatus>(vehicle?.documents.carteGrise || 'complet');
  const [certificatCession, setCertificatCession] = useState<DocumentStatus>(vehicle?.documents.certificatCession || 'complet');
  const [certificatNonGage, setCertificatNonGage] = useState<DocumentStatus>(vehicle?.documents.certificatNonGage || 'complet');
  const [controleTechnique, setControleTechnique] = useState<DocumentStatus>(vehicle?.documents.controleTechnique || 'complet');
  const [bonCommande, setBonCommande] = useState<DocumentStatus>(vehicle?.documents.bonCommande || 'en_attente');
  const [factureAchat, setFactureAchat] = useState<DocumentStatus>(vehicle?.documents.factureAchat || 'complet');
  const [mandatVente, setMandatVente] = useState<DocumentStatus>(vehicle?.documents.mandatVente || (businessType === 'depot_vente' ? 'complet' : 'non_requis'));
  const [doubleDesCles, setDoubleDesCles] = useState<boolean>(vehicle?.documents.doubleDesCles ?? true);
  const [carnetEntretien, setCarnetEntretien] = useState<boolean>(vehicle?.documents.carnetEntretien ?? true);

  // Key Options list
  const [keyOptions, setKeyOptions] = useState<string[]>(
    vehicle?.keyOptions || []
  );
  const [newOptionInput, setNewOptionInput] = useState('');

  // Convert string inputs safely to numbers (so empty string "" stays empty and is treated as 0 for calculations)
  const toNum = (val: string) => val === '' ? 0 : (Number(val) || 0);

  const sellerDesiredPrice = toNum(sellerDesiredPriceStr);
  const purchasePrice = toNum(purchasePriceStr);
  const transport = toNum(transportStr);
  const reconditioning = toNum(reconditioningStr);
  const detailing = toNum(detailingStr);
  const inspection = toNum(inspectionStr);
  const adminFees = toNum(adminFeesStr);
  const warrantyCost = toNum(warrantyCostStr);
  const sellingPrice = toNum(sellingPriceStr);
  const monthlyEstimate = toNum(monthlyEstimateStr);
  const warrantyExtensionCost = toNum(warrantyExtensionCostStr);

  const totalPrepFees = transport + reconditioning + detailing + inspection + adminFees + warrantyCost;

  let totalCostInvested: number;
  let grossMargin: number;
  let netMargin: number;
  let marginPercentage: number;

  if (businessType === 'depot_vente') {
    totalCostInvested = sellerDesiredPrice + totalPrepFees;
    const grossCommission = sellingPrice - sellerDesiredPrice;
    grossMargin = grossCommission;
    netMargin = grossCommission - totalPrepFees;
    marginPercentage = sellerDesiredPrice > 0 ? (netMargin / sellerDesiredPrice) * 100 : 0;
  } else {
    totalCostInvested = purchasePrice + totalPrepFees;
    grossMargin = sellingPrice - totalCostInvested;
    netMargin = grossMargin;
    marginPercentage = totalCostInvested > 0 ? (grossMargin / totalCostInvested) * 100 : 0;
  }

  // French Tax Authority (DGFiP) TVA on margin or standard calculation
  const marginTTC = Math.max(0, sellingPrice - (businessType === 'depot_vente' ? sellerDesiredPrice : purchasePrice));
  const tvaAmount = tvaRegime === 'marge'
    ? (tvaRate > 0 ? (marginTTC * (tvaRate / (100 + tvaRate))) : 0)
    : (tvaRate > 0 ? ((sellingPrice / (1 + tvaRate / 100)) * (tvaRate / 100)) : 0);
  const netMarginAfterTva = netMargin - (tvaRegime === 'marge' ? tvaAmount : 0);

  const selectedSeller = sellers.find(s => s.id === sellerId);

  const stepsConfig = [
    { num: 1 as WizardStep, title: 'Fiche Véhicule', desc: 'Spécifications' },
    { num: 2 as WizardStep, title: 'Chiffres & Finances', desc: 'Marge & Coût Mehdi' },
    { num: 3 as WizardStep, title: 'Type & Mandat', desc: 'Vendeur déposant' },
    { num: 4 as WizardStep, title: 'Photos & Médias', desc: 'Glisser pour réorganiser' },
    { num: 5 as WizardStep, title: 'Vitrine & Validation', desc: 'Garanties & Validation' }
  ];

  const handleSaveNewSeller = async () => {
    if (!newSellerName.trim() || !newSellerPhone.trim()) {
      alert("Veuillez renseigner au moins le nom du vendeur et son téléphone.");
      return;
    }
    if (onQuickAddSeller) {
      const created = await onQuickAddSeller({
        name: (newSellerName.trim()) + (newSellerFirstName.trim() ? ` ${newSellerFirstName.trim()}` : ''),
        type: newSellerType,
        companyName: newSellerCompanyName.trim() || undefined,
        phone: newSellerPhone.trim(),
        email: newSellerEmail.trim(),
        address: newSellerAddress.trim(),
        city: newSellerCity.trim(),
        postalCode: newSellerPostalCode.trim(),
        rib: newSellerRib.trim(),
        idDocumentNumber: newSellerIdNumber.trim(),
        siret: newSellerSiret.trim() || undefined,
        notes: "Créé lors de l'enregistrement véhicule en dépôt-vente"
      });
      if (created && created.id) {
        setSellerId(created.id);
        setSellerMode('existing');
        setSellerSavedSuccess(true);
        setTimeout(() => setSellerSavedSuccess(false), 3000);
      }
    }
  };

  const handlePreviewSalesMandate = () => {
    if (!onOpenSalesMandate) return;
    const currentSellerObj: Seller = sellerMode === 'existing' && selectedSeller
      ? selectedSeller
      : {
          id: sellerId || `sel-temp-${Date.now()}`,
          name: (newSellerName || 'Client Vendeur Déposant') + (newSellerFirstName ? ` ${newSellerFirstName}` : ''),
          type: newSellerType,
          companyName: newSellerCompanyName || undefined,
          phone: newSellerPhone || '06 00 00 00 00',
          email: newSellerEmail || 'client@email.com',
          address: newSellerAddress || 'Adresse client',
          city: newSellerCity || 'Bordeaux',
          postalCode: newSellerPostalCode || '33000',
          rib: newSellerRib || 'FR76 ...',
          idDocumentNumber: newSellerIdNumber || 'CNI 123456789',
          siret: newSellerSiret || undefined,
          notes: 'Mandat dépôt-vente',
          createdAt: new Date().toISOString()
        };

    const tempVehicle: Vehicle = {
      ...(vehicle || {
        doors: 5,
        seats: 5,
        monthlyEstimate: 0,
        warrantyInitialMonths: 3,
        warrantyExtensionMonths: 0,
        detailedEquipment: [],
        history: {
          origin: 'Origine France',
          firstOwner: true,
          serviceBookComplete: true
        },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }),
      createdAt: vehicle?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      id: vehicle?.id || `veh-temp-${Date.now()}`,
      brand: brand || 'Véhicule',
      model: model || 'Modèle',
      version,
      registration: registration || 'XX-000-XX',
      vin: vin || 'VF1XXXXXXXXXXXXXX',
      year: toNum(yearStr) || new Date().getFullYear(),
      firstRegistrationDate,
      mileage: toNum(mileageStr),
      fuel,
      gearbox,
      powerDin: toNum(powerDinStr),
      powerFiscal: toNum(powerFiscalStr),
      critAir,
      colorExterior,
      colorInterior,
      doors: vehicle?.doors || 5,
      seats: vehicle?.seats || 5,
      businessType: 'depot_vente',
      sellerId: currentSellerObj.id,
      seller: currentSellerObj,
      sellerDesiredPrice: toNum(sellerDesiredPriceStr),
      sellingPrice: toNum(sellingPriceStr),
      status,
      location,
      guarantee,
      warrantyInitialMonths,
      warrantyExtensionMonths: hasWarrantyExtension ? warrantyExtensionMonths : 0,
      warrantyProvider: hasWarrantyExtension ? warrantyProvider : undefined,
      tvaRegime,
      tvaRate,
      monthlyEstimate: toNum(monthlyEstimateStr),
      detailedEquipment: vehicle?.detailedEquipment || [],
      history: vehicle?.history || {
        origin: 'Origine France',
        firstOwner: true,
        serviceBookComplete: true
      },
      costs: {
        purchasePrice: toNum(sellerDesiredPriceStr),
        transport: toNum(transportStr),
        reconditioning: toNum(reconditioningStr),
        detailing: toNum(detailingStr),
        inspection: toNum(inspectionStr),
        adminFees: toNum(adminFeesStr),
        warrantyCost: toNum(warrantyCostStr),
        customCosts: vehicle?.costs?.customCosts || []
      },
      documents: {
        carteGrise,
        certificatCession,
        certificatNonGage,
        controleTechnique,
        bonCommande,
        factureAchat,
        factureVente: vehicle?.documents?.factureVente || 'en_attente',
        mandatVente: 'complet',
        doubleDesCles,
        carnetEntretien,
        files: []
      },
      images: mediaItems.map(m => m.url),
      mediaItems,
      documentFiles,
      damages,
      keyOptions,
      entryDate: vehicle?.entryDate || new Date().toISOString().split('T')[0]
    };

    onOpenSalesMandate(tempVehicle);
  };

  // Sync guarantee label when levers move
  useEffect(() => {
    const totalMonths = warrantyInitialMonths + (hasWarrantyExtension ? warrantyExtensionMonths : 0);
    const generated = hasWarrantyExtension 
      ? `Garantie ${warrantyInitialMonths} Mois TBD + Extension ${warrantyExtensionMonths} Mois (${warrantyProvider}) - Total ${totalMonths} Mois`
      : `Garantie ${warrantyInitialMonths} Mois Pièces & Main d'œuvre`;
    setGuarantee(generated);
  }, [warrantyInitialMonths, hasWarrantyExtension, warrantyExtensionMonths, warrantyProvider]);

  // Media reordering (Drag-and-Drop and Buttons)
  const [draggedMediaIndex, setDraggedMediaIndex] = useState<number | null>(null);
  const [dragOverMediaIndex, setDragOverMediaIndex] = useState<number | null>(null);

  const handleMediaDragStart = (e: React.DragEvent, index: number) => {
    setDraggedMediaIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleMediaDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverMediaIndex !== index) {
      setDragOverMediaIndex(index);
    }
  };

  const handleMediaDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedMediaIndex === null || draggedMediaIndex === targetIndex) {
      setDraggedMediaIndex(null);
      setDragOverMediaIndex(null);
      return;
    }
    const newMedia = [...mediaItems];
    const [draggedItem] = newMedia.splice(draggedMediaIndex, 1);
    newMedia.splice(targetIndex, 0, draggedItem);
    setMediaItems(newMedia);
    setDraggedMediaIndex(null);
    setDragOverMediaIndex(null);
  };

  const handleMoveMedia = (idx: number, direction: 'left' | 'right') => {
    const targetIdx = direction === 'left' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= mediaItems.length) return;
    const newMedia = [...mediaItems];
    const [moved] = newMedia.splice(idx, 1);
    newMedia.splice(targetIdx, 0, moved);
    setMediaItems(newMedia);
  };

  const handleSetPrimaryMedia = (idx: number) => {
    if (idx === 0) return;
    const newMedia = [...mediaItems];
    const [moved] = newMedia.splice(idx, 1);
    newMedia.unshift(moved);
    setMediaItems(newMedia);
  };

  const handleUpdateLocationTag = (id: string, locationTag: PhotoLocationTag) => {
    setMediaItems(mediaItems.map(m => m.id === id ? { ...m, locationTag } : m));
  };

  // --- File Handlers ---
  const handleMediaFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const isVideo = file.type.startsWith('video');
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        const newItem: VehicleMediaItem = {
          id: `med-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          type: isVideo ? 'video' : 'photo',
          url: result,
          title: newMediaTitle || file.name,
          createdAt: new Date().toISOString()
        };
        setMediaItems(prev => [newItem, ...prev]);
        setNewMediaTitle('');
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDeleteMedia = (id: string) => {
    setMediaItems(prev => prev.filter(m => m.id !== id));
  };

  const handleDocFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;

        // Auto format file name by nature and auto set SIV status
        const immatLabel = registration.trim() ? registration.trim().toUpperCase() : 'VEHICULE';
        let formattedName = file.name;
        if (selectedDocCategory === 'carte_grise') {
          formattedName = `Carte_Grise_${immatLabel}_${file.name}`;
          setCarteGrise('complet');
        } else if (selectedDocCategory === 'non_gage') {
          formattedName = `Certificat_Non_Gage_${immatLabel}_${file.name}`;
          setCertificatNonGage('complet');
        } else if (selectedDocCategory === 'ct') {
          formattedName = `Controle_Technique_${immatLabel}_${file.name}`;
          setControleTechnique('complet');
        } else if (selectedDocCategory === 'mandat') {
          formattedName = `Mandat_Vente_${immatLabel}_${file.name}`;
          setMandatVente('complet');
        } else if (selectedDocCategory === 'cession') {
          formattedName = `Certificat_Cession_${immatLabel}_${file.name}`;
          setCertificatCession('complet');
        } else if (selectedDocCategory === 'facture') {
          setFactureAchat('complet');
        }

        const newDoc: VehicleDocumentFile = {
          id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          name: formattedName,
          type: file.type || 'application/octet-stream',
          category: selectedDocCategory,
          url: result,
          uploadDate: new Date().toISOString().slice(0, 10),
          size: `${(file.size / (1024 * 1024)).toFixed(2)} Mo`,
          notes: newDocNotes || undefined
        };
        setDocumentFiles(prev => [newDoc, ...prev]);
        setNewDocNotes('');
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDeleteDocFile = (id: string) => {
    setDocumentFiles(prev => prev.filter(d => d.id !== id));
  };

  const handleDamagePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setDamageMediaUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAddDamage = () => {
    if (!damageTitle.trim()) return;

    const newDamage: VehicleDamageItem = {
      id: `dmg-${Date.now()}`,
      title: damageTitle.trim(),
      location: damageLocation.trim() || 'Carrosserie',
      severity: damageSeverity,
      estimatedRepairCost: Number(damageRepairCost) || 0,
      repaired: damageRepaired,
      notes: damageNotes.trim() || undefined,
      mediaUrl: damageMediaUrl || undefined,
      mediaType: 'photo',
      createdAt: new Date().toISOString()
    };

    setDamages(prev => [newDamage, ...prev]);

    // Reset inputs
    setDamageTitle('');
    setDamageLocation('');
    setDamageRepairCost(0);
    setDamageRepaired(false);
    setDamageNotes('');
    setDamageMediaUrl(null);
  };

  const handleDeleteDamage = (id: string) => {
    setDamages(prev => prev.filter(d => d.id !== id));
  };

  const handleToggleDamageRepaired = (id: string) => {
    setDamages(prev => prev.map(d => d.id === id ? { ...d, repaired: !d.repaired } : d));
  };

  const handleAddOption = () => {
    if (!newOptionInput.trim()) return;
    setKeyOptions([...keyOptions, newOptionInput.trim()]);
    setNewOptionInput('');
  };

  const handleRemoveOption = (index: number) => {
    setKeyOptions(keyOptions.filter((_, i) => i !== index));
  };

  // Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const effectivePurchasePrice = businessType === 'depot_vente' 
      ? Number(sellerDesiredPrice) 
      : Number(purchasePrice);

    // Extract images list in exact order
    const imagesList = mediaItems.filter(m => m.type === 'photo').map(m => m.url);
    if (imagesList.length === 0 && vehicle?.images?.length) {
      imagesList.push(...vehicle.images);
    }

    const payload: Partial<Vehicle> = {
      ...(vehicle || {}),
      brand,
      model,
      version,
      registration: registration.toUpperCase(),
      vin: vin.toUpperCase(),
      year: toNum(yearStr) || new Date().getFullYear(),
      firstRegistrationDate,
      mileage: toNum(mileageStr),
      fuel,
      gearbox,
      powerDin: toNum(powerDinStr),
      powerFiscal: toNum(powerFiscalStr),
      critAir: Number(critAir),
      colorExterior,
      colorInterior,
      businessType,
      sellerId: businessType === 'depot_vente' && sellerId ? sellerId : undefined,
      seller: businessType === 'depot_vente' && sellerId ? sellers.find(s => s.id === sellerId) : undefined,
      sellerDesiredPrice: businessType === 'depot_vente' ? Number(sellerDesiredPrice) : undefined,
      brokerageFee: businessType === 'depot_vente' ? Math.max(0, netMargin) : undefined,
      status,
      location,
      guarantee,
      warrantyInitialMonths,
      warrantyExtensionMonths: hasWarrantyExtension ? warrantyExtensionMonths : 0,
      warrantyExtensionCost: hasWarrantyExtension ? warrantyExtensionCost : 0,
      warrantyProvider: hasWarrantyExtension ? warrantyProvider : undefined,
      monthlyEstimate: Number(monthlyEstimate),
      sellingPrice: Number(sellingPrice),
      tvaRegime,
      tvaRate,
      images: imagesList,
      mediaItems,
      costs: {
        purchasePrice: effectivePurchasePrice,
        transport: Number(transport),
        reconditioning: Number(reconditioning),
        detailing: Number(detailing),
        inspection: Number(inspection),
        adminFees: Number(adminFees),
        warrantyCost: Number(warrantyCost),
        customCosts: vehicle?.costs?.customCosts || []
      },
      documents: {
        ...(vehicle?.documents || { files: [] }),
        carteGrise,
        certificatCession,
        certificatNonGage,
        controleTechnique,
        bonCommande,
        factureAchat,
        factureVente: vehicle?.documents?.factureVente || 'en_attente',
        mandatVente: businessType === 'depot_vente' ? mandatVente : 'non_requis',
        doubleDesCles,
        carnetEntretien,
        files: documentFiles.map(d => ({
          id: d.id,
          name: d.name,
          type: d.type,
          uploadDate: d.uploadDate,
          size: d.size,
          url: d.url
        }))
      },
      documentFiles,
      damages,
      keyOptions,
      entryDate: vehicle?.entryDate || new Date().toISOString().split('T')[0]
    };

    onSave(payload);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-6 flex flex-col max-h-[94vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
              <Car className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                {isEditing ? `${vehicle.brand} ${vehicle.model}` : 'Ajouter un Véhicule au Stock'}
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                  businessType === 'depot_vente' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                }`}>
                  {businessType === 'depot_vente' ? 'Dépôt-Vente (Mandat)' : 'Achat-Revente (Propre)'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Gestion complète : prix de vente, net vendeur souhaité, marge calculée, photos/vidéos, documents et état des dommages.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Step Progression Bar */}
        <div className="px-4 sm:px-6 py-3 border-b border-slate-800 bg-slate-950/60 shrink-0">
          <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 text-xs">
            {stepsConfig.map((s) => {
              const isCurrent = step === s.num;
              const isPassed = step > s.num;
              return (
                <button
                  key={s.num}
                  type="button"
                  onClick={() => setStep(s.num)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
                    isCurrent 
                      ? 'bg-amber-400 text-slate-950 shadow-md ring-2 ring-amber-400/40' 
                      : isPassed
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/25'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-black ${
                    isCurrent 
                      ? 'bg-slate-950 text-amber-400' 
                      : isPassed 
                        ? 'bg-emerald-500 text-slate-950' 
                        : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isPassed ? '✓' : s.num}
                  </span>
                  <div className="text-left">
                    <div className="leading-tight">{s.title}</div>
                    <div className={`text-[10px] font-normal leading-tight hidden sm:block ${
                      isCurrent ? 'text-slate-900/80 font-semibold' : 'text-slate-500'
                    }`}>
                      {s.desc}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Modal Form Content */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1">
          


          {/* STEP 1: CARACTÉRISTIQUES DU VÉHICULE (GÉNÈRE LA FICHE VÉHICULE) */}
          {step === 1 && (
            <div className="space-y-5">
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Car className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-white">Étape 1 sur 5 : Spécifications et Identification du Véhicule</span>
                </div>
                <span className="text-[11px] text-amber-300/80 font-medium">Génère automatiquement les caractéristiques de la fiche</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Marque *</label>
                  <input
                    type="text"
                    required
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    placeholder="ex: Porsche, Audi, Peugeot"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Modèle *</label>
                  <input
                    type="text"
                    required
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="ex: Macan, RS3 Sportback, 3008"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Version & Finition détaillée *</label>
                  <input
                    type="text"
                    required
                    value={version}
                    onChange={(e) => setVersion(e.target.value)}
                    placeholder="ex: GTS 2.9 V6 Biturbo 440 ch PDK 7"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Immatriculation *</label>
                  <input
                    type="text"
                    required
                    value={registration}
                    onChange={(e) => setRegistration(e.target.value)}
                    placeholder="ex: FK-421-MP"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white uppercase font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Numéro VIN (Châssis)</label>
                  <input
                    type="text"
                    value={vin}
                    onChange={(e) => setVin(e.target.value)}
                    placeholder="ex: WP1ZZZ95ZNLB12894"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white uppercase font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Année Modèle</label>
                  <input
                    type="number"
                    value={yearStr}
                    onChange={(e) => setYearStr(e.target.value)}
                    placeholder="2024"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">1ère Mise en Circulation</label>
                  <input
                    type="date"
                    value={firstRegistrationDate}
                    onChange={(e) => setFirstRegistrationDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Kilométrage (km) *</label>
                  <input
                    type="number"
                    required
                    value={mileageStr}
                    onChange={(e) => setMileageStr(e.target.value)}
                    placeholder="0"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Carburant</label>
                  <select
                    value={fuel}
                    onChange={(e) => setFuel(e.target.value as FuelType)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="Essence">Essence</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Hybride">Hybride</option>
                    <option value="Hybride Rechargeable">Hybride Rechargeable</option>
                    <option value="Électrique">Électrique</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Boîte de Vitesses</label>
                  <select
                    value={gearbox}
                    onChange={(e) => setGearbox(e.target.value as GearboxType)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="Automatique">Automatique</option>
                    <option value="Manuelle">Manuelle</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Puissance (ch / CV)</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={powerDinStr}
                      onChange={(e) => setPowerDinStr(e.target.value)}
                      placeholder="ch Din"
                      className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-xs text-white tabular-nums"
                    />
                    <input
                      type="number"
                      value={powerFiscalStr}
                      onChange={(e) => setPowerFiscalStr(e.target.value)}
                      placeholder="CV Fisc"
                      className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-xs text-white tabular-nums"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Statut du Véhicule</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as VehicleStatus)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="en_stock">En stock (Visible en parc)</option>
                    <option value="en_preparation">En préparation atelier</option>
                    <option value="en_arrivage">En arrivage / Transit</option>
                    <option value="reserve">Réservé (Acompte versé)</option>
                    <option value="vendu">Vendu</option>
                    <option value="livre">Livré au client</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Emplacement Parc</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Showroom Principal, Emplacement B4..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Crit'Air & Teinte</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min="0"
                      max="5"
                      value={critAir}
                      onChange={(e) => setCritAir(Number(e.target.value))}
                      placeholder="Crit'Air"
                      className="w-1/3 bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-xs text-white"
                    />
                    <input
                      type="text"
                      value={colorExterior}
                      onChange={(e) => setColorExterior(e.target.value)}
                      placeholder="Couleur"
                      className="w-2/3 bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Step 1 Navigation Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <span>Prochaine Étape : Chiffres & Finances</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}



          {/* STEP 2: LES CHIFFRES & FINANCES (MARGES, FRAIS ATELIER & COÛT MEHDI) */}
          {step === 2 && (
            <div className="space-y-6">
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold text-white">Étape 2 sur 5 : Chiffres, Marges & Coûts de Préparation (Coût Mehdi)</span>
                </div>
                <span className="text-[11px] text-emerald-300 font-medium">Calcul en direct du gain net</span>
              </div>
              
              {/* Dynamic Profitability Banner */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                      <Calculator className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        {businessType === 'depot_vente' ? 'Commission & Marge Nette Courtier (Dépôt-Vente)' : 'Marge Nette Achat-Revente'}
                      </div>
                      <div className="text-xl font-extrabold text-white tabular-nums">
                        Gain Net Estimé : <span className={netMargin >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          +{netMargin.toLocaleString('fr-FR')} € ({marginPercentage.toFixed(1)}%)
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right text-xs">
                    <div className="text-slate-400">Prix de vente TTC affiché : <strong className="text-amber-400 tabular-nums">{sellingPrice.toLocaleString('fr-FR')} €</strong></div>
                    <div className="text-slate-400">
                      {businessType === 'depot_vente' 
                        ? `Montant net vendeur : ${sellerDesiredPrice.toLocaleString('fr-FR')} €` 
                        : `Prix d'achat : ${purchasePrice.toLocaleString('fr-FR')} €`}
                    </div>
                  </div>
                </div>

                {/* Calculation Explainer Strip */}
                <div className="p-3 bg-slate-900/80 rounded-xl text-xs space-y-1.5 border border-slate-800/80 text-slate-300">
                  {businessType === 'depot_vente' ? (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px]">
                      <span>1. Prix Vente ({sellingPrice.toLocaleString('fr-FR')} €) - Montant Vendeur ({sellerDesiredPrice.toLocaleString('fr-FR')} €) = <strong>Commission brute {grossMargin.toLocaleString('fr-FR')} €</strong></span>
                      <span>2. Frais préparation engagés garage ({totalPrepFees.toLocaleString('fr-FR')} €) = <strong className="text-emerald-400">Marge nette finale {netMargin.toLocaleString('fr-FR')} €</strong></span>
                    </div>
                  ) : (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px]">
                      <span>Prix de vente ({sellingPrice.toLocaleString('fr-FR')} €) - (Achat {purchasePrice.toLocaleString('fr-FR')} € + Total Frais {totalPrepFees.toLocaleString('fr-FR')} €)</span>
                      <span>= <strong className="text-emerald-400">Marge brute & nette {netMargin.toLocaleString('fr-FR')} € ({marginPercentage.toFixed(1)}%)</strong></span>
                    </div>
                  )}
                </div>
              </div>

              {/* Main Inputs Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Acquisition Base (Seller Desired Price vs Purchase Price) */}
                <div className="space-y-4">
                  <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-amber-400" />
                    Base d'Acquisition & Vendeur
                  </h3>

                  {businessType === 'depot_vente' ? (
                    <div className="p-4 bg-purple-950/20 border border-purple-500/30 rounded-xl space-y-2">
                      <label className="block text-xs font-bold text-purple-300">
                        Montant Souhaité par le Client Vendeur Net (€) *
                      </label>
                      <input
                        type="number"
                        required
                        value={sellerDesiredPriceStr}
                        onChange={(e) => setSellerDesiredPriceStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-purple-500/40 rounded-lg px-3 py-2 text-sm font-bold text-purple-200 tabular-nums focus:outline-none focus:ring-1 focus:ring-purple-400"
                      />
                      <span className="text-[11px] text-purple-400 block leading-tight">
                        C'est la somme exacte nette qui sera reversée au propriétaire après dénouement de la vente sous mandat.
                      </span>
                    </div>
                  ) : (
                    <div className="p-4 bg-blue-950/20 border border-blue-500/30 rounded-xl space-y-2">
                      <label className="block text-xs font-bold text-blue-300">
                        Prix d'Achat Net du Véhicule (€) *
                      </label>
                      <input
                        type="number"
                        required
                        value={purchasePriceStr}
                        onChange={(e) => setPurchasePriceStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-blue-500/40 rounded-lg px-3 py-2 text-sm font-bold text-blue-200 tabular-nums focus:outline-none focus:ring-1 focus:ring-blue-400"
                      />
                      <span className="text-[11px] text-blue-400 block leading-tight">
                        Montant déboursé par votre société pour acquérir le véhicule en stock propre.
                      </span>
                    </div>
                  )}

                  {/* Pricing Inputs */}
                  <div className="space-y-3 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">
                        Prix de Vente TTC Affiché (€) *
                      </label>
                      <input
                        type="number"
                        required
                        value={sellingPriceStr}
                        onChange={(e) => setSellingPriceStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm font-bold text-amber-400 tabular-nums focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs text-slate-400 mb-1">Régime Fiscal</label>
                        <select
                          value={tvaRegime}
                          onChange={(e) => setTvaRegime(e.target.value as 'marge' | 'standard')}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                        >
                          <option value="marge">TVA sur marge d'occasion (Art. 297 A CGI)</option>
                          <option value="standard">TVA standard sur prix total</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-slate-400 mb-1">Simulation Financement (€/m)</label>
                        <input
                          type="number"
                          value={monthlyEstimateStr}
                          onChange={(e) => setMonthlyEstimateStr(e.target.value)}
                          placeholder="0"
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                        />
                      </div>
                    </div>

                    {/* French Tax Authority (DGFiP) TVA Rate Toggles */}
                    <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                          <Percent className="w-3.5 h-3.5 text-amber-400" />
                          Taux de TVA Fisc Français : <strong className="text-amber-400">{tvaRate}%</strong>
                        </label>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {tvaRate === 20 ? 'Taux normal standard' :
                           tvaRate === 8.5 ? 'Taux spécifique DOM' :
                           tvaRate === 10 ? 'Taux intermédiaire' :
                           tvaRate === 5.5 ? 'Taux réduit' :
                           tvaRate === 2.1 ? 'Taux super-réduit' : 'Exonération fiscale'}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5">
                        {[
                          { rate: 20, label: '20 % (Normal)' },
                          { rate: 10, label: '10 % (Interm.)' },
                          { rate: 8.5, label: '8,5 % (DOM)' },
                          { rate: 5.5, label: '5,5 % (Réduit)' },
                          { rate: 2.1, label: '2,1 % (Super-r.)' },
                          { rate: 0, label: '0 % (Exonéré)' },
                        ].map(item => (
                          <button
                            key={item.rate}
                            type="button"
                            onClick={() => setTvaRate(item.rate)}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                              tvaRate === item.rate
                                ? 'bg-amber-400 text-slate-950 shadow-sm'
                                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>

                      <div className="pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-300">
                        <span>{tvaRegime === 'marge' ? 'TVA estimée reversable sur la marge :' : 'TVA brute incluse dans le prix :'}</span>
                        <strong className="text-amber-400 font-mono tabular-nums">
                          {Math.round(tvaAmount).toLocaleString('fr-FR')} €
                        </strong>
                      </div>
                    </div>

                  </div>
                </div>

                {/* Preparation & Reconditioning Cost Breakdown */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                      <Wrench className="w-4 h-4 text-slate-400" />
                      Frais de Remise en État & Garantie ({totalPrepFees.toLocaleString('fr-FR')} €)
                    </h3>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Transport / Convoyage (€)</label>
                      <input
                        type="number"
                        value={transportStr}
                        onChange={(e) => setTransportStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-amber-300 mb-1 flex items-center justify-between">
                        <span>Coût Mehdi / Atelier (€)</span>
                        <span className="text-[10px] text-amber-400 font-normal">Frais atelier Mehdi</span>
                      </label>
                      <input
                        type="number"
                        value={reconditioningStr}
                        onChange={(e) => setReconditioningStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-amber-500/40 rounded-lg px-3 py-2 text-xs text-amber-300 font-bold tabular-nums focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Carrosserie & Detailing (€)</label>
                      <input
                        type="number"
                        value={detailingStr}
                        onChange={(e) => setDetailingStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Contrôle Technique (€)</label>
                      <input
                        type="number"
                        value={inspectionStr}
                        onChange={(e) => setInspectionStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Frais Admin & SIV (€)</label>
                      <input
                        type="number"
                        value={adminFeesStr}
                        onChange={(e) => setAdminFeesStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Garantie Commerciale (€)</label>
                      <input
                        type="number"
                        value={warrantyCostStr}
                        onChange={(e) => setWarrantyCostStr(e.target.value)}
                        placeholder="0"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                      />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs space-y-1 text-slate-400">
                    <div className="flex justify-between">
                      <span>Total des frais annexes engagés :</span>
                      <strong className="text-white tabular-nums">{totalPrepFees.toLocaleString('fr-FR')} €</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Impact direct sur la rentabilité :</span>
                      <strong className="text-amber-400 tabular-nums">Défalqué de la commission</strong>
                    </div>
                  </div>
                </div>

              </div>

              {/* Step 4 Navigation Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Précédente Étape : Fiche Véhicule</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <span>Prochaine Étape : Type & Mandat Vendeur</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}


          {/* STEP 3: TYPE DE VENTE & CLIENT VENDEUR DÉPOSANT (MANDAT DE VENTE) */}
          {step === 3 && (
            <div className="space-y-6">
              <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileSignature className="w-4 h-4 text-purple-400" />
                  <span className="text-xs font-bold text-white">Étape 3 sur 5 : Type de Vente & Mandat Client Vendeur</span>
                </div>
                <span className="text-[11px] text-purple-300 font-medium">Génère le mandat de vente officiel prêt à faire signer</span>
              </div>

              {/* Mode Commercial : Achat-Revente vs Dépôt-Vente */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Mode de Commercialisation du Véhicule *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setBusinessType('achat_revente')}
                    className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                      businessType === 'achat_revente'
                        ? 'bg-blue-500/15 border-blue-500 text-white shadow-md ring-1 ring-blue-500/50'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-bold text-sm text-white">Achat - Revente</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300">Stock Propre</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Véhicule acquis directement par le garage TBD AUTOS. Aucun mandat client vendeur n'est requis.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setBusinessType('depot_vente')}
                    className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                      businessType === 'depot_vente'
                        ? 'bg-purple-500/15 border-purple-500 text-white shadow-md ring-1 ring-purple-500/50'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-bold text-sm text-white">Dépôt - Vente</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300">Mandat Requis</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Mandat d'intermédiaire commercial confié par un propriétaire (client particulier ou professionnel).
                    </p>
                  </button>
                </div>
              </div>

              {/* Si Dépôt-Vente : Choix entre Client Existant ou Nouveau Client */}
              {businessType === 'depot_vente' ? (
                <div className="space-y-4">
                  {/* Mode selector: Existant vs Nouveau */}
                  <div className="p-1 bg-slate-950 border border-slate-800 rounded-xl grid grid-cols-2 gap-1 text-xs">
                    <button
                      type="button"
                      onClick={() => setSellerMode('existing')}
                      className={`py-2 px-3 rounded-lg font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                        sellerMode === 'existing'
                          ? 'bg-purple-600 text-white shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <User className="w-3.5 h-3.5" />
                      <span>1. Client Vendeur Déjà Existant</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSellerMode('new')}
                      className={`py-2 px-3 rounded-lg font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                        sellerMode === 'new'
                          ? 'bg-purple-600 text-white shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>2. Nouveau Client Vendeur</span>
                    </button>
                  </div>

                  {/* Mode 1: Client Déjà Existant */}
                  {sellerMode === 'existing' && (
                    <div className="p-4 bg-purple-950/20 border border-purple-500/30 rounded-xl space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-purple-400" />
                          Sélectionner le Client Vendeur Déposant dans la base *
                        </label>
                        <span className="text-[11px] text-purple-400">
                          {sellers.length} vendeur(s) enregistré(s)
                        </span>
                      </div>

                      <select
                        value={sellerId}
                        onChange={(e) => setSellerId(e.target.value)}
                        className="w-full bg-slate-950 border border-purple-500/40 rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-400 font-semibold"
                      >
                        <option value="">-- Choisir un client vendeur enregistré --</option>
                        {sellers.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} {s.companyName ? `(${s.companyName})` : ''} — Tél : {s.phone} ({s.type === 'professionnel' ? 'Société' : 'Particulier'})
                          </option>
                        ))}
                      </select>

                      {selectedSeller ? (
                        <div className="p-3 bg-slate-900 border border-purple-500/30 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-sm">{selectedSeller.name}</span>
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-purple-950 text-purple-300 border border-purple-800">
                                {selectedSeller.type === 'professionnel' ? 'Société Pro' : 'Particulier'}
                              </span>
                            </div>
                            <div className="text-slate-400 text-[11px] flex flex-wrap items-center gap-x-3">
                              <span>Tél: <strong className="text-slate-200">{selectedSeller.phone}</strong></span>
                              <span>Mail: <strong className="text-slate-200">{selectedSeller.email}</strong></span>
                              {selectedSeller.city && <span>Ville: <strong className="text-slate-200">{selectedSeller.postalCode} {selectedSeller.city}</strong></span>}
                            </div>
                            {selectedSeller.rib && (
                              <div className="text-[10px] text-slate-500 font-mono">
                                IBAN virement net : {selectedSeller.rib}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            {selectedSeller.idDocumentFile && (
                              <button
                                type="button"
                                onClick={() => setViewingSellerDoc({
                                  title: `Pièce d'identité - ${selectedSeller.name}`,
                                  url: selectedSeller.idDocumentFile?.url,
                                  type: selectedSeller.idDocumentFile?.type || 'application/pdf'
                                })}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-blue-300 bg-blue-950 hover:bg-blue-900 border border-blue-800 rounded-lg cursor-pointer"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Voir CNI</span>
                              </button>
                            )}
                            {selectedSeller.type === 'professionnel' && selectedSeller.kbisFile && (
                              <button
                                type="button"
                                onClick={() => setViewingSellerDoc({
                                  title: `Extrait KBIS - ${selectedSeller.companyName || selectedSeller.name}`,
                                  url: selectedSeller.kbisFile?.url,
                                  type: selectedSeller.kbisFile?.type || 'application/pdf'
                                })}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-purple-300 bg-purple-950 hover:bg-purple-900 border border-purple-800 rounded-lg cursor-pointer"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Voir KBIS</span>
                              </button>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="p-3 bg-slate-900/60 border border-dashed border-slate-800 rounded-xl text-center text-xs text-slate-500">
                          Sélectionnez un vendeur ci-dessus ou basculez sur "Nouveau Client Vendeur" pour en créer un nouveau.
                        </div>
                      )}
                    </div>
                  )}

                  {/* Mode 2: Nouveau Client Vendeur Form */}
                  {sellerMode === 'new' && (
                    <div className="p-4 bg-purple-950/20 border border-purple-500/40 rounded-xl space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-purple-400" />
                          Informations du Nouveau Client Vendeur Déposant
                        </h4>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => setNewSellerType('particulier')}
                            className={`px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer ${
                              newSellerType === 'particulier' ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            Particulier
                          </button>
                          <button
                            type="button"
                            onClick={() => setNewSellerType('professionnel')}
                            className={`px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer ${
                              newSellerType === 'professionnel' ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            Société / Pro
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">
                            {newSellerType === 'professionnel' ? 'Raison Sociale *' : 'Nom du Vendeur *'}
                          </label>
                          <input
                            type="text"
                            value={newSellerName}
                            onChange={(e) => setNewSellerName(e.target.value)}
                            placeholder={newSellerType === 'professionnel' ? 'ex: SARL TRANSPORTS DUPONT' : 'ex: DUPONT'}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-400 font-semibold"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">
                            {newSellerType === 'professionnel' ? 'Nom du Dirigeant / Représentant' : 'Prénom'}
                          </label>
                          <input
                            type="text"
                            value={newSellerFirstName}
                            onChange={(e) => setNewSellerFirstName(e.target.value)}
                            placeholder="ex: Jean-Marc"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-400"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">Téléphone *</label>
                          <input
                            type="tel"
                            value={newSellerPhone}
                            onChange={(e) => setNewSellerPhone(e.target.value)}
                            placeholder="06 12 34 56 78"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-400 font-semibold"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">Email</label>
                          <input
                            type="email"
                            value={newSellerEmail}
                            onChange={(e) => setNewSellerEmail(e.target.value)}
                            placeholder="vendeur@email.com"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-400"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="sm:col-span-2">
                          <label className="block text-xs font-medium text-slate-300 mb-1">Adresse Postale</label>
                          <input
                            type="text"
                            value={newSellerAddress}
                            onChange={(e) => setNewSellerAddress(e.target.value)}
                            placeholder="12 Avenue des Vignes"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-400"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">Code Postal & Ville</label>
                          <div className="flex gap-1.5">
                            <input
                              type="text"
                              value={newSellerPostalCode}
                              onChange={(e) => setNewSellerPostalCode(e.target.value)}
                              placeholder="33000"
                              className="w-20 bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-xs text-white"
                            />
                            <input
                              type="text"
                              value={newSellerCity}
                              onChange={(e) => setNewSellerCity(e.target.value)}
                              placeholder="Bordeaux"
                              className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-xs text-white"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">
                            {newSellerType === 'professionnel' ? 'SIREN / SIRET' : 'N° Pièce d’Identité (CNI / Passeport)'}
                          </label>
                          <input
                            type="text"
                            value={newSellerIdNumber}
                            onChange={(e) => setNewSellerIdNumber(e.target.value)}
                            placeholder={newSellerType === 'professionnel' ? 'ex: 812 345 678 00012' : 'ex: 180533100245'}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-400 font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">IBAN / RIB pour virement net</label>
                          <input
                            type="text"
                            value={newSellerRib}
                            onChange={(e) => setNewSellerRib(e.target.value)}
                            placeholder="FR76 3000 4000 5000 6000 7000 123"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-purple-400 font-mono"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[11px] text-slate-400">
                          Ce vendeur sera sauvegardé dans votre répertoire clients pour vos futurs mandats.
                        </span>
                        <button
                          type="button"
                          onClick={handleSaveNewSeller}
                          className="px-3.5 py-2 text-xs font-bold text-white bg-purple-600 hover:bg-purple-500 rounded-lg shadow cursor-pointer transition-colors flex items-center gap-1.5"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{sellerSavedSuccess ? 'Vendeur Enregistré !' : 'Enregistrer ce Vendeur'}</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* MANDAT DE VENTE PRÉ-REMPLI BANNER & ACTION */}
                  <div className="p-4 bg-gradient-to-r from-purple-950/40 via-slate-900 to-amber-950/30 border border-purple-500/40 rounded-xl space-y-3 shadow-lg">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 flex items-center justify-center shrink-0">
                          <FileSignature className="w-5 h-5 text-purple-300" />
                        </div>
                        <div>
                          <h4 className="text-sm font-extrabold text-white flex items-center gap-2">
                            <span>Mandat de Vente Conforme TBD AUTOS</span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              Pré-rempli Automatiquement
                            </span>
                          </h4>
                          <p className="text-xs text-purple-300/90 leading-relaxed mt-0.5">
                            Le document officiel (exemplaire en pièce jointe) est généré avec les caractéristiques du véhicule ({brand || 'Véhicule'} {model || ''} - {registration || 'Immat'}) et l'identité du client vendeur ({sellerMode === 'existing' && selectedSeller ? selectedSeller.name : newSellerName || 'Client Vendeur'}).
                          </p>
                        </div>
                      </div>

                      {onOpenSalesMandate && (
                        <button
                          type="button"
                          onClick={handlePreviewSalesMandate}
                          className="px-4 py-2.5 text-xs font-black text-white bg-purple-600 hover:bg-purple-500 rounded-xl shadow-lg hover:shadow-purple-600/30 transition-all cursor-pointer flex items-center justify-center gap-2 shrink-0 active:scale-95"
                          title="Prévisualiser et imprimer l'exemplaire du mandat de vente pré-rempli"
                        >
                          <FileText className="w-4 h-4 text-purple-200" />
                          <span>📄 Prévisualiser / Imprimer le Mandat</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-5 bg-blue-950/20 border border-blue-500/30 rounded-xl flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-400 shrink-0" />
                  <div className="text-xs text-slate-300">
                    <strong className="text-white block font-semibold mb-0.5">Véhicule Achat-Revente (Stock Propre)</strong>
                    Ce véhicule est la propriété directe du garage TBD AUTOS. Aucun mandat de vente tiers n'est requis. Passez directement à l'étape suivante pour importer les photos.
                  </div>
                </div>
              )}

              {/* Step 2 Navigation Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Précédente Étape : Chiffres & Finances</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <span>Prochaine Étape : Photos & Médias</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}



          {/* STEP 4: PHOTOS & MÉDIAS (GLISSER POUR RÉORGANISER) & DOMMAGES CONSTATÉS */}
          {step === 4 && (
            <div className="space-y-6">
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Camera className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-white">Étape 4 sur 5 : Photos, Vidéos & Relevé des Dommages</span>
                </div>
                <span className="text-[11px] text-amber-300 font-medium">Glissez les photos pour changer l'ordre (la 1ère sera l'affiche)</span>
              </div>
          {/* Médias & Photos */}
              
              {/* Upload Box */}
              <div className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <Camera className="w-4 h-4 text-amber-400" />
                      Ajouter des Photos ou Vidéos du Véhicule
                    </h3>
                    <p className="text-xs text-slate-400">
                      Importez vos photos professionnelles ou vidéos de tour du véhicule (formats JPG, PNG, WebP, MP4, WebM).
                    </p>
                  </div>

                  <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors cursor-pointer shrink-0 shadow-md">
                    <Upload className="w-4 h-4" />
                    <span>Sélectionner Fichiers (Photos / Vidéos)</span>
                    <input
                      type="file"
                      accept="image/*,video/*"
                      multiple
                      onChange={handleMediaFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={newMediaTitle}
                    onChange={(e) => setNewMediaTitle(e.target.value)}
                    placeholder="Légende personnalisée (ex: Vue 3/4 avant, Sellerie cuir, Compteur, Vidéo son échappement...)"
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              {/* Gallery of Uploaded Media */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 mb-3 flex items-center justify-between">
                  <span>Médias Actuels ({mediaItems.length})</span>
                  <span className="text-[11px] text-slate-500">La 1ère photo sert d'image principale sur les fiches et affiches</span>
                </h4>

                {mediaItems.length === 0 ? (
                  <div className="p-12 text-center bg-slate-950/60 border border-dashed border-slate-800 rounded-2xl space-y-2">
                    <Camera className="w-8 h-8 text-slate-600 mx-auto" />
                    <div className="text-xs text-slate-400">Aucune photo ou vidéo uploadée pour le moment.</div>
                    <div className="text-[11px] text-slate-500">Utilisez le bouton ci-dessus pour importer depuis votre appareil.</div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {mediaItems.map((item, idx) => (
                      <div
                        key={item.id}
                        draggable
                        onDragStart={(e) => handleMediaDragStart(e, idx)}
                        onDragOver={(e) => handleMediaDragOver(e, idx)}
                        onDrop={(e) => handleMediaDrop(e, idx)}
                        onDragEnd={() => {
                          setDraggedMediaIndex(null);
                          setDragOverMediaIndex(null);
                        }}
                        className={`group relative bg-slate-950 border rounded-xl overflow-hidden flex flex-col transition-all cursor-grab active:cursor-grabbing ${
                          dragOverMediaIndex === idx 
                            ? 'border-amber-400 ring-2 ring-amber-400/50 scale-[1.02] shadow-xl' 
                            : draggedMediaIndex === idx 
                              ? 'opacity-40 border-slate-700' 
                              : 'border-slate-800 hover:border-slate-700'
                        }`}
                        title="Glisser-déposer pour changer la position de la photo"
                      >
                        <div className="aspect-16/9 bg-slate-900 relative overflow-hidden">
                          {item.type === 'video' ? (
                            <video
                              src={item.url}
                              controls
                              className="w-full h-full object-cover pointer-events-none"
                            />
                          ) : (
                            <img
                              src={item.url}
                              alt={item.title || 'Photo véhicule'}
                              className="w-full h-full object-cover pointer-events-none"
                              referrerPolicy="no-referrer"
                            />
                          )}

                          {/* Position Badge & Drag Handle */}
                          <div className="absolute top-2 left-2 flex items-center gap-1.5">
                            <span className="p-1 rounded bg-slate-950/80 text-slate-400 hover:text-amber-400 shadow cursor-grab" title="Glisser pour déplacer">
                              <GripVertical className="w-3.5 h-3.5" />
                            </span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              idx === 0 
                                ? 'bg-amber-400 text-slate-950 shadow-sm' 
                                : 'bg-slate-950/80 text-white'
                            }`}>
                              {idx === 0 ? '★ Couverture #1' : `#${idx + 1}`}
                            </span>

                            {item.locationTag && (
                              <span className="bg-slate-900/90 text-slate-300 border border-slate-700/80 px-1.5 py-0.5 rounded text-[9px] font-medium">
                                {item.locationTag === 'avant_3_4' ? 'Avant 3/4' :
                                 item.locationTag === 'arriere_3_4' ? 'Arrière 3/4' :
                                 item.locationTag === 'profil' ? 'Profil' :
                                 item.locationTag === 'interieur_poste' ? 'Poste de conduite' :
                                 item.locationTag === 'sieges' ? 'Sièges' :
                                 item.locationTag === 'compteur' ? 'Compteur' :
                                 item.locationTag === 'moteur' ? 'Moteur' :
                                 item.locationTag === 'coffre' ? 'Coffre' :
                                 item.locationTag === 'jantes' ? 'Jantes' : 'Détail'}
                              </span>
                            )}
                          </div>

                          <button
                            type="button"
                            onClick={() => handleDeleteMedia(item.id)}
                            className="absolute top-2 right-2 p-1.5 bg-rose-600/90 text-white rounded-lg hover:bg-rose-600 transition-colors cursor-pointer shadow"
                            title="Supprimer ce média"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Reordering Controls Bar at bottom of thumbnail */}
                          <div className="absolute bottom-2 inset-x-2 flex items-center justify-between gap-1.5 bg-slate-950/85 backdrop-blur-sm p-1 rounded-lg border border-slate-800 text-slate-300">
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                disabled={idx === 0}
                                onClick={() => handleMoveMedia(idx, 'left')}
                                className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                                  idx === 0 ? 'text-slate-600 cursor-not-allowed' : 'hover:bg-slate-800 text-white hover:text-amber-400'
                                }`}
                                title="Déplacer vers la gauche"
                              >
                                <ArrowLeft className="w-3.5 h-3.5" />
                              </button>
                              <span className="text-[10px] font-mono text-slate-400 font-bold">
                                {idx + 1}/{mediaItems.length}
                              </span>
                              <button
                                type="button"
                                disabled={idx === mediaItems.length - 1}
                                onClick={() => handleMoveMedia(idx, 'right')}
                                className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                                  idx === mediaItems.length - 1 ? 'text-slate-600 cursor-not-allowed' : 'hover:bg-slate-800 text-white hover:text-amber-400'
                                }`}
                                title="Déplacer vers la droite"
                              >
                                <ArrowRight className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {idx !== 0 && (
                              <button
                                type="button"
                                onClick={() => handleSetPrimaryMedia(idx)}
                                className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold text-amber-300 hover:text-amber-200 bg-amber-400/15 hover:bg-amber-400/25 rounded cursor-pointer transition-colors"
                                title="Définir comme photo principale de couverture"
                              >
                                <Star className="w-3 h-3 text-amber-400" />
                                <span>Mettre en #1</span>
                              </button>
                            )}
                          </div>
                        </div>

                        <div className="p-3 bg-slate-950 flex-1 flex flex-col justify-between space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-semibold text-slate-200 truncate block">
                              {item.title || `Photo ${idx + 1}`}
                            </span>
                            <span className="text-[10px] text-slate-500 shrink-0">
                              {new Date(item.createdAt).toLocaleDateString('fr-FR')}
                            </span>
                          </div>

                          {/* Location / Angle Tag Selector */}
                          <div>
                            <label className="block text-[10px] font-medium text-slate-400 mb-1 flex items-center gap-1">
                              <Tag className="w-3 h-3 text-amber-400" /> Emplacement / Angle du véhicule
                            </label>
                            <select
                              value={item.locationTag || 'avant_3_4'}
                              onChange={(e) => handleUpdateLocationTag(item.id, e.target.value as PhotoLocationTag)}
                              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-slate-200 focus:outline-none focus:ring-1 focus:ring-amber-400"
                            >
                              <option value="avant_3_4">Avant 3/4 (Vue principale)</option>
                              <option value="arriere_3_4">Arrière 3/4</option>
                              <option value="profil">Profil latéral</option>
                              <option value="interieur_poste">Poste de conduite / Tableau de bord</option>
                              <option value="sieges">Sellerie & Sièges avant/arrière</option>
                              <option value="compteur">Compteur & Tableau de bord</option>
                              <option value="moteur">Compartiment Moteur</option>
                              <option value="coffre">Coffre à bagages</option>
                              <option value="jantes">Jantes & Pneumatiques</option>
                              <option value="autre">Autre détail carrosserie</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
          {/* Relevé des Dommages & Réparations */}
              
              {/* Add Damage Form */}
              <div className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                      Signaler un Dommage / Défaut Carrosserie ou Mécanique
                    </h3>
                    <p className="text-xs text-slate-400">
                      Prenez ou uploadez des photos/vidéos de dommages (rayures, coups de portière, jantes frottées) avec chiffrage estimatif.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Description du dommage *</label>
                    <input
                      type="text"
                      value={damageTitle}
                      onChange={(e) => setDamageTitle(e.target.value)}
                      placeholder="ex: Rayure superficielle aile ARD"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Emplacement précis</label>
                    <input
                      type="text"
                      value={damageLocation}
                      onChange={(e) => setDamageLocation(e.target.value)}
                      placeholder="ex: Aile ARD, Jante AVD, Pare-brise..."
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Gravité</label>
                    <select
                      value={damageSeverity}
                      onChange={(e) => setDamageSeverity(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="mineur">Mineur (Léger lustrage / micro-rayure)</option>
                      <option value="moyen">Moyen (Carrosserie / Peinture partielle)</option>
                      <option value="important">Important (Pièce à remplacer / débosselage)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Coût estimé réparation (€)</label>
                    <input
                      type="number"
                      value={damageRepairCost}
                      onChange={(e) => setDamageRepairCost(Number(e.target.value))}
                      placeholder="0"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Photo / Vidéo du dommage</label>
                    <label className="flex items-center gap-2 px-3 py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg text-xs text-slate-300 cursor-pointer">
                      <Camera className="w-3.5 h-3.5 text-amber-400" />
                      <span className="truncate">{damageMediaUrl ? 'Photo jointe ✓' : 'Joindre une photo'}</span>
                      <input
                        type="file"
                        accept="image/*,video/*"
                        onChange={handleDamagePhotoUpload}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer py-2">
                      <input
                        type="checkbox"
                        checked={damageRepaired}
                        onChange={(e) => setDamageRepaired(e.target.checked)}
                        className="w-4 h-4 rounded text-amber-500"
                      />
                      Déjà réparé en atelier
                    </label>

                    <button
                      type="button"
                      onClick={handleAddDamage}
                      className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-lg transition-colors cursor-pointer shrink-0"
                    >
                      + Enregistrer dommage
                    </button>
                  </div>
                </div>
              </div>

              {/* List of Registered Damages */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 mb-3 flex items-center justify-between">
                  <span>Dommages Enregistrés ({damages.length})</span>
                  <span className="text-[11px] text-slate-500">
                    Total chiffré : <strong className="text-white">{damages.reduce((acc, d) => acc + (d.estimatedRepairCost || 0), 0)} €</strong>
                  </span>
                </h4>

                {damages.length === 0 ? (
                  <div className="p-8 text-center bg-slate-950/60 border border-slate-800 rounded-xl space-y-1">
                    <CheckCircle2 className="w-7 h-7 text-emerald-400 mx-auto" />
                    <div className="text-xs font-bold text-white">Aucun dommage signalé</div>
                    <div className="text-[11px] text-slate-400">Véhicule sans défaut majeur constaté.</div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {damages.map((dmg) => (
                      <div
                        key={dmg.id}
                        className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex gap-3 justify-between items-start"
                      >
                        {dmg.mediaUrl && (
                          <div className="w-16 h-16 rounded-lg overflow-hidden bg-slate-900 shrink-0 border border-slate-800">
                            <img src={dmg.mediaUrl} alt={dmg.title} className="w-full h-full object-cover" />
                          </div>
                        )}

                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-white">{dmg.title}</span>
                            <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold uppercase ${
                              dmg.severity === 'important' ? 'bg-rose-500/20 text-rose-300' :
                              dmg.severity === 'moyen' ? 'bg-amber-500/20 text-amber-300' : 'bg-blue-500/20 text-blue-300'
                            }`}>
                              {dmg.severity}
                            </span>
                          </div>

                          <div className="text-[11px] text-slate-400">
                            Emplacement : <span className="text-slate-300 font-medium">{dmg.location}</span>
                          </div>

                          <div className="flex items-center gap-3 text-xs pt-1">
                            <span className="font-bold text-amber-400 tabular-nums">
                              {dmg.estimatedRepairCost > 0 ? `${dmg.estimatedRepairCost} €` : 'Coût non chiffré'}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleToggleDamageRepaired(dmg.id)}
                              className={`text-[11px] px-2 py-0.5 rounded cursor-pointer font-medium ${
                                dmg.repaired ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {dmg.repaired ? '✓ Réparé' : 'À réparer'}
                            </button>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteDamage(dmg.id)}
                          className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Step 3 Navigation Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Précédente Étape : Type & Mandat Vendeur</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStep(5)}
                  className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <span>Prochaine Étape : Vitrine & Validation</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}


          {/* STEP 5: OPTIONS VITRINE, GARANTIES & DOCUMENTS ADMINISTRATIFS */}
          {step === 5 && (
            <div className="space-y-6">
              <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-bold text-white">Étape 5 sur 5 : Options Vitrine, Garanties Commerciales & Validation</span>
                </div>
                <span className="text-[11px] text-blue-300 font-medium">Paramètres d'affichage vitrine et conformité des pièces</span>
              </div>
          {/* Options Vitrine & Leviers de Garanties */}
              
              {/* Commercial Warranty Levers Module */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                        Garantie Commerciale & Extension (Leviers en Mois)
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Ajustez la durée initiale (1 à 12 mois) et ajoutez une extension complémentaire (4 à 36 mois).
                      </p>
                    </div>
                  </div>

                  <div className="text-left sm:text-right bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Durée Totale Couverte</span>
                    <span className="text-base font-extrabold text-amber-400 tabular-nums">
                      {warrantyInitialMonths + (hasWarrantyExtension ? warrantyExtensionMonths : 0)} mois
                    </span>
                  </div>
                </div>

                {/* Levier 1: Durée de la Garantie Commerciale Initiale (1 à 12 mois) */}
                <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-200">
                      1. Garantie Commerciale Initiale : <span className="text-emerald-400 text-sm font-extrabold">{warrantyInitialMonths} mois</span>
                    </label>

                    <div className="flex items-center gap-1">
                      {[1, 3, 6, 12].map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setWarrantyInitialMonths(m)}
                          className={`px-2.5 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                            warrantyInitialMonths === m
                              ? 'bg-emerald-500 text-slate-950 shadow-sm'
                              : 'bg-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          {m} m
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Range Slider 1 to 12 months */}
                  <input
                    type="range"
                    min={1}
                    max={12}
                    step={1}
                    value={warrantyInitialMonths}
                    onChange={(e) => setWarrantyInitialMonths(Number(e.target.value))}
                    className="w-full accent-emerald-400 cursor-pointer h-2 bg-slate-950 rounded-lg"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>1 mois (Légal min.)</span>
                    <span>3 mois</span>
                    <span>6 mois (Standard)</span>
                    <span>12 mois (Complet)</span>
                  </div>
                </div>

                {/* Levier 2: Supplément pour Extension de Garantie (4 à 36 mois) */}
                <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="modalToggleExt"
                        checked={hasWarrantyExtension}
                        onChange={(e) => setHasWarrantyExtension(e.target.checked)}
                        className="w-4 h-4 rounded accent-amber-400 cursor-pointer"
                      />
                      <label htmlFor="modalToggleExt" className="text-xs font-bold text-slate-200 cursor-pointer">
                        2. Extension de Garantie Complémentaire : {hasWarrantyExtension ? (
                          <span className="text-amber-400 font-extrabold">+{warrantyExtensionMonths} mois de supplément</span>
                        ) : (
                          <span className="text-slate-500 font-normal">Non incluse</span>
                        )}
                      </label>
                    </div>

                    {hasWarrantyExtension && (
                      <div className="flex items-center gap-1">
                        {[6, 12, 24, 36].map((m) => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => setWarrantyExtensionMonths(m)}
                            className={`px-2.5 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                              warrantyExtensionMonths === m
                                ? 'bg-amber-400 text-slate-950 shadow-sm'
                                : 'bg-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            +{m} m
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {hasWarrantyExtension && (
                    <div className="space-y-3 pt-2.5 border-t border-slate-800">
                      {/* Range Slider 4 to 36 months */}
                      <input
                        type="range"
                        min={4}
                        max={36}
                        step={1}
                        value={warrantyExtensionMonths}
                        onChange={(e) => setWarrantyExtensionMonths(Number(e.target.value))}
                        className="w-full accent-amber-400 cursor-pointer h-2 bg-slate-950 rounded-lg"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                        <span>+4 mois</span>
                        <span>+12 mois (1 an)</span>
                        <span>+24 mois (2 ans)</span>
                        <span>+36 mois (3 ans)</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Coût du supplément extension (€)</label>
                          <input
                            type="number"
                            value={warrantyExtensionCostStr}
                            onChange={(e) => setWarrantyExtensionCostStr(e.target.value)}
                            placeholder="0"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white tabular-nums"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Prestataire Garantie Partenaire</label>
                          <select
                            value={warrantyProvider}
                            onChange={(e) => setWarrantyProvider(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                          >
                            <option value="Opteven Premium">Opteven Premium</option>
                            <option value="Cirano Élite">Cirano Élite</option>
                            <option value="Gras Savoye">Gras Savoye</option>
                            <option value="Garantie Commerciale TBD AUTOS">Garantie Commerciale TBD AUTOS</option>
                            <option value="Garantie Constructeur">Garantie Constructeur</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Live Guarantee Label Preview / Override */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">
                    Libellé Commercial pour Fiche Client & Affiche Pare-Brise
                  </label>
                  <input
                    type="text"
                    value={guarantee}
                    onChange={(e) => setGuarantee(e.target.value)}
                    placeholder="ex: Garantie 12 Mois Pièces et Main d’œuvre"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-amber-300 font-semibold focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Options Majeures & Équipements Clés (affichés sur l'affiche pare-brise)
                </label>
                
                <div className="flex gap-2 mb-3">
                  <input
                    type="text"
                    value={newOptionInput}
                    onChange={(e) => setNewOptionInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddOption();
                      }
                    }}
                    placeholder="Ajouter une option (ex: Échappement sport, Toit ouvrant panoramique...)"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={handleAddOption}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Ajouter
                  </button>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {keyOptions.map((opt, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200"
                    >
                      <span className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                        {opt}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveOption(idx)}
                        className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
          {/* Checklist & Scans Administratifs */}
              
              {/* Document File Upload Dropzone */}
              <div className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <Upload className="w-4 h-4 text-amber-400" />
                      Uploader les Documents du Véhicule (Scans, Factures, Mandat)
                    </h3>
                    <p className="text-xs text-slate-400">
                      Rattachez la carte grise barrée, certificat de non-gage SIV, mandat de vente, CT ou factures d'achat.
                    </p>
                  </div>

                  <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors cursor-pointer shrink-0 shadow-md">
                    <Upload className="w-4 h-4" />
                    <span>Uploader Document (PDF / Scan)</span>
                    <input
                      type="file"
                      accept=".pdf,image/*"
                      multiple
                      onChange={handleDocFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Catégorie du document rattaché</label>
                    <select
                      value={selectedDocCategory}
                      onChange={(e) => setSelectedDocCategory(e.target.value as DocumentCategory)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="carte_grise">Carte Grise / Certificat d'immatriculation</option>
                      <option value="mandat">Mandat de vente (Dépôt-vente)</option>
                      <option value="non_gage">Certificat de non-gage SIV</option>
                      <option value="ct">Contrôle Technique</option>
                      <option value="cession">Certificat de Cession Cerfa</option>
                      <option value="facture">Facture d'achat / d'entretien</option>
                      <option value="autre">Autre pièce jointe</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Note / Précision sur le document</label>
                    <input
                      type="text"
                      value={newDocNotes}
                      onChange={(e) => setNewDocNotes(e.target.value)}
                      placeholder="ex: Mandat signé par M. Dupont jusqu'au 15/12..."
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Uploaded Documents List */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 mb-3 flex items-center justify-between">
                  <span>Documents Rattachés ({documentFiles.length})</span>
                </h4>

                {documentFiles.length === 0 ? (
                  <div className="p-8 text-center bg-slate-950/60 border border-dashed border-slate-800 rounded-xl text-xs text-slate-400">
                    Aucun document PDF ou scan rattaché à ce véhicule pour le moment.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {documentFiles.map((doc) => (
                      <div
                        key={doc.id}
                        className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between text-xs hover:border-slate-700 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <FileText className="w-5 h-5 text-amber-400 shrink-0" />
                          <div>
                            <div className="font-bold text-white flex items-center gap-2">
                              {doc.name}
                              <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded font-normal text-slate-300 uppercase">
                                {doc.category}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-500">
                              Uploadé le {doc.uploadDate} · {doc.size} {doc.notes ? `· ${doc.notes}` : ''}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {doc.url && doc.url !== '#' && (
                            <a
                              href={doc.url}
                              download={doc.name}
                              target="_blank"
                              rel="noreferrer"
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs cursor-pointer"
                            >
                              Télécharger / Voir
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={() => handleDeleteDocFile(doc.id)}
                            className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Status Checklist Selectors */}
              <div className="pt-4 border-t border-slate-800">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
                  Statuts Réglementaires SIV
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400 block mb-1">Carte Grise</span>
                    <select
                      value={carteGrise}
                      onChange={(e) => setCarteGrise(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded text-xs px-2 py-1 text-white"
                    >
                      <option value="complet">Complet (Reçue & Conforme)</option>
                      <option value="en_attente">En attente (Barrée)</option>
                      <option value="manquant">Manquant</option>
                    </select>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400 block mb-1">Certificat Non-Gage (&lt;15j)</span>
                    <select
                      value={certificatNonGage}
                      onChange={(e) => setCertificatNonGage(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded text-xs px-2 py-1 text-white"
                    >
                      <option value="complet">Complet (Vierge)</option>
                      <option value="en_attente">À renouveler</option>
                      <option value="manquant">Manquant</option>
                    </select>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400 block mb-1">Contrôle Technique</span>
                    <select
                      value={controleTechnique}
                      onChange={(e) => setControleTechnique(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded text-xs px-2 py-1 text-white"
                    >
                      <option value="complet">Valide (&lt; 6 mois)</option>
                      <option value="en_attente">À programmer</option>
                      <option value="manquant">Manquant / Expiré</option>
                      <option value="non_requis">Non requis (&lt; 4 ans)</option>
                    </select>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400 block mb-1">Mandat de Vente (si Dépôt-Vente)</span>
                    <select
                      value={mandatVente}
                      onChange={(e) => setMandatVente(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded text-xs px-2 py-1 text-white"
                    >
                      <option value="complet">Mandat signé</option>
                      <option value="en_attente">En cours de signature</option>
                      <option value="non_requis">Non requis</option>
                    </select>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400 block mb-1">Certificat Cession (Cerfa)</span>
                    <select
                      value={certificatCession}
                      onChange={(e) => setCertificatCession(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded text-xs px-2 py-1 text-white"
                    >
                      <option value="complet">Signé & Valide</option>
                      <option value="en_attente">En attente signature</option>
                      <option value="manquant">Manquant</option>
                    </select>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400 block mb-1">Clés & Carnet</span>
                    <div className="flex gap-4 pt-1">
                      <label className="flex items-center gap-1.5 text-xs text-slate-300">
                        <input
                          type="checkbox"
                          checked={doubleDesCles}
                          onChange={(e) => setDoubleDesCles(e.target.checked)}
                          className="w-3.5 h-3.5"
                        />
                        2 Clés
                      </label>
                      <label className="flex items-center gap-1.5 text-xs text-slate-300">
                        <input
                          type="checkbox"
                          checked={carnetEntretien}
                          onChange={(e) => setCarnetEntretien(e.target.checked)}
                          className="w-3.5 h-3.5"
                        />
                        Carnet
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 5 Navigation Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Précédente Étape : Photos & Médias</span>
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 text-xs font-black text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-all shadow-lg flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isEditing ? 'Enregistrer les Modifications' : '✨ Valider & Ajouter au Stock'}</span>
                </button>
              </div>
            </div>
          )}


                    {/* Modal Actions */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between shrink-0 bg-slate-950/80 px-4 sm:px-6 py-3 rounded-b-2xl">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Annuler
              </button>

              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep((s) => (s > 1 ? (s - 1) as WizardStep : 1))}
                  className="px-3.5 py-2 text-xs font-bold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5 text-slate-400" />
                  <span>Précédente</span>
                </button>
              )}

              {isEditing && vehicle && onOpenSendEmail && (
                <button
                  type="button"
                  onClick={() => onOpenSendEmail(vehicle, vehicle.businessType === 'achat_revente' ? 'facture_achat' : 'mandat_depot_vente')}
                  className="px-3 py-2 text-xs font-bold text-amber-300 hover:text-white bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/30 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                  title="Envoyer la facture d'achat ou les documents par email avec tbdautos@gmail.com"
                >
                  <Mail className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">Envoyer Facture & Docs</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              {step < 5 ? (
                <button
                  type="button"
                  onClick={() => setStep((s) => (s < 5 ? (s + 1) as WizardStep : 5))}
                  className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-md flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <span>Étape Suivante</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  type="submit"
                  className="px-6 py-2.5 text-xs font-black text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-all shadow-lg flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isEditing ? 'Enregistrer les Modifications' : '✨ Valider & Ajouter au Stock'}</span>
                </button>
              )}

              {isEditing && step < 5 && (
                <button
                  type="submit"
                  className="px-4 py-2.5 text-xs font-bold text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 rounded-xl transition-colors cursor-pointer"
                  title="Enregistrer immédiatement sans parcourir toutes les étapes"
                >
                  Sauvegarder
                </button>
              )}
            </div>
          </div>

        </form>

        {/* Lightbox for CNI / KBIS Document Preview in VehicleModal */}
        {viewingSellerDoc && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
            <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
              <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-slate-950">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-white">{viewingSellerDoc.title}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setViewingSellerDoc(null)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-4 bg-slate-950 flex items-center justify-center min-h-[350px] overflow-auto">
                {viewingSellerDoc.url ? (
                  viewingSellerDoc.type.includes('image') || viewingSellerDoc.url.startsWith('data:image') || viewingSellerDoc.url.includes('images.unsplash.com') ? (
                    <img
                      src={viewingSellerDoc.url}
                      alt={viewingSellerDoc.title}
                      className="max-w-full max-h-[65vh] object-contain rounded-xl border border-slate-800 shadow"
                    />
                  ) : (
                    <iframe
                      src={viewingSellerDoc.url}
                      title={viewingSellerDoc.title}
                      className="w-full h-[65vh] rounded-xl border border-slate-800 bg-white"
                    />
                  )
                ) : (
                  <div className="text-center p-6 text-slate-400 text-xs">
                    Document d'identité archivé sous référence conforme.
                  </div>
                )}
              </div>

              <div className="px-5 py-2.5 border-t border-slate-800 bg-slate-950/70 flex justify-end">
                <button
                  type="button"
                  onClick={() => setViewingSellerDoc(null)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
