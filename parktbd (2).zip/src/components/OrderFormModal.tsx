import React from 'react';
import { Vehicle, ReservationBuyerInfo } from '../types';
import { Printer, X, Download, ShieldCheck, Mail, CheckCircle2 } from 'lucide-react';

interface OrderFormModalProps {
  vehicle: Vehicle | null;
  reservation?: ReservationBuyerInfo | null;
  onClose: () => void;
}

export const OrderFormModal: React.FC<OrderFormModalProps> = ({
  vehicle,
  reservation,
  onClose
}) => {
  if (!vehicle) return null;

  const res = reservation || vehicle.reservation;

  const orderNum = res?.orderNumber || `BDC-${vehicle.registration.replace(/-/g, '')}-${new Date().getFullYear()}`;
  const orderDate = res?.orderDate || new Date().toISOString().slice(0, 10);
  const formattedOrderDate = new Date(orderDate).toLocaleDateString('fr-FR');

  const buyerType = res?.buyerType || 'particulier';
  const buyerName = res?.name || vehicle.buyerName || 'Client Acheteur';
  const buyerFirstName = res?.firstName || '';
  const sirenSiret = res?.sirenSiret || '';
  const buyerPhone = res?.phone || vehicle.buyerPhone || '';
  const buyerEmail = res?.email || '';
  const buyerAddress = res?.address || '';
  const buyerPostalCodeCity = res?.postalCodeCity || '';

  const vehiclePriceTTC = res?.vehiclePriceTTC ?? vehicle.sellingPrice ?? 0;
  const adminPrepFees = res?.adminPrepFees ?? 0;
  const regFeesCarteGrise = res?.regFeesCarteGrise ?? (vehicle.powerFiscal ? vehicle.powerFiscal * 45 : 250);
  const totalPriceToPayTTC = res?.totalPriceToPayTTC ?? (vehiclePriceTTC + adminPrepFees + regFeesCarteGrise);
  const depositAmount = res?.depositAmount ?? Math.min(1000, Math.round(totalPriceToPayTTC * 0.1));
  const depositDate = res?.depositDate ? new Date(res.depositDate).toLocaleDateString('fr-FR') : formattedOrderDate;
  const balanceRemaining = res?.balanceRemaining ?? (totalPriceToPayTTC - depositAmount);
  const paymentMethod = res?.depositPaymentMethod || 'virement';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-8 flex flex-col">
        
        {/* Screen Controls Header (hidden on print) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Bon de Commande Véhicule d'Occasion — TBD AUTOS</span>
              <span className="text-amber-400 font-mono text-xs">({orderNum})</span>
            </h2>
            <p className="text-xs text-slate-400">
              Conforme au modèle officiel 2 pages avec conditions générales de vente & mentions légales.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimer / Enregistrer PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Canvas (Rendered in clean white A4 style) */}
        <div className="p-6 sm:p-10 bg-white text-slate-950 font-sans text-xs leading-relaxed max-h-[85vh] overflow-y-auto print:max-h-none print:overflow-visible print:p-0">
          
          {/* ================= PAGE 1 ================= */}
          <div className="space-y-5 print:min-h-[297mm] print:p-8 flex flex-col justify-between">
            <div>
              {/* Header TBD AUTOS */}
              <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <div className="w-10 h-10 rounded-lg bg-slate-950 text-amber-400 flex items-center justify-center font-black text-xl tracking-tighter">
                    T
                  </div>
                  <div className="text-xs font-semibold text-slate-500 mt-1 uppercase tracking-wider">
                    Véhicules d'Occasion & Courtage
                  </div>
                </div>

                <div className="text-right text-[11px] text-slate-700 space-y-0.5">
                  <div className="font-extrabold text-sm text-slate-950 uppercase tracking-tight">TBD AUTOS</div>
                  <div>Résidence Sarcignan, Chemin Gaston</div>
                  <div>33140 Villenave d'Ornon</div>
                  <div className="font-mono text-[10px]">SIRET : 937 534 097 00012</div>
                  <div className="font-mono text-[10px]">Courriel : tbdautos@gmail.com</div>
                </div>
              </div>

              {/* Document Banner */}
              <div className="mt-4 flex items-center justify-between border-y-2 border-slate-950 py-2.5 bg-slate-100 px-3">
                <h1 className="text-sm font-black tracking-wider uppercase text-slate-950">
                  BON DE COMMANDE VÉHICULE D'OCCASION
                </h1>
                <div className="font-mono text-xs font-bold text-slate-900">
                  N° Commande : <span className="underline">{orderNum}</span>
                </div>
              </div>

              {/* 1. IDENTIFICATION DE L'ACHETEUR */}
              <div className="mt-4 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1.5 text-xs flex justify-between items-center">
                  <span>1. IDENTIFICATION DE L'ACHETEUR</span>
                  <div className="flex items-center gap-4 text-[11px] font-normal">
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={buyerType === 'particulier'} 
                        readOnly 
                        className="accent-amber-400" 
                      />
                      <span>PARTICULIER</span>
                    </label>
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={buyerType === 'professionnel'} 
                        readOnly 
                        className="accent-amber-400" 
                      />
                      <span>PROFESSIONNEL</span>
                    </label>
                  </div>
                </div>

                <div className="p-3 grid grid-cols-2 gap-x-4 gap-y-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">Nom / Raison Sociale :</span>
                    <strong className="text-slate-900 text-xs">{buyerName}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Prénom (si particulier) :</span>
                    <strong className="text-slate-900 text-xs">{buyerFirstName || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">N° SIREN / SIRET (si pro) :</span>
                    <strong className="text-slate-900 font-mono">{sirenSiret || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Téléphone :</span>
                    <strong className="text-slate-900">{buyerPhone || '—'}</strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 block">Adresse / Siège Social :</span>
                    <strong className="text-slate-900">{buyerAddress || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Code Postal & Ville :</span>
                    <strong className="text-slate-900">{buyerPostalCodeCity || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Adresse e-mail :</span>
                    <strong className="text-slate-900">{buyerEmail || '—'}</strong>
                  </div>
                </div>
              </div>

              {/* 2. DÉSIGNATION DU VÉHICULE COMMANDÉ */}
              <div className="mt-4 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1.5 text-xs">
                  2. DÉSIGNATION DU VÉHICULE COMMANDÉ
                </div>

                <div className="p-3 grid grid-cols-3 gap-x-4 gap-y-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">Marque :</span>
                    <strong className="text-slate-900 text-xs uppercase">{vehicle.brand}</strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 block">Modèle & Finition :</span>
                    <strong className="text-slate-900 text-xs">{vehicle.model} {vehicle.version}</strong>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Immatriculation :</span>
                    <strong className="text-slate-900 font-mono text-xs">{vehicle.registration}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">N° VIN (Châssis) :</span>
                    <strong className="text-slate-900 font-mono text-[10px]">{vehicle.vin || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">1ère Mise en circulation :</span>
                    <strong className="text-slate-900">{vehicle.firstRegistrationDate || `${vehicle.year}-01-01`}</strong>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Kilométrage certifié :</span>
                    <strong className="text-slate-900 tabular-nums">{Number(vehicle.mileage).toLocaleString('fr-FR')} km</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Énergie / Carburant :</span>
                    <strong className="text-slate-900">{vehicle.fuel}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Boîte de vitesses :</span>
                    <strong className="text-slate-900">{vehicle.gearbox}</strong>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Couleur :</span>
                    <strong className="text-slate-900">{vehicle.colorExterior}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Puissance :</span>
                    <strong className="text-slate-900">{vehicle.powerDin} ch ({vehicle.powerFiscal} CV)</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Garantie souscrite :</span>
                    <strong className="text-slate-900">{vehicle.guarantee}</strong>
                  </div>
                </div>
              </div>

              {/* 3. DÉTAIL FINANCIER & PRIX TOTAL TTC */}
              <div className="mt-4 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1.5 text-xs">
                  3. DÉTAIL FINANCIER & PRIX TOTAL TTC
                </div>

                <table className="w-full text-[11px] border-collapse">
                  <thead>
                    <tr className="border-b border-slate-300 bg-slate-50 text-slate-600 font-semibold">
                      <th className="text-left p-2.5">Désignation / Prestation</th>
                      <th className="text-right p-2.5 w-40">Montant (€ TTC)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="p-2.5 text-slate-800">
                        Prix de vente du véhicule d'occasion TTC
                        <span className="block text-[10px] text-slate-500">
                          {vehicle.tvaRegime === 'marge' ? 'TVA sur marge d\'occasion Art. 297 A CGI' : 'TVA standard incluse'}
                        </span>
                      </td>
                      <td className="p-2.5 text-right font-bold text-slate-950 tabular-nums text-xs">
                        {vehiclePriceTTC.toLocaleString('fr-FR')} €
                      </td>
                    </tr>
                    <tr>
                      <td className="p-2.5 text-slate-800">
                        Frais de dossier / Préparation véhicule (si applicable)
                      </td>
                      <td className="p-2.5 text-right font-semibold text-slate-800 tabular-nums">
                        {adminPrepFees.toLocaleString('fr-FR')} €
                      </td>
                    </tr>
                    <tr>
                      <td className="p-2.5 text-slate-800">
                        Frais d'immatriculation / Carte Grise (estimation sous réserve de la région)
                      </td>
                      <td className="p-2.5 text-right font-semibold text-slate-800 tabular-nums">
                        {regFeesCarteGrise.toLocaleString('fr-FR')} €
                      </td>
                    </tr>
                    <tr className="bg-slate-100 font-bold border-t-2 border-slate-400">
                      <td className="p-2.5 text-slate-950 uppercase text-xs">PRIX TOTAL A PAYER TTC</td>
                      <td className="p-2.5 text-right text-slate-950 font-black text-sm tabular-nums">
                        {totalPriceToPayTTC.toLocaleString('fr-FR')} €
                      </td>
                    </tr>
                    <tr className="text-rose-700 bg-rose-50/50">
                      <td className="p-2.5">
                        Acompte versé à la commande le : <span className="underline font-semibold">{depositDate}</span>
                      </td>
                      <td className="p-2.5 text-right font-black tabular-nums">
                        - {depositAmount.toLocaleString('fr-FR')} €
                      </td>
                    </tr>
                    <tr className="bg-amber-100/70 font-extrabold border-t border-slate-300">
                      <td className="p-2.5 text-amber-950 uppercase text-xs">SOLDE RESTANT À PAYER À LA LIVRAISON</td>
                      <td className="p-2.5 text-right text-amber-950 font-black text-sm tabular-nums">
                        {balanceRemaining.toLocaleString('fr-FR')} €
                      </td>
                    </tr>
                  </tbody>
                </table>

                {/* Mode de règlement de l'acompte */}
                <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between text-[11px] text-slate-700">
                  <span className="font-semibold">Mode de règlement de l'acompte :</span>
                  <div className="flex items-center gap-4">
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input type="checkbox" checked={paymentMethod === 'virement'} readOnly className="accent-slate-900" />
                      <span>Virement</span>
                    </label>
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input type="checkbox" checked={paymentMethod === 'cheque_banque'} readOnly className="accent-slate-900" />
                      <span>Chèque de banque</span>
                    </label>
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input type="checkbox" checked={paymentMethod === 'carte_bancaire'} readOnly className="accent-slate-900" />
                      <span>Carte Bancaire</span>
                    </label>
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input type="checkbox" checked={paymentMethod === 'especes'} readOnly className="accent-slate-900" />
                      <span>Espèces (max 1000€)</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Page 1 */}
            <div className="pt-3 border-t border-slate-300 flex justify-between text-[9px] text-slate-500 uppercase tracking-wider">
              <span>TBD AUTOS — Bon de Commande Véhicule</span>
              <span>Page 1 / 2</span>
            </div>
          </div>

          {/* ================= PAGE 2 ================= */}
          <div className="space-y-4 print:min-h-[297mm] print:p-8 flex flex-col justify-between mt-8 print:mt-0 print:break-before-page border-t-2 border-dashed border-slate-300 pt-8 print:border-none print:pt-0">
            <div>
              {/* Header Mini Page 2 */}
              <div className="flex justify-between items-center pb-2 border-b border-slate-300 text-[10px] text-slate-500">
                <span className="font-bold text-slate-800">TBD AUTOS — Conditions Générales de Vente</span>
                <span>N° Commande : {orderNum}</span>
              </div>

              {/* 5. CONDITIONS GÉNÉRALES ET MENTIONS LÉGALES */}
              <div className="mt-3 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1.5 text-xs">
                  5. CONDITIONS GÉNÉRALES ET MENTIONS LÉGALES
                </div>

                <div className="p-3 text-[9.5px] leading-relaxed text-slate-700 space-y-2 text-justify">
                  <p>
                    <strong>Article 1 — Engagement de commande :</strong> La présente commande devient ferme et définitive pour l'acheteur dès la signature du présent bon de commande et le versement de l'acompte convenu. En cas d'annulation non justifiée par la force majeure ou le non-respect de la date limite de livraison par le vendeur, l'acompte sera restitué conformément aux dispositions légales.
                  </p>
                  <p>
                    <strong>Article 2 — Modalités de paiement du solde :</strong> Le solde du prix total TTC doit être intégralement réglé au plus tard le jour de la livraison effective du véhicule, exclusivement par virement bancaire préalablement crédité ou par chèque de banque certifié à l'ordre de TBD AUTOS.
                  </p>
                  <p>
                    <strong>Article 3 — Réserve de propriété :</strong> Conformément à la loi n° 80-335 du 12 mai 1980, le vendeur conserve la propriété du véhicule vendu jusqu'au paiement effectif et intégral du prix principal et des frais accessoires. Les risques liés au véhicule sont toutefois transférés à l'acheteur dès la remise physique des clés.
                  </p>
                  <p>
                    <strong>Article 4 — Garanties légales :</strong> Le véhicule bénéficie de la garantie légale de conformité (articles L. 217-3 et suivants du Code de la consommation) et de la garantie des vices cachés (articles 1641 et suivants du Code civil). Si une garantie commerciale est souscrite, ses conditions spécifiques font l'objet d'un contrat annexé.
                  </p>
                  <p>
                    <strong>Article 5 — Rétractation :</strong> En cas de vente conclue hors établissement ou à distance (Internet, téléphone), l'acheteur consommateur dispose d'un délai de rétractation de 14 jours révolus à compter de la livraison du véhicule pour exercer son droit sans avoir à justifier de motifs.
                  </p>
                  <p>
                    <strong>Article 6 — Données personnelles (RGPD) :</strong> Les informations recueillies sur ce document font l'objet d'un traitement informatique nécessaire à la gestion de la commande, à la facturation et à la réalisation des démarches d'immatriculation. Elles sont conservées en toute sécurité conformément à la réglementation. L'acheteur dispose d'un droit d'accès et de rectification par courriel à : tbdautos@gmail.com.
                  </p>
                </div>
              </div>

              {/* 6. ACCORD DES PARTIES ET SIGNATURES */}
              <div className="mt-4 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1.5 text-xs">
                  6. ACCORD DES PARTIES ET SIGNATURES
                </div>

                <div className="p-3 space-y-3">
                  <p className="text-[10px] text-slate-600">
                    L'Acheteur déclare avoir pris connaissance des conditions générales ci-dessus et accepter les termes de la présente commande.
                  </p>
                  <p className="text-[10px] text-slate-600">
                    Fait à <span className="underline font-semibold">Villenave d'Ornon</span>, le <span className="underline font-semibold">{formattedOrderDate}</span>, en deux exemplaires originaux.
                  </p>

                  <div className="grid grid-cols-2 gap-4 pt-2">
                    {/* Buyer Signature Box */}
                    <div className="border border-slate-300 rounded p-3 min-h-[120px] flex flex-col justify-between bg-slate-50/50">
                      <div>
                        <div className="font-bold text-xs text-slate-900 uppercase">L'ACHETEUR</div>
                        <div className="text-[10px] text-slate-600">({buyerName} {buyerFirstName})</div>
                        <div className="text-[9px] text-slate-500 italic mt-0.5">
                          Mention manuscrite « Lu et approuvé, bon pour commande »
                        </div>
                      </div>
                      <div className="border-b border-dashed border-slate-300 pt-6 text-center text-[9px] text-slate-400">
                        Signature de l'acheteur
                      </div>
                    </div>

                    {/* Dealer Signature Box */}
                    <div className="border border-slate-300 rounded p-3 min-h-[120px] flex flex-col justify-between bg-slate-50/50">
                      <div>
                        <div className="font-bold text-xs text-slate-900 uppercase">LE VENDEUR / MANDATAIRE</div>
                        <div className="text-[10px] font-semibold text-slate-800">TBD AUTOS</div>
                        <div className="text-[9px] text-slate-500 italic mt-0.5">
                          Signature et cachet de la société
                        </div>
                      </div>
                      <div className="border-b border-dashed border-slate-300 pt-6 text-center text-[9px] text-slate-400">
                        Cachet & Signature TBD AUTOS
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Page 2 */}
            <div className="pt-3 border-t border-slate-300 flex justify-between text-[9px] text-slate-500 uppercase tracking-wider">
              <span>TBD AUTOS — SIRET 937 534 097 00012</span>
              <span>Page 2 / 2</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
