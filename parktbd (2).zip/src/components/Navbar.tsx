import React from 'react';
import { Plus, Wifi, RefreshCw, Mail } from 'lucide-react';

export type NavTab = 
  | 'dashboard' 
  | 'stock' 
  | 'appointments' 
  | 'documents' 
  | 'sellers'
  | 'margins' 
  | 'team';

interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenNewVehicle: () => void;
  onOpenSendEmail?: () => void;
  syncConnected: boolean;
  currentUser: { name: string; role: string };
  onRefreshData: () => void;
  isSyncing: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenNewVehicle,
  onOpenSendEmail,
  syncConnected,
  currentUser,
  onRefreshData,
  isSyncing
}) => {
  return (
    <header className="no-print sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          
          {/* Zone 1: Brand Wordmark (Single element) */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onSelectTab('dashboard')}
              className="flex items-center gap-2.5 text-left cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-black text-lg flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
                P
              </div>
              <div>
                <span className="text-xl font-black tracking-tight text-white uppercase block leading-none">
                  Park<span className="text-amber-400">TBD</span>
                </span>
                <span className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase block mt-0.5">
                  Gestion Automobile
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Concise Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium">
            <button
              onClick={() => onSelectTab('dashboard')}
              className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
                currentTab === 'dashboard'
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Tableau de bord
            </button>
            <button
              onClick={() => onSelectTab('stock')}
              className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
                currentTab === 'stock'
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Stock Véhicules
            </button>
            <button
              onClick={() => onSelectTab('appointments')}
              className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
                currentTab === 'appointments'
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Rendez-vous & Essais
            </button>
            <button
              onClick={() => onSelectTab('documents')}
              className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
                currentTab === 'documents'
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Documents & SIV
            </button>
            <button
              onClick={() => onSelectTab('sellers')}
              className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
                currentTab === 'sellers'
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Vendeurs & Dépôts
            </button>
            <button
              onClick={() => onSelectTab('margins')}
              className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
                currentTab === 'margins'
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Finances & Comptabilité
            </button>
            <button
              onClick={() => onSelectTab('team')}
              className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
                currentTab === 'team'
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Équipe & Accès
            </button>
          </nav>

          {/* Zone 3: Sync state & Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Real-time synchronization indicator */}
            <div 
              title={syncConnected ? 'Données synchronisées en temps réel sur tous vos appareils' : 'Tentative de reconnexion au serveur...'}
              className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg"
            >
              <Wifi className={`w-3.5 h-3.5 ${syncConnected ? 'text-emerald-400' : 'text-amber-400 animate-pulse'}`} />
              <span className="text-[11px] font-medium hidden md:inline">
                {syncConnected ? 'Sync Direct' : 'Reconnexion'}
              </span>
              <button
                onClick={onRefreshData}
                disabled={isSyncing}
                title="Actualiser manuellement"
                className="hover:text-white text-slate-500 cursor-pointer p-0.5 ml-1"
              >
                <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Current user badge */}
            <button
              onClick={() => onSelectTab('team')}
              className="hidden sm:flex items-center gap-2 text-left cursor-pointer hover:bg-slate-900 px-2 py-1 rounded-lg transition-colors"
            >
              <div className="w-7 h-7 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 flex items-center justify-center text-xs font-bold">
                {currentUser.name.charAt(0)}
              </div>
              <div className="text-[11px] leading-tight hidden xl:block">
                <div className="text-white font-medium">{currentUser.name}</div>
                <div className="text-slate-400 capitalize">{currentUser.role}</div>
              </div>
            </button>

            {/* Send Document / Invoice Email Button */}
            {onOpenSendEmail && (
              <button
                onClick={onOpenSendEmail}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 hover:text-white"
                title="Envoyer des factures d'achat ou documents administratifs avec tbdautos@gmail.com"
              >
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <span>Envoyer Facture / Doc</span>
              </button>
            )}

            {/* Primary Action Button */}
            <button
              onClick={onOpenNewVehicle}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-sm cursor-pointer whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Nouveau Véhicule</span>
            </button>
          </div>

        </div>

        {/* Mobile Nav bar */}
        <div className="lg:hidden flex items-center justify-between overflow-x-auto py-2.5 border-t border-slate-800/80 gap-3 text-xs">
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`whitespace-nowrap px-2 py-1 rounded cursor-pointer ${currentTab === 'dashboard' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Tableau de bord
          </button>
          <button
            onClick={() => onSelectTab('stock')}
            className={`whitespace-nowrap px-2 py-1 rounded cursor-pointer ${currentTab === 'stock' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Stock
          </button>
          <button
            onClick={() => onSelectTab('appointments')}
            className={`whitespace-nowrap px-2 py-1 rounded cursor-pointer ${currentTab === 'appointments' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Rendez-vous
          </button>
          <button
            onClick={() => onSelectTab('documents')}
            className={`whitespace-nowrap px-2 py-1 rounded cursor-pointer ${currentTab === 'documents' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Documents
          </button>
          <button
            onClick={() => onSelectTab('sellers')}
            className={`whitespace-nowrap px-2 py-1 rounded cursor-pointer ${currentTab === 'sellers' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Vendeurs
          </button>
          <button
            onClick={() => onSelectTab('margins')}
            className={`whitespace-nowrap px-2 py-1 rounded cursor-pointer ${currentTab === 'margins' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Finances
          </button>
          <button
            onClick={() => onSelectTab('team')}
            className={`whitespace-nowrap px-2 py-1 rounded cursor-pointer ${currentTab === 'team' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Équipe
          </button>
        </div>

      </div>
    </header>
  );
};
