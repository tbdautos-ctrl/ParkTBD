import React, { useState } from 'react';
import { Vehicle, FinancialStats, EmailDocType } from '../types';
import { 
  DollarSign, 
  TrendingUp, 
  Percent, 
  Download, 
  Wrench, 
  Truck, 
  Sparkles, 
  ShieldCheck, 
  PieChart, 
  Filter,
  Mail,
  FileText,
  Receipt,
  Printer,
  Scale
} from 'lucide-react';
import { 
  GlobalFinancialReportModal, 
  AccountingLedgerModal, 
  SellerSettlementModal 
} from './FinancialReportsModals';

interface MarginsViewProps {
  vehicles: Vehicle[];
  stats: FinancialStats;
  onOpenVehicleModal: (vehicle: Vehicle) => void;
  onOpenSendEmail?: (vehicle: Vehicle, docType?: EmailDocType) => void;
}

export const MarginsView: React.FC<MarginsViewProps> = ({
  vehicles,
  stats,
  onOpenVehicleModal,
  onOpenSendEmail
}) => {
  const [filterType, setFilterType] = useState<'all' | 'achat_revente' | 'depot_vente'>('all');
  const [tvaFilter, setTvaFilter] = useState<'all' | 20 | 10 | 8.5 | 5.5 | 2.1 | 0>('all');

  // Report Modals State
  const [showGlobalReport, setShowGlobalReport] = useState(false);
  const [showAccountingLedger, setShowAccountingLedger] = useState(false);
  const [showSellerSettlement, setShowSellerSettlement] = useState(false);

  const filteredVehicles = vehicles.filter(v => {
    const matchesActivity = filterType === 'all' || v.businessType === filterType;
    const rate = v.tvaRate ?? 20;
    const matchesTva = tvaFilter === 'all' || rate === tvaFilter;
    return matchesActivity && matchesTva;
  });

  // Calculate Aggregated Cost Buckets
  const totalPurchase = vehicles.reduce((acc, v) => acc + (v.costs.purchasePrice || 0), 0);
  const totalTransport = vehicles.reduce((acc, v) => acc + (v.costs.transport || 0), 0);
  const totalMechanical = vehicles.reduce((acc, v) => acc + (v.costs.reconditioning || 0), 0);
  const totalDetailing = vehicles.reduce((acc, v) => acc + (v.costs.detailing || 0), 0);
  const totalInspectionAdmin = vehicles.reduce((acc, v) => acc + (v.costs.inspection || 0) + (v.costs.adminFees || 0), 0);
  const totalWarranties = vehicles.reduce((acc, v) => acc + (v.costs.warrantyCost || 0), 0);
  const totalPrepFees = totalTransport + totalMechanical + totalDetailing + totalInspectionAdmin + totalWarranties;

  // Export CSV
  const handleExportCsv = () => {
    const headers = [
      'Marque',
      'Modèle',
      'Immatriculation',
      'Activité',
      'Statut',
      'Prix Achat (€)',
      'Transport (€)',
      'Mécanique (€)',
      'Carrosserie (€)',
      'CT & Admin (€)',
      'Garantie (€)',
      'Coût Revient Total (€)',
      'Prix Vente TTC (€)',
      'Marge Nette (€)',
      'Taux Marge (%)'
    ];

    const rows = filteredVehicles.map(v => {
      const totalCost = v.costs.purchasePrice + v.costs.transport + v.costs.reconditioning + v.costs.detailing + v.costs.inspection + v.costs.adminFees + v.costs.warrantyCost;
      const margin = v.sellingPrice - totalCost;
      const marginPct = totalCost > 0 ? ((margin / totalCost) * 100).toFixed(1) : '0';

      return [
        v.brand,
        v.model,
        v.registration,
        v.businessType,
        v.status,
        v.costs.purchasePrice,
        v.costs.transport,
        v.costs.reconditioning,
        v.costs.detailing,
        v.costs.inspection + v.costs.adminFees,
        v.costs.warrantyCost,
        totalCost,
        v.sellingPrice,
        margin,
        marginPct
      ].join(';');
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(';'), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ParkTBD_Suivi_Marges_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>Finances & Comptabilité Automobile</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-bold border border-amber-400/30">
              TBD AUTOS
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Comptabilité analytique, Grand Livre des ventes, Compte-rendu financier global et Comptes de reddition Vendeurs.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Button 1: Global Financial Report */}
          <button
            onClick={() => setShowGlobalReport(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer shadow-md"
            title="Générer et imprimer le compte-rendu financier complet de toutes les ventes"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Compte-Rendu Global Ventes</span>
          </button>

          {/* Button 2: Accounting Ledger */}
          <button
            onClick={() => setShowAccountingLedger(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
            title="Fiche comptable détaillée avec ventilation TVA sur marge pour l'expert-comptable"
          >
            <Receipt className="w-3.5 h-3.5 text-blue-400" />
            <span>Fiche Comptable (Expert)</span>
          </button>

          {/* Button 3: Seller Settlement (Reddition Vendeur) */}
          <button
            onClick={() => setShowSellerSettlement(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
            title="Générer un compte de reddition financier à donner au client vendeur en dépôt-vente"
          >
            <Scale className="w-3.5 h-3.5 text-emerald-400" />
            <span>Reddition Client Vendeur</span>
          </button>

          {/* Button 4: CSV Export */}
          <button
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg transition-colors cursor-pointer"
            title="Exporter le grand livre au format CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CSV</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl">
          <span className="text-xs text-slate-400 block">Chiffre d'Affaires Prévisionnel</span>
          <span className="text-2xl sm:text-3xl font-extrabold text-white tabular-nums block mt-1">
            {stats.totalStockValueTTC.toLocaleString('fr-FR')} €
          </span>
          <span className="text-[11px] text-slate-500 mt-2 block">Valeur marchande des véhicules en parc</span>
        </div>

        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl">
          <span className="text-xs text-slate-400 block">Total Coûts de Revient Engagés</span>
          <span className="text-2xl sm:text-3xl font-extrabold text-white tabular-nums block mt-1">
            {stats.totalCostInvested.toLocaleString('fr-FR')} €
          </span>
          <span className="text-[11px] text-slate-500 mt-2 block">Achats ({totalPurchase.toLocaleString('fr-FR')} €) + Prépa ({totalPrepFees.toLocaleString('fr-FR')} €)</span>
        </div>

        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl">
          <span className="text-xs text-slate-400 block">Marge Nette Potentielle</span>
          <span className="text-2xl sm:text-3xl font-extrabold text-emerald-400 tabular-nums block mt-1">
            +{stats.potentialNetMargin.toLocaleString('fr-FR')} €
          </span>
          <span className="text-[11px] text-emerald-500/80 mt-2 block">Gain net après toutes charges</span>
        </div>

        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl">
          <span className="text-xs text-slate-400 block">Rentabilité Moyenne du Stock</span>
          <span className="text-2xl sm:text-3xl font-extrabold text-amber-400 tabular-nums block mt-1">
            {stats.averageMarginPercentage.toFixed(1)}%
          </span>
          <span className="text-[11px] text-slate-500 mt-2 block">Ratio Marge / Coûts de revient</span>
        </div>
      </div>

      {/* Preparation Cost Breakdown Grid */}
      <div className="p-6 bg-slate-900/70 border border-slate-800 rounded-2xl space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <PieChart className="w-4 h-4 text-amber-400" />
          Décomposition des Frais de Remise en État du Parc ({totalPrepFees.toLocaleString('fr-FR')} €)
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Truck className="w-3.5 h-3.5 text-amber-400" /> Transport & Convoyage
            </div>
            <div className="text-lg font-bold text-white tabular-nums mt-1">
              {totalTransport.toLocaleString('fr-FR')} €
            </div>
          </div>

          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Wrench className="w-3.5 h-3.5 text-blue-400" /> Révision & Mécanique
            </div>
            <div className="text-lg font-bold text-white tabular-nums mt-1">
              {totalMechanical.toLocaleString('fr-FR')} €
            </div>
          </div>

          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" /> Carrosserie & Detailing
            </div>
            <div className="text-lg font-bold text-white tabular-nums mt-1">
              {totalDetailing.toLocaleString('fr-FR')} €
            </div>
          </div>

          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Garanties Commerciales
            </div>
            <div className="text-lg font-bold text-white tabular-nums mt-1">
              {totalWarranties.toLocaleString('fr-FR')} €
            </div>
          </div>

          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <DollarSign className="w-3.5 h-3.5 text-rose-400" /> Contrôle Tech & SIV
            </div>
            <div className="text-lg font-bold text-white tabular-nums mt-1">
              {totalInspectionAdmin.toLocaleString('fr-FR')} €
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Vehicles Margin Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg space-y-4 p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white">Tableau Analytique Unitaire par Véhicule</h2>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1 rounded text-xs font-semibold cursor-pointer ${
                filterType === 'all' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-800'
              }`}
            >
              Tous
            </button>
            <button
              onClick={() => setFilterType('achat_revente')}
              className={`px-3 py-1 rounded text-xs font-semibold cursor-pointer ${
                filterType === 'achat_revente' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-800'
              }`}
            >
              Achat-Revente
            </button>
            <button
              onClick={() => setFilterType('depot_vente')}
              className={`px-3 py-1 rounded text-xs font-semibold cursor-pointer ${
                filterType === 'depot_vente' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-800'
              }`}
            >
              Dépôt-Vente
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-3">Véhicule</th>
                <th className="py-3 px-3">Activité</th>
                <th className="py-3 px-3 text-right">Achat / Net Vendeur Souhaité</th>
                <th className="py-3 px-3 text-right">Transport</th>
                <th className="py-3 px-3 text-right">Mécanique</th>
                <th className="py-3 px-3 text-right">Carrosserie</th>
                <th className="py-3 px-3 text-right">Garantie</th>
                <th className="py-3 px-3 text-right font-bold">Total Frais Parc</th>
                <th className="py-3 px-3 text-right font-bold">Prix Vente TTC</th>
                <th className="py-3 px-3 text-right font-bold">Marge / Comm. Nette</th>
                <th className="py-3 px-3 text-right">Rendement</th>
                <th className="py-3 px-3 text-center">Facture</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredVehicles.map((car) => {
                const baseAcquisition = car.businessType === 'depot_vente'
                  ? (car.sellerDesiredPrice || car.costs.purchasePrice)
                  : car.costs.purchasePrice;
                const prepFees = car.costs.transport + car.costs.reconditioning + car.costs.detailing + car.costs.inspection + car.costs.adminFees + car.costs.warrantyCost;
                const totalInvested = baseAcquisition + prepFees;
                const margin = car.sellingPrice - totalInvested;
                const marginPct = baseAcquisition > 0 ? (margin / baseAcquisition) * 100 : 0;

                return (
                  <tr 
                    key={car.id} 
                    onClick={() => onOpenVehicleModal(car)}
                    className="hover:bg-slate-800/60 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-3">
                      <div className="font-bold text-white">{car.brand} {car.model}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{car.registration}</div>
                    </td>
                    <td className="py-3 px-3 text-[11px]">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                        car.businessType === 'depot_vente' ? 'bg-purple-500/20 text-purple-300' : 'bg-blue-500/20 text-blue-300'
                      }`}>
                        {car.businessType === 'depot_vente' ? 'Dépôt-vente' : 'Achat direct'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums">
                      <div className="font-semibold text-slate-200">
                        {baseAcquisition.toLocaleString('fr-FR')} €
                      </div>
                      <div className="text-[10px] text-slate-500">
                        {car.businessType === 'depot_vente' ? 'Net vendeur' : 'Prix achat'}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                      {car.costs.transport.toLocaleString('fr-FR')} €
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                      {car.costs.reconditioning.toLocaleString('fr-FR')} €
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                      {car.costs.detailing.toLocaleString('fr-FR')} €
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums text-slate-400">
                      {car.costs.warrantyCost.toLocaleString('fr-FR')} €
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums font-semibold text-slate-200">
                      {totalInvested.toLocaleString('fr-FR')} €
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums font-bold text-white">
                      {Number(car.sellingPrice).toLocaleString('fr-FR')} €
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums font-bold">
                      <span className={margin >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                        +{margin.toLocaleString('fr-FR')} €
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums font-semibold">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        marginPct >= 12 ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' :
                        marginPct >= 6 ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30' :
                        'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                      }`}>
                        {marginPct.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                      {onOpenSendEmail && (
                        <button
                          onClick={() => onOpenSendEmail(car, 'facture_achat')}
                          title="Envoyer Facture d'Achat & Justificatif par email (tbdautos@gmail.com)"
                          className="p-1.5 hover:bg-slate-700 text-amber-400 hover:text-amber-300 rounded cursor-pointer"
                        >
                          <Mail className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Financial Report Modals */}
      {showGlobalReport && (
        <GlobalFinancialReportModal
          vehicles={vehicles}
          stats={stats}
          onClose={() => setShowGlobalReport(false)}
        />
      )}

      {showAccountingLedger && (
        <AccountingLedgerModal
          vehicles={vehicles}
          onClose={() => setShowAccountingLedger(false)}
        />
      )}

      {showSellerSettlement && (
        <SellerSettlementModal
          vehicles={vehicles}
          onClose={() => setShowSellerSettlement(false)}
        />
      )}

    </div>
  );
};
