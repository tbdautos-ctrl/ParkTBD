import React, { useState } from 'react';
import { Vehicle } from '../types';
import { api } from '../services/api';
import { Sparkles, Copy, Check, X, RefreshCw, Layers } from 'lucide-react';

interface AiAdGeneratorModalProps {
  vehicle: Vehicle | null;
  onClose: () => void;
  onSaveDescription?: (vehicleId: string, desc: string) => void;
}

export const AiAdGeneratorModal: React.FC<AiAdGeneratorModalProps> = ({
  vehicle,
  onClose,
  onSaveDescription
}) => {
  const [platform, setPlatform] = useState<'Leboncoin' | 'La Centrale' | 'Facebook Marketplace' | 'Autoscout24'>('Leboncoin');
  const [tone, setTone] = useState<'Professionnel & Vendeur' | 'Technique & Structuré' | 'Prestige & Émotion' | 'Court & Direct'>('Professionnel & Vendeur');
  const [generatedText, setGeneratedText] = useState<string>(vehicle?.aiDescription || '');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [providerUsed, setProviderUsed] = useState<string>('');

  const handleGenerate = async () => {
    if (!vehicle) return;
    setIsLoading(true);
    try {
      const result = await api.generateAiAd(vehicle, platform, tone);
      setGeneratedText(result.text);
      setProviderUsed(result.provider);
      if (onSaveDescription) {
        onSaveDescription(vehicle.id, result.text);
      }
    } catch (err) {
      console.error('Erreur génération', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!generatedText) return;
    navigator.clipboard.writeText(generatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (!vehicle) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                Générateur d'Annonces IA (Gemini)
              </h2>
              <p className="text-xs text-slate-400">
                {vehicle.brand} {vehicle.model} ({vehicle.version}) · Immat {vehicle.registration}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Configuration Controls */}
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Platform Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Portail de Vente Cible
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['Leboncoin', 'La Centrale', 'Facebook Marketplace', 'Autoscout24'] as const).map((plat) => (
                  <button
                    key={plat}
                    type="button"
                    onClick={() => setPlatform(plat)}
                    className={`px-3 py-2 rounded-lg text-xs font-medium text-left transition-all border cursor-pointer ${
                      platform === plat
                        ? 'bg-amber-500/15 border-amber-500/50 text-amber-300 shadow-sm'
                        : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {plat}
                  </button>
                ))}
              </div>
            </div>

            {/* Tone Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Ton de Rédaction
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['Professionnel & Vendeur', 'Technique & Structuré', 'Prestige & Émotion', 'Court & Direct'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTone(t)}
                    className={`px-3 py-2 rounded-lg text-xs font-medium text-left transition-all border cursor-pointer ${
                      tone === t
                        ? 'bg-amber-500/15 border-amber-500/50 text-amber-300 shadow-sm'
                        : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* TBD AUTOS Commercial Rules Banner */}
          <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-1.5 text-xs text-amber-200/90">
            <div className="font-bold text-amber-300 flex items-center gap-1.5">
              <span>✨ Règles Commerciales TBD AUTOS appliquées</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-300 pt-1">
              <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                <strong className="text-amber-400 block mb-0.5">Transparence Totale</strong>
                Mise en avant des qualités & mention honnête des éventuels défauts d'usage.
              </div>
              <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                <strong className="text-amber-400 block mb-0.5">Packs de Livraison</strong>
                Pack 1 (150 €) & Pack 2 (250 € + CG) systématiquement proposés en option.
              </div>
              <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                <strong className="text-amber-400 block mb-0.5">Négociation sur place</strong>
                Mention obligatoire : aucune négociation par téléphone, sur place uniquement.
              </div>
            </div>
          </div>

          {/* Trigger Generate Button */}
          <div className="flex items-center justify-between pt-1">
            <div className="text-xs text-slate-400 flex items-center gap-2">
              <Layers className="w-4 h-4 text-slate-500" />
              Structure standardisée en 7 blocs (Entête, Tarifs/Packs, Les +, Garantie, État, Options, Modalités).
            </div>
            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Rédaction en cours...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Générer l'Annonce pour {platform}
                </>
              )}
            </button>
          </div>

          {/* Output Text Area */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                Texte Prêt à Publier
                {providerUsed && (
                  <span className="text-[10px] text-slate-400 lowercase font-normal">
                    (moteur : {providerUsed})
                  </span>
                )}
              </label>
              {generatedText && (
                <button
                  onClick={handleCopy}
                  className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copié dans le presse-papier !</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      <span>Copier le texte</span>
                    </>
                  )}
                </button>
              )}
            </div>

            <textarea
              value={generatedText}
              onChange={(e) => setGeneratedText(e.target.value)}
              placeholder="Cliquez sur 'Générer l'Annonce' pour produire la description complète avec l'IA Gemini..."
              rows={14}
              className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-xs font-sans text-slate-200 leading-relaxed focus:outline-none focus:ring-1 focus:ring-amber-500 focus:border-amber-500 resize-y"
            />
          </div>

        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-950/60">
          <span className="text-xs text-slate-500">
            {generatedText ? `${generatedText.length} caractères · Recommandé pour ${platform}` : 'Prêt'}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Fermer
            </button>
            {generatedText && (
              <button
                onClick={handleCopy}
                className="px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
              >
                Copier & Publier
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
