import React, { useState, useEffect } from 'react';
import { Vehicle, SentEmailRecord, EmailDocType } from '../types';
import { 
  X, 
  Send, 
  Mail, 
  FileText, 
  CheckCircle2, 
  Paperclip, 
  Printer, 
  History, 
  Car, 
  Sparkles, 
  Building2, 
  Trash2, 
  ExternalLink,
  Plus,
  RefreshCw,
  AlertCircle
} from 'lucide-react';

interface SendDocumentEmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  vehicles: Vehicle[];
  initialVehicle?: Vehicle | null;
  initialDocType?: EmailDocType;
  sentEmails: SentEmailRecord[];
  onSendEmail: (email: Partial<SentEmailRecord>) => Promise<void>;
  onDeleteEmail?: (id: string) => Promise<void>;
}

export const SendDocumentEmailModal: React.FC<SendDocumentEmailModalProps> = ({
  isOpen,
  onClose,
  vehicles,
  initialVehicle = null,
  initialDocType = 'facture_achat',
  sentEmails,
  onSendEmail,
  onDeleteEmail
}) => {
  // Active Tab: 'compose' | 'preview_invoice' | 'history'
  const [activeTab, setActiveTab] = useState<'compose' | 'preview_invoice' | 'history'>('compose');

  // Selected vehicle
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>(
    initialVehicle ? initialVehicle.id : (vehicles[0]?.id || '')
  );

  const currentVehicle = vehicles.find(v => v.id === selectedVehicleId) || null;

  // Document type
  const [docType, setDocType] = useState<EmailDocType>(initialDocType);

  // Form Fields (Editable in real-time)
  const [recipientName, setRecipientName] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [messageBody, setMessageBody] = useState('');
  const [customAttachments, setCustomAttachments] = useState<{ name: string; size: string }[]>([]);
  const [selectedCheckboxes, setSelectedCheckboxes] = useState<{ [key: string]: boolean }>({
    factureAchat: true,
    carteGrise: true,
    nonGage: true,
    ct: false,
    mandat: false,
    ficheTechnique: true
  });

  const [isSending, setIsSending] = useState(false);
  const [sendSuccessMessage, setSendSuccessMessage] = useState<string | null>(null);
  const [selectedHistoryItem, setSelectedHistoryItem] = useState<SentEmailRecord | null>(null);
  const [historySearch, setHistorySearch] = useState('');

  // Default company constants
  const COMPANY_NAME = 'TBD AUTOS';
  const OFFICIAL_EMAIL = 'tbdautos@gmail.com';

  // Helper to generate template contents based on vehicle & docType
  const generateTemplate = (type: EmailDocType, veh: Vehicle | null) => {
    const brandModel = veh ? `${veh.brand} ${veh.model}` : 'Véhicule';
    const reg = veh?.registration || 'XX-000-XX';
    const vin = veh?.vin || 'VIN NON RENSEIGNÉ';
    const year = veh?.year || new Date().getFullYear();
    const mileage = veh ? Number(veh.mileage || 0).toLocaleString('fr-FR') : '0';
    const purchasePrice = veh ? Number(veh.costs?.purchasePrice || 0).toLocaleString('fr-FR') : '0';
    const sellingPrice = veh ? Number(veh.sellingPrice || 0).toLocaleString('fr-FR') : '0';
    const netSeller = veh?.sellerDesiredPrice ? Number(veh.sellerDesiredPrice).toLocaleString('fr-FR') : '0';
    const guarantee = veh?.guarantee || 'Garantie 12 Mois';
    const optionsText = veh?.keyOptions?.length 
      ? veh.keyOptions.slice(0, 4).map(o => `  • ${o}`).join('\n')
      : '  • Finition haut de gamme & équipements complets';

    let subj = '';
    let body = '';

    switch (type) {
      case 'facture_achat':
        subj = `[${COMPANY_NAME}] Facture d'achat acquittée & Justificatif d'acquisition - ${brandModel} (${reg})`;
        body = `Bonjour,

Veuillez trouver ci-joint la facture d'achat acquittée ainsi que le dossier d'acquisition du véhicule entré en stock chez ${COMPANY_NAME} :

• Véhicule : ${brandModel} ${veh?.version || ''}
• Immatriculation : ${reg}
• Numéro de série (VIN) : ${vin}
• Kilométrage compteur : ${mileage} km
• Montant d'achat réglé : ${purchasePrice} €
• Régime fiscal : TVA sur la marge (Art. 297 A du CGI)

Documents joints au présent envoi :
- Facture d'achat originale / Bordereau d'acquisition acquitté
- Certificat de cession et déclaration d'achat SIV

Ce document atteste du règlement intégral et du transfert de propriété au bénéfice de ${COMPANY_NAME}.

Restant à votre entière disposition pour tout complément comptable ou administratif.

Bien cordialement,
L'équipe ${COMPANY_NAME}
Email : ${OFFICIAL_EMAIL}
PARKTBD - Logiciel de Contrôle & Gestion de Stock`;
        break;

      case 'dossier_administratif':
        subj = `[${COMPANY_NAME}] Dossier administratif complet SIV - ${brandModel} (${reg})`;
        body = `Bonjour,

Veuillez trouver ci-joint l'ensemble des documents administratifs et réglementaires pour le véhicule suivant :

• Véhicule : ${brandModel} (${year})
• Immatriculation : ${reg}
• Numéro de châssis (VIN) : ${vin}
• Kilométrage certifié : ${mileage} km

Pièces jointes incluses dans ce dossier :
- Certificat d'immatriculation (Carte grise originale / récépissé DA SIV)
- Certificat de situation administrative (Non-gage valide de moins de 15 jours)
- Rapport de Contrôle Technique en cours de validité
- Certificat de cession officiel (Cerfa 15776*02)

L'ensemble des pièces a fait l'objet d'un contrôle de conformité par le service administratif de ${COMPANY_NAME}.

Restant à votre écoute pour toute démarche d'immatriculation.

Bien cordialement,
Service Administratif - ${COMPANY_NAME}
Email : ${OFFICIAL_EMAIL}`;
        break;

      case 'facture_vente':
        subj = `[${COMPANY_NAME}] Facture de vente & Bon de commande client - ${brandModel} (${reg})`;
        body = `Bonjour ${recipientName ? recipientName : 'Madame, Monsieur'},

Nous vous remercions pour votre confiance accordée à ${COMPANY_NAME} pour l'acquisition de votre véhicule.

Veuillez trouver ci-joint votre facture officielle de vente ainsi que le récapitulatif de votre commande :

• Modèle acquis : ${brandModel} ${veh?.version || ''}
• Immatriculation : ${reg}
• Année : ${year} | Kilométrage : ${mileage} km
• Prix de vente TTC convenu : ${sellingPrice} €
• Couverture commerciale : ${guarantee}

Modalités administratives & livraison :
Notre atelier procède aux derniers contrôles de préparation avant la mise en main. Votre carte grise définitive sera acheminée directement à votre domicile par l'Imprimerie Nationale.

Bien cordialement,
Service Commercial - ${COMPANY_NAME}
Email : ${OFFICIAL_EMAIL}`;
        break;

      case 'mandat_depot_vente':
        subj = `[${COMPANY_NAME}] Mandat de dépôt-vente & Engagement de commercialisation - ${brandModel}`;
        body = `Bonjour ${recipientName ? recipientName : 'Cher Client'},

Dans le cadre du contrat d'intermédiation de vente confié à ${COMPANY_NAME}, vous trouverez ci-joint votre mandat officiel de dépôt-vente :

• Véhicule confié : ${brandModel}
• Immatriculation : ${reg}
• Montant net vendeur garanti : ${netSeller} €
• Prix de vente public affiché sur notre parc : ${sellingPrice} €
• Commission & Frais d'intermédiation ${COMPANY_NAME} : ${veh?.brokerageFee ? Number(veh.brokerageFee).toLocaleString('fr-FR') + ' €' : 'Inclus'}

Engagements de ${COMPANY_NAME} :
- Contrôle rigoureux et préparation esthétique
- Shooting photo HD et multidiffusion sur l'ensemble de nos portails partenaires
- Gestion intégrale des visites, essais clients et sécurisation des fonds

Merci de nous retourner un exemplaire paraphé et signé.

Bien cordialement,
Direction ${COMPANY_NAME}
Email : ${OFFICIAL_EMAIL}`;
        break;

      case 'fiche_technique_brochure':
        subj = `[${COMPANY_NAME}] Présentation détaillée & Fiche commerciale - ${brandModel} (${year})`;
        body = `Bonjour,

Suite à votre intérêt pour notre ${brandModel}, vous trouverez ci-joint la présentation détaillée du véhicule ainsi que ses caractéristiques complètes :

• Véhicule : ${brandModel} ${veh?.version || ''}
• Année : ${year} | Kilométrage : ${mileage} km
• Énergie : ${veh?.fuel || 'Essence'} | Boîte : ${veh?.gearbox || 'Automatique'}
• Puissance : ${veh?.powerDin || 0} ch (${veh?.powerFiscal || 0} CV)
• Prix de vente : ${sellingPrice} € TTC ${veh?.monthlyEstimate ? `(ou dès ${veh.monthlyEstimate} €/mois)` : ''}
• Garantie : ${guarantee}

Options et points forts :
${optionsText}

Le véhicule est visible dans notre showroom ${COMPANY_NAME}. Nous serions ravis de convenir d'un rendez-vous pour un essai sur route à votre convenance.

Bien cordialement,
L'équipe commerciale ${COMPANY_NAME}
Email : ${OFFICIAL_EMAIL}`;
        break;

      case 'autre':
      default:
        subj = `[${COMPANY_NAME}] Demande de pièces justificatives - Dossier ${brandModel} (${reg})`;
        body = `Bonjour,

Afin de finaliser les démarches d'immatriculation SIV et la constitution de votre dossier chez ${COMPANY_NAME} pour le véhicule ${brandModel} (${reg}), merci de nous faire parvenir par retour d'e-mail les éléments suivants :

1. Pièce d'identité en cours de validité recto/verso (CNI ou Passeport)
2. Justificatif de domicile de moins de 3 mois (Facture électricité, eau, téléphone ou avis d'imposition)
3. Copie recto/verso de votre permis de conduire
4. Attestation d'assurance pour la prise en charge du véhicule

Dès réception de ces pièces, notre équipe administrative validera votre dossier sous 24h.

Restant à votre entière disposition,

Bien cordialement,
Service Administratif - ${COMPANY_NAME}
Email : ${OFFICIAL_EMAIL}`;
        break;
    }

    return { subj, body };
  };

  // Re-populate template when changing docType or vehicle
  useEffect(() => {
    const { subj, body } = generateTemplate(docType, currentVehicle);
    setSubject(subj);
    setMessageBody(body);

    // Set default recipient if vehicle has buyer or default contacts
    if (docType === 'facture_achat') {
      setRecipientName('Service Comptabilité / Gestion');
      setRecipientEmail('comptabilite@cabinet-expert.fr');
    } else if (docType === 'mandat_depot_vente') {
      setRecipientName('Client Vendeur');
      setRecipientEmail('');
    } else if (currentVehicle?.buyerName && docType === 'facture_vente') {
      setRecipientName(currentVehicle.buyerName);
      setRecipientEmail('');
    }
  }, [docType, selectedVehicleId]);

  // Compute Active Attachments List
  const computedAttachments = () => {
    const list: { name: string; size: string }[] = [];

    if (selectedCheckboxes.factureAchat && currentVehicle) {
      list.push({
        name: `Facture_Achat_${currentVehicle.brand}_${currentVehicle.registration.replace(/-/g, '')}.pdf`,
        size: '1.2 Mo'
      });
    }

    if (selectedCheckboxes.carteGrise && currentVehicle) {
      list.push({
        name: `Certificat_Immatriculation_${currentVehicle.registration}.pdf`,
        size: '980 Ko'
      });
    }

    if (selectedCheckboxes.nonGage && currentVehicle) {
      list.push({
        name: `Certificat_Non_Gage_${currentVehicle.registration}.pdf`,
        size: '410 Ko'
      });
    }

    if (selectedCheckboxes.ct && currentVehicle) {
      list.push({
        name: `Proces_Verbal_Controle_Technique_${currentVehicle.registration}.pdf`,
        size: '1.5 Mo'
      });
    }

    if (selectedCheckboxes.mandat && currentVehicle) {
      list.push({
        name: `Mandat_Depot_Vente_TBD_AUTOS_${currentVehicle.registration}.pdf`,
        size: '620 Ko'
      });
    }

    if (selectedCheckboxes.ficheTechnique && currentVehicle) {
      list.push({
        name: `Fiche_Presentation_Client_${currentVehicle.brand}_${currentVehicle.model}.pdf`,
        size: '2.1 Mo'
      });
    }

    // Attach documents uploaded to the vehicle if any
    if (currentVehicle?.documentFiles) {
      currentVehicle.documentFiles.forEach(f => {
        list.push({ name: f.name, size: f.size || 'Fichier' });
      });
    }

    // Custom user added attachments
    list.push(...customAttachments);

    return list;
  };

  // Handle direct file upload in modal
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newItems: { name: string; size: string }[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const sizeStr = file.size > 1024 * 1024 
        ? `${(file.size / (1024 * 1024)).toFixed(1)} Mo`
        : `${Math.round(file.size / 1024)} Ko`;
      newItems.push({ name: file.name, size: sizeStr });
    }
    setCustomAttachments(prev => [...prev, ...newItems]);
  };

  // Send action (via backend API + SSE sync)
  const handleSend = async () => {
    if (!recipientEmail || !recipientEmail.includes('@')) {
      alert('Veuillez renseigner une adresse email valide pour le destinataire.');
      return;
    }

    setIsSending(true);
    try {
      const attachments = computedAttachments();
      const newEmail: Partial<SentEmailRecord> = {
        from: OFFICIAL_EMAIL,
        fromName: COMPANY_NAME,
        to: recipientEmail.trim(),
        recipientName: recipientName.trim() || recipientEmail.trim(),
        vehicleId: currentVehicle?.id,
        vehicleName: currentVehicle ? `${currentVehicle.brand} ${currentVehicle.model} (${currentVehicle.registration})` : undefined,
        docType,
        subject: subject.trim(),
        message: messageBody.trim(),
        attachments,
        sentAt: new Date().toISOString(),
        status: 'envoye'
      };

      await onSendEmail(newEmail);
      setSendSuccessMessage(`Message et documents transmis avec succès à ${recipientEmail} depuis ${OFFICIAL_EMAIL} !`);
      setTimeout(() => {
        setSendSuccessMessage(null);
        setActiveTab('history');
      }, 1500);
    } catch (err: any) {
      console.error('Erreur envoi email', err);
      alert('Erreur lors de l\'envoi : ' + (err.message || 'vérifiez votre connexion'));
    } finally {
      setIsSending(false);
    }
  };

  // Open in user's default email client (mailto link)
  const handleOpenMailto = () => {
    const to = encodeURIComponent(recipientEmail.trim());
    const subj = encodeURIComponent(subject.trim());
    const body = encodeURIComponent(messageBody.trim());
    const mailtoUrl = `mailto:${to}?subject=${subj}&body=${body}`;
    window.location.href = mailtoUrl;
  };

  // Quick insertion tag in message body
  const insertTag = (tag: string) => {
    setMessageBody(prev => prev + ' ' + tag);
  };

  // Filter sent emails
  const filteredSentEmails = sentEmails.filter(e => {
    const q = historySearch.toLowerCase();
    return (
      e.to.toLowerCase().includes(q) ||
      e.recipientName.toLowerCase().includes(q) ||
      e.subject.toLowerCase().includes(q) ||
      (e.vehicleName && e.vehicleName.toLowerCase().includes(q))
    );
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh]">
        
        {/* Top Header */}
        <div className="px-6 py-4 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-black text-lg flex items-center justify-center shadow-md">
              <Mail className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white tracking-tight uppercase">
                  {COMPANY_NAME} <span className="text-amber-400 text-sm font-bold">· PARKTBD</span>
                </h2>
                <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                  Expéditeur certifié : {OFFICIAL_EMAIL}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Envoi de factures d'achat, documents administratifs et fiches clients avec messages pré-inscrits personnalisables
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Tab switchers */}
            <div className="flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700/60 text-xs">
              <button
                onClick={() => setActiveTab('compose')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'compose' ? 'bg-amber-400 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Rédiger & Envoyer</span>
              </button>

              <button
                onClick={() => setActiveTab('preview_invoice')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'preview_invoice' ? 'bg-amber-400 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Aperçu Facture Achat</span>
              </button>

              <button
                onClick={() => setActiveTab('history')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'history' ? 'bg-amber-400 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                <span>Journal d'envois ({sentEmails.length})</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Success toast if just sent */}
        {sendSuccessMessage && (
          <div className="bg-emerald-500/20 border-b border-emerald-500/30 px-6 py-2.5 text-xs text-emerald-300 flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{sendSuccessMessage}</span>
          </div>
        )}

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6">
          
          {/* TAB 1: COMPOSE & SEND */}
          {activeTab === 'compose' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Column: Context, Vehicle & Template Selection */}
              <div className="lg:col-span-5 space-y-5">
                
                {/* Vehicle Selection Card */}
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Car className="w-4 h-4 text-amber-400" />
                    <span>Véhicule concerné</span>
                  </label>
                  <select
                    value={selectedVehicleId}
                    onChange={(e) => setSelectedVehicleId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 cursor-pointer"
                  >
                    {vehicles.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.brand} {v.model} ({v.registration}) · {v.businessType === 'achat_revente' ? 'Stock Propre' : 'Dépôt-Vente'}
                      </option>
                    ))}
                  </select>

                  {currentVehicle && (
                    <div className="mt-3 p-3 bg-slate-900/80 rounded-lg border border-slate-800/80 text-xs space-y-1">
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">VIN :</span>
                        <span className="font-mono font-bold text-slate-200">{currentVehicle.vin}</span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Activité :</span>
                        <span className="font-semibold text-amber-400">
                          {currentVehicle.businessType === 'achat_revente' ? 'Achat - Revente' : 'Dépôt - Vente'}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">
                          {currentVehicle.businessType === 'achat_revente' ? 'Prix d\'achat :' : 'Net vendeur souhaité :'}
                        </span>
                        <span className="font-bold text-emerald-400">
                          {currentVehicle.businessType === 'achat_revente' 
                            ? `${Number(currentVehicle.costs?.purchasePrice || 0).toLocaleString('fr-FR')} €`
                            : `${Number(currentVehicle.sellerDesiredPrice || 0).toLocaleString('fr-FR')} €`}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Prix de vente affiché :</span>
                        <span className="font-bold text-white">
                          {Number(currentVehicle.sellingPrice || 0).toLocaleString('fr-FR')} € TTC
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Template Selector Card (Pre-inscribed messages) */}
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>Modèle de message pré-inscrit</span>
                    </label>
                    <button
                      onClick={() => {
                        const { subj, body } = generateTemplate(docType, currentVehicle);
                        setSubject(subj);
                        setMessageBody(body);
                      }}
                      className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                      title="Réinitialiser au message pré-inscrit par défaut"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Réinitialiser</span>
                    </button>
                  </div>

                  <div className="space-y-1.5">
                    <button
                      type="button"
                      onClick={() => setDocType('facture_achat')}
                      className={`w-full text-left p-2.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                        docType === 'facture_achat' 
                          ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold' 
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-white">1. Facture d'achat & Acquisition</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Pour comptable, expert-comptable ou fournisseur avec mentions SIV & TVA marge</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDocType('dossier_administratif')}
                      className={`w-full text-left p-2.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                        docType === 'dossier_administratif' 
                          ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold' 
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-white">2. Dossier administratif complet</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Carte grise, certificat de non-gage valide, contrôle technique et cession</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDocType('facture_vente')}
                      className={`w-full text-left p-2.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                        docType === 'facture_vente' 
                          ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold' 
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-white">3. Facture de vente & Bon de commande</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Destinée à l'acheteur avec récapitulatif du solde et garanties</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDocType('mandat_depot_vente')}
                      className={`w-full text-left p-2.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                        docType === 'mandat_depot_vente' 
                          ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold' 
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-white">4. Mandat de dépôt-vente (Client vendeur)</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Spécifie le montant net vendeur convenu et engagements de commercialisation</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDocType('fiche_technique_brochure')}
                      className={`w-full text-left p-2.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                        docType === 'fiche_technique_brochure' 
                          ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold' 
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-white">5. Fiche technique & Brochure commerciale</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Présentation prestigieuse pour prospect client avec options et photos</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDocType('autre')}
                      className={`w-full text-left p-2.5 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                        docType === 'autre' 
                          ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold' 
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-white">6. Demande de pièces justificatives</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Demande de CNI, permis et justificatif de domicile pour carte grise</div>
                    </button>
                  </div>
                </div>

                {/* Attachments Checklist */}
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2.5">
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Paperclip className="w-4 h-4 text-amber-400" />
                      <span>Documents & Pièces jointes</span>
                    </label>
                    <label className="text-[11px] text-amber-400 hover:text-amber-300 font-semibold cursor-pointer flex items-center gap-1">
                      <Plus className="w-3.5 h-3.5" />
                      <span>Ajouter un fichier</span>
                      <input type="file" multiple className="hidden" onChange={handleFileUpload} />
                    </label>
                  </div>

                  <div className="space-y-2 text-xs">
                    <label className="flex items-center justify-between p-2 rounded bg-slate-900 hover:bg-slate-850 cursor-pointer">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedCheckboxes.factureAchat}
                          onChange={(e) => setSelectedCheckboxes({ ...selectedCheckboxes, factureAchat: e.target.checked })}
                          className="rounded text-amber-400 focus:ring-0"
                        />
                        <span className="text-slate-200">Facture d'achat / Bordereau d'acquisition {COMPANY_NAME}</span>
                      </div>
                      <span className="text-slate-500 text-[10px]">PDF · 1.2 Mo</span>
                    </label>

                    <label className="flex items-center justify-between p-2 rounded bg-slate-900 hover:bg-slate-850 cursor-pointer">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedCheckboxes.carteGrise}
                          onChange={(e) => setSelectedCheckboxes({ ...selectedCheckboxes, carteGrise: e.target.checked })}
                          className="rounded text-amber-400 focus:ring-0"
                        />
                        <span className="text-slate-200">Certificat d'immatriculation (Carte Grise SIV)</span>
                      </div>
                      <span className="text-slate-500 text-[10px]">PDF · 980 Ko</span>
                    </label>

                    <label className="flex items-center justify-between p-2 rounded bg-slate-900 hover:bg-slate-850 cursor-pointer">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedCheckboxes.nonGage}
                          onChange={(e) => setSelectedCheckboxes({ ...selectedCheckboxes, nonGage: e.target.checked })}
                          className="rounded text-amber-400 focus:ring-0"
                        />
                        <span className="text-slate-200">Certificat de non-gage administratif</span>
                      </div>
                      <span className="text-slate-500 text-[10px]">PDF · 410 Ko</span>
                    </label>

                    <label className="flex items-center justify-between p-2 rounded bg-slate-900 hover:bg-slate-850 cursor-pointer">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedCheckboxes.ct}
                          onChange={(e) => setSelectedCheckboxes({ ...selectedCheckboxes, ct: e.target.checked })}
                          className="rounded text-amber-400 focus:ring-0"
                        />
                        <span className="text-slate-200">Procès-verbal de Contrôle Technique</span>
                      </div>
                      <span className="text-slate-500 text-[10px]">PDF · 1.5 Mo</span>
                    </label>

                    <label className="flex items-center justify-between p-2 rounded bg-slate-900 hover:bg-slate-850 cursor-pointer">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedCheckboxes.mandat}
                          onChange={(e) => setSelectedCheckboxes({ ...selectedCheckboxes, mandat: e.target.checked })}
                          className="rounded text-amber-400 focus:ring-0"
                        />
                        <span className="text-slate-200">Mandat de vente Dépôt-Vente {COMPANY_NAME}</span>
                      </div>
                      <span className="text-slate-500 text-[10px]">PDF · 620 Ko</span>
                    </label>

                    <label className="flex items-center justify-between p-2 rounded bg-slate-900 hover:bg-slate-850 cursor-pointer">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedCheckboxes.ficheTechnique}
                          onChange={(e) => setSelectedCheckboxes({ ...selectedCheckboxes, ficheTechnique: e.target.checked })}
                          className="rounded text-amber-400 focus:ring-0"
                        />
                        <span className="text-slate-200">Fiche de présentation client complète (PDF)</span>
                      </div>
                      <span className="text-slate-500 text-[10px]">PDF · 2.1 Mo</span>
                    </label>

                    {/* Custom user files */}
                    {customAttachments.map((f, i) => (
                      <div key={i} className="flex items-center justify-between p-2 rounded bg-amber-950/20 border border-amber-500/20">
                        <span className="text-amber-200 truncate pr-2">📎 {f.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-400 text-[10px]">{f.size}</span>
                          <button
                            type="button"
                            onClick={() => setCustomAttachments(prev => prev.filter((_, idx) => idx !== i))}
                            className="text-slate-400 hover:text-rose-400 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Right Column: Editable Message, Header & Sender Form */}
              <div className="lg:col-span-7 flex flex-col space-y-4">
                
                {/* Email Metadata Box */}
                <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                  
                  {/* Sender Row */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400 w-24">Expéditeur :</span>
                      <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 border border-slate-700/80 rounded-md text-xs">
                        <Building2 className="w-3.5 h-3.5 text-amber-400" />
                        <span className="font-bold text-white">{COMPANY_NAME}</span>
                        <span className="text-slate-400 font-mono text-[11px]">&lt;{OFFICIAL_EMAIL}&gt;</span>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-400">
                      Application : <span className="font-bold text-slate-300">PARKTBD</span>
                    </div>
                  </div>

                  {/* Recipient Row */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 mb-1">
                        Nom du destinataire :
                      </label>
                      <input
                        type="text"
                        value={recipientName}
                        onChange={(e) => setRecipientName(e.target.value)}
                        placeholder="Ex: Cabinet Comptable / M. Dupont"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 mb-1">
                        Email destinataire <span className="text-amber-400">*</span> :
                      </label>
                      <input
                        type="email"
                        value={recipientEmail}
                        onChange={(e) => setRecipientEmail(e.target.value)}
                        placeholder="destinataire@exemple.com"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                        required
                      />
                    </div>
                  </div>

                  {/* Subject Line (Fully editable) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">
                      Objet du message (modifiable) :
                    </label>
                    <input
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400 font-medium"
                    />
                  </div>

                </div>

                {/* Body Message Editor */}
                <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex-1 flex flex-col">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      Corps du message (100% modifiable en direct)
                    </label>
                    
                    {/* Quick variables buttons */}
                    <div className="hidden sm:flex items-center gap-1.5 text-[10px]">
                      <span className="text-slate-500">Insérer :</span>
                      {currentVehicle && (
                        <>
                          <button
                            type="button"
                            onClick={() => insertTag(`[${currentVehicle.registration}]`)}
                            className="px-1.5 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded cursor-pointer"
                          >
                            Immat
                          </button>
                          <button
                            type="button"
                            onClick={() => insertTag(`[VIN: ${currentVehicle.vin}]`)}
                            className="px-1.5 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded cursor-pointer"
                          >
                            VIN
                          </button>
                          <button
                            type="button"
                            onClick={() => insertTag(`[Prix Achat: ${Number(currentVehicle.costs?.purchasePrice || 0).toLocaleString('fr-FR')} €]`)}
                            className="px-1.5 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded cursor-pointer"
                          >
                            Prix Achat
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  <textarea
                    rows={12}
                    value={messageBody}
                    onChange={(e) => setMessageBody(e.target.value)}
                    className="w-full flex-1 bg-slate-900 border border-slate-700 rounded-lg p-3 text-xs text-slate-100 font-sans leading-relaxed focus:outline-none focus:border-amber-400 resize-none font-mono"
                    placeholder="Tapez ou personnalisez votre message..."
                  />

                  {/* Attachment pills preview */}
                  <div className="mt-3 pt-3 border-t border-slate-800/80">
                    <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
                      <span>Pièces jointes qui seront associées à l'envoi :</span>
                      <span className="font-bold text-amber-400">{computedAttachments().length} document(s)</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto">
                      {computedAttachments().map((att, idx) => (
                        <div key={idx} className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-slate-300">
                          <FileText className="w-3 h-3 text-amber-400 shrink-0" />
                          <span className="truncate max-w-[180px]">{att.name}</span>
                          <span className="text-slate-500">({att.size})</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                  <div className="text-xs text-slate-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>L'envoi sera archivé dans le journal et synchronisé sur tous vos écrans.</span>
                  </div>

                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    {/* Mailto local client button */}
                    <button
                      type="button"
                      onClick={handleOpenMailto}
                      className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
                      title="Ouvre votre logiciel de messagerie local (Outlook, Apple Mail, etc.)"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Ouvrir dans mon mail (mailto)</span>
                    </button>

                    {/* Primary direct send button */}
                    <button
                      type="button"
                      onClick={handleSend}
                      disabled={isSending}
                      className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-black tracking-wide shadow-lg shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                      <span>{isSending ? 'Transmission en cours...' : `Envoyer via ${COMPANY_NAME}`}</span>
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB 2: PREVIEW OFFICIAL PURCHASE INVOICE (FACTURE D'ACHAT) */}
          {activeTab === 'preview_invoice' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Facture d'Achat & Bordereau d'Acquisition Officiel · {COMPANY_NAME}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Document légal certifié conforme pour justification comptable et déclaration d'achat SIV
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Imprimer / Télécharger en PDF</span>
                </button>
              </div>

              {/* Printable Invoice Sheet */}
              <div className="bg-white text-slate-950 p-8 rounded-xl shadow-xl max-w-4xl mx-auto border border-slate-300 print:border-none print:shadow-none">
                {/* Header */}
                <div className="flex justify-between items-start border-b-2 border-slate-900 pb-6 mb-6">
                  <div>
                    <h1 className="text-3xl font-black tracking-tight text-slate-950 uppercase">
                      {COMPANY_NAME}
                    </h1>
                    <p className="text-xs text-slate-600 font-semibold uppercase tracking-wider mt-0.5">
                      Négoce & Contrôle Automobile · PARKTBD
                    </p>
                    <div className="text-xs text-slate-600 mt-2 space-y-0.5">
                      <p><strong>Email :</strong> {OFFICIAL_EMAIL}</p>
                      <p><strong>SIRET :</strong> 912 345 678 00019 · RCS Paris</p>
                      <p><strong>TVA Intracommunautaire :</strong> FR 89 912345678</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="inline-block bg-slate-950 text-white text-xs font-black uppercase px-3 py-1 rounded">
                      Facture d'Achat Acquittée
                    </span>
                    <p className="font-mono text-sm font-bold text-slate-900 mt-2">
                      RÉF : FAC-ACH-{currentVehicle ? currentVehicle.registration.replace(/-/g, '') : '2024'}-{currentVehicle ? currentVehicle.year : '01'}
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      Date d'acquisition : {currentVehicle ? currentVehicle.entryDate : new Date().toISOString().slice(0, 10)}
                    </p>
                    <p className="text-xs text-slate-500">
                      Régime fiscal : <strong>TVA sur marge (Art. 297 A CGI)</strong>
                    </p>
                  </div>
                </div>

                {/* Identification Véhicule */}
                {currentVehicle ? (
                  <div className="mb-6">
                    <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 bg-slate-100 p-2 rounded mb-3">
                      1. Identification Complète du Véhicule Acquis
                    </h2>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                      <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                        <span className="text-slate-500 block text-[10px] uppercase font-bold">Marque & Modèle</span>
                        <span className="font-bold text-sm text-slate-900">{currentVehicle.brand} {currentVehicle.model}</span>
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                        <span className="text-slate-500 block text-[10px] uppercase font-bold">Immatriculation</span>
                        <span className="font-mono font-bold text-sm text-amber-600">{currentVehicle.registration}</span>
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                        <span className="text-slate-500 block text-[10px] uppercase font-bold">Numéro de Série (VIN)</span>
                        <span className="font-mono font-bold text-xs text-slate-900">{currentVehicle.vin}</span>
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                        <span className="text-slate-500 block text-[10px] uppercase font-bold">Kilométrage Compteur</span>
                        <span className="font-bold text-sm text-slate-900">{Number(currentVehicle.mileage || 0).toLocaleString('fr-FR')} km</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mt-2 text-[11px] text-slate-600">
                      <div><strong>Énergie :</strong> {currentVehicle.fuel}</div>
                      <div><strong>Boîte :</strong> {currentVehicle.gearbox}</div>
                      <div><strong>Puissance :</strong> {currentVehicle.powerDin} ch ({currentVehicle.powerFiscal} CV)</div>
                      <div><strong>Couleur :</strong> {currentVehicle.colorExterior}</div>
                      <div><strong>Crit'Air :</strong> {currentVehicle.critAir}</div>
                      <div><strong>Mise en circ. :</strong> {currentVehicle.firstRegistrationDate}</div>
                    </div>
                  </div>
                ) : (
                  <p className="text-slate-500 text-xs mb-4">Veuillez sélectionner un véhicule dans le menu.</p>
                )}

                {/* Tableau financier */}
                <div className="mb-6">
                  <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 bg-slate-100 p-2 rounded mb-3">
                    2. Décompte Financier de la Transaction
                  </h2>
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="border-b-2 border-slate-900 text-left">
                        <th className="py-2 px-3 font-bold text-slate-700">Désignation</th>
                        <th className="py-2 px-3 font-bold text-slate-700">Régime fiscal</th>
                        <th className="py-2 px-3 text-right font-bold text-slate-700">Montant</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      <tr>
                        <td className="py-2.5 px-3 font-bold text-slate-900">
                          {currentVehicle?.businessType === 'achat_revente' 
                            ? 'Prix d\'acquisition véhicule d\'occasion'
                            : 'Prix de reprise net vendeur garanti (Dépôt-Vente)'}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600">TVA sur la marge (CGI 297 A)</td>
                        <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                          {currentVehicle ? (
                            currentVehicle.businessType === 'achat_revente'
                              ? `${Number(currentVehicle.costs?.purchasePrice || 0).toLocaleString('fr-FR')} €`
                              : `${Number(currentVehicle.sellerDesiredPrice || 0).toLocaleString('fr-FR')} €`
                          ) : '0 €'}
                        </td>
                      </tr>
                      {currentVehicle && currentVehicle.costs?.transport > 0 && (
                        <tr>
                          <td className="py-2 px-3 text-slate-600">Frais de convoyage & transport sécurisé</td>
                          <td className="py-2 px-3 text-slate-600">Prestation intégrée</td>
                          <td className="py-2 px-3 text-right text-slate-700">{Number(currentVehicle.costs.transport).toLocaleString('fr-FR')} €</td>
                        </tr>
                      )}
                      {currentVehicle && currentVehicle.costs?.adminFees > 0 && (
                        <tr>
                          <td className="py-2 px-3 text-slate-600">Frais d'enregistrement et certificat SIV</td>
                          <td className="py-2 px-3 text-slate-600">Frais légaux</td>
                          <td className="py-2 px-3 text-right text-slate-700">{Number(currentVehicle.costs.adminFees).toLocaleString('fr-FR')} €</td>
                        </tr>
                      )}
                      <tr className="border-t-2 border-slate-900 bg-slate-50 font-bold">
                        <td className="py-3 px-3 text-sm text-slate-950 uppercase" colSpan={2}>
                          Total Décaissé & Acquitté par {COMPANY_NAME}
                        </td>
                        <td className="py-3 px-3 text-right text-base text-slate-950">
                          {currentVehicle ? (
                            currentVehicle.businessType === 'achat_revente'
                              ? `${Number(currentVehicle.costs?.purchasePrice || 0).toLocaleString('fr-FR')} €`
                              : `${Number(currentVehicle.sellerDesiredPrice || 0).toLocaleString('fr-FR')} €`
                          ) : '0 €'}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Mentions légales & Signatures */}
                <div className="pt-4 border-t border-slate-200">
                  <div className="text-[10px] text-slate-500 space-y-1 mb-8">
                    <p>• Déclaration d'achat effectuée dans le Système d'Immatriculation des Véhicules (SIV).</p>
                    <p>• Le cédant certifie sur l'honneur être propriétaire du bien, libre de tout gage, opposition ou nantissement.</p>
                    <p>• Règlement effectué par virement bancaire sécurisé émis par {COMPANY_NAME}.</p>
                  </div>

                  <div className="grid grid-cols-2 gap-8 text-xs pt-4 border-t border-slate-300">
                    <div className="border border-slate-300 p-4 rounded min-h-[100px]">
                      <span className="font-bold uppercase text-slate-700 block mb-1">Pour le cédant / vendeur :</span>
                      <p className="text-[11px] text-slate-500 italic">Signature précédée de la mention "Bon pour cession et règlement reçu" :</p>
                    </div>

                    <div className="border border-slate-300 p-4 rounded min-h-[100px] text-right">
                      <span className="font-bold uppercase text-slate-700 block mb-1">Pour {COMPANY_NAME} (L'acquéreur) :</span>
                      <p className="text-[11px] text-slate-500 italic">Cachet commercial & signature autorisée :</p>
                      <div className="mt-4 text-[11px] font-black text-slate-900 uppercase">
                        {COMPANY_NAME} · Direction
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 3: SENT EMAILS HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <History className="w-4 h-4 text-amber-400" />
                    <span>Journal des Factures & Documents Envoyés</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Historique de tous les e-mails transmis depuis <strong>{OFFICIAL_EMAIL}</strong>
                  </p>
                </div>

                <div className="w-full sm:w-64">
                  <input
                    type="text"
                    value={historySearch}
                    onChange={(e) => setHistorySearch(e.target.value)}
                    placeholder="Rechercher destinataire, objet..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {filteredSentEmails.length === 0 ? (
                <div className="p-12 text-center bg-slate-950/40 rounded-xl border border-slate-800/80">
                  <Mail className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-400">Aucun e-mail envoyé correspondant à votre recherche.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredSentEmails.map((item) => (
                    <div 
                      key={item.id} 
                      className={`p-4 rounded-xl border transition-all cursor-pointer ${
                        selectedHistoryItem?.id === item.id 
                          ? 'bg-slate-850 border-amber-400 shadow-md' 
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                      }`}
                      onClick={() => setSelectedHistoryItem(item)}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                            <CheckCircle2 className="w-3 h-3" />
                            Envoyé
                          </span>
                          <span className="text-[11px] font-bold text-slate-300">
                            {item.recipientName}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-500">
                          {new Date(item.sentAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <div className="text-xs font-bold text-white mb-1 truncate">
                        {item.subject}
                      </div>

                      <div className="text-[11px] text-slate-400 truncate mb-2">
                        À : <span className="font-mono text-slate-300">{item.to}</span>
                      </div>

                      {item.vehicleName && (
                        <div className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-300 bg-amber-400/10 px-2 py-0.5 rounded mb-2">
                          <Car className="w-3 h-3" />
                          <span>{item.vehicleName}</span>
                        </div>
                      )}

                      <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px] text-slate-500">
                        <div className="flex items-center gap-1">
                          <Paperclip className="w-3 h-3 text-slate-400" />
                          <span>{item.attachments?.length || 0} pièce(s) jointe(s)</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setRecipientEmail(item.to);
                              setRecipientName(item.recipientName);
                              setSubject(item.subject);
                              setMessageBody(item.message);
                              setActiveTab('compose');
                            }}
                            className="text-amber-400 hover:text-amber-300 font-bold"
                          >
                            Réutiliser
                          </button>
                          {onDeleteEmail && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (confirm('Supprimer cette entrée du journal ?')) {
                                  onDeleteEmail(item.id);
                                }
                              }}
                              className="text-slate-500 hover:text-rose-400 ml-1"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Detail drawer when clicking an item */}
              {selectedHistoryItem && (
                <div className="mt-4 p-5 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h4 className="text-xs font-bold uppercase text-slate-300 tracking-wider">
                      Détail complet du message envoyé le {new Date(selectedHistoryItem.sentAt).toLocaleString('fr-FR')}
                    </h4>
                    <button
                      onClick={() => setSelectedHistoryItem(null)}
                      className="text-slate-500 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="text-xs space-y-1">
                    <p><strong>De :</strong> {selectedHistoryItem.fromName} &lt;{selectedHistoryItem.from}&gt;</p>
                    <p><strong>À :</strong> {selectedHistoryItem.recipientName} &lt;{selectedHistoryItem.to}&gt;</p>
                    <p><strong>Objet :</strong> {selectedHistoryItem.subject}</p>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-lg text-xs font-mono text-slate-200 whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto border border-slate-800">
                    {selectedHistoryItem.message}
                  </div>

                  {selectedHistoryItem.attachments?.length > 0 && (
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 block mb-1">Pièces jointes transmises :</span>
                      <div className="flex flex-wrap gap-2">
                        {selectedHistoryItem.attachments.map((att, i) => (
                          <span key={i} className="inline-flex items-center gap-1 text-[11px] bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300">
                            <FileText className="w-3 h-3 text-amber-400" />
                            {att.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
