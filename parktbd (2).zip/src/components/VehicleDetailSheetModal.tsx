import React from 'react';
import { Vehicle, EmailDocType } from '../types';
import { 
  X, 
  Edit3, 
  Eye, 
  Car, 
  DollarSign, 
  Calendar, 
  Gauge, 
  Fuel, 
  Cog, 
  ShieldCheck, 
  User, 
  Building2, 
  FileText, 
  FileSignature, 
  BookmarkCheck, 
  Printer, 
  Mail, 
  Wrench, 
  Truck, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Key, 
  BookOpen, 
  Phone, 
  Clock,
  ExternalLink
} from 'lucide-react';

interface VehicleDetailSheetModalProps {
  vehicle: Vehicle | null;
  onClose: () => void;
  onOpenEdit: (vehicle: Vehicle) => void;
  onOpenShowcase: (vehicle: Vehicle) => void;
  onOpenReservation: (vehicle: Vehicle) => void;
  onOpenSalesMandate?: (vehicle: Vehicle) => void;
  onOpenWindowSticker?: (vehicle: Vehicle) => void;
  onOpenBrochure?: (vehicle: Vehicle) => void;
  onOpenSendEmail?: (vehicle: Vehicle, docType?: EmailDocType) => void;
}

export const VehicleDetailSheetModal: React.FC<VehicleDetailSheetModalProps> = ({
  vehicle,
  onClose,
  onOpenEdit,
  onOpenShowcase,
  onOpenReservation,
  onOpenSalesMandate,
  onOpenWindowSticker,
  onOpenBrochure,
  onOpenSendEmail
}) => {
  if (!vehicle) return null;

  const photo = vehicle.images?.[0] || vehicle.mediaItems?.find(m => m.type === 'photo')?.url || null;
  const totalCost = vehicle.costs.purchasePrice + 
    vehicle.costs.transport + 
    vehicle.costs.reconditioning + 
    vehicle.costs.detailing + 
    vehicle.costs.inspection + 
    vehicle.costs.adminFees + 
    vehicle.costs.warrantyCost;
  const margin = vehicle.sellingPrice - totalCost;
  const marginPct = totalCost > 0 ? (margin / totalCost) * 100 : 0;

  const reservation = vehicle.reservation;
  const mandate = vehicle.salesMandate;
  const seller = vehicle.seller;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-8 flex flex-col">
        
        {/* Header with Title and PRIMARY DUAL ACTIONS: Modifier vs Showcase Client */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-4 border-b border-slate-800 bg-slate-950/90">
          <div>
            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-0.5 rounded text-[11px] font-extrabold uppercase ${
                vehicle.status === 'en_stock' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                vehicle.status === 'reserve' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                vehicle.status === 'en_preparation' ? 'bg-amber-400/20 text-amber-300 border border-amber-400/30' :
                vehicle.status === 'vendu' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' :
                'bg-slate-800 text-slate-300'
              }`}>
                {vehicle.status === 'en_stock' ? '● En stock' :
                 vehicle.status === 'reserve' ? '● Réservé' :
                 vehicle.status === 'en_preparation' ? '● En préparation' :
                 vehicle.status === 'vendu' ? '● Vendu' : vehicle.status}
              </span>
              <span className="text-xs font-mono font-bold text-amber-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                {vehicle.registration}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                {vehicle.businessType === 'depot_vente' ? 'Formule Dépôt-Vente' : 'Achat-Revente Direct'}
              </span>
            </div>
            <h2 className="text-xl font-black text-white tracking-tight uppercase mt-1">
              Fiche Véhicule & État de la Vente · {vehicle.brand} {vehicle.model}
            </h2>
          </div>

          {/* TOP PRIMARY ACTION BUTTONS */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenEdit(vehicle)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white border border-amber-500/30 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
              title="Modifier les informations, les coûts ou les photos"
            >
              <Edit3 className="w-4 h-4 text-amber-400" />
              <span>Modifier / Mettre à jour</span>
            </button>

            <button
              onClick={() => onOpenShowcase(vehicle)}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-lg transition-transform active:scale-95 cursor-pointer"
              title="Ouvrir la vue épurée pour montrer au client (sans marges internes)"
            >
              <Eye className="w-4 h-4" />
              <span>Showcase Client</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Detailed Body */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[82vh]">
          
          {/* Main Visual & Key Specs Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Photo Column */}
            <div className="lg:col-span-5 space-y-3">
              <div className="relative aspect-16/10 rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 shadow-lg flex items-center justify-center">
                {photo ? (
                  <img
                    src={photo}
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-slate-600">
                    <Car className="w-12 h-12 text-slate-700 mb-1" />
                    <span className="text-xs text-slate-500">Aucune photo enregistrée</span>
                  </div>
                )}
                <div className="absolute bottom-2 left-2 px-2.5 py-1 bg-slate-950/80 backdrop-blur-sm rounded text-[11px] font-mono text-white">
                  VIN : {vehicle.vin}
                </div>
              </div>

              {/* Quick actions row */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => onOpenReservation(vehicle)}
                  className="p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                >
                  <BookmarkCheck className="w-3.5 h-3.5" />
                  <span>{vehicle.status === 'reserve' ? 'Gérer Réservation' : 'Réserver'}</span>
                </button>

                {onOpenWindowSticker && (
                  <button
                    onClick={() => onOpenWindowSticker(vehicle)}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5 text-amber-400" />
                    <span>Vitrine</span>
                  </button>
                )}

                {onOpenBrochure && (
                  <button
                    onClick={() => onOpenBrochure(vehicle)}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5 text-blue-400" />
                    <span>PDF Client</span>
                  </button>
                )}
              </div>
            </div>

            {/* General Specs and State */}
            <div className="lg:col-span-7 space-y-4">
              <div>
                <h3 className="text-2xl font-black text-white">
                  {vehicle.brand} {vehicle.model}
                </h3>
                <p className="text-sm font-semibold text-slate-300 mt-0.5">
                  {vehicle.version}
                </p>
                <div className="text-xs text-slate-400 mt-1 flex items-center gap-3">
                  <span>Couleur : <strong className="text-white">{vehicle.colorExterior}</strong></span>
                  <span>·</span>
                  <span>Intérieur : <strong className="text-white">{vehicle.colorInterior}</strong></span>
                  <span>·</span>
                  <span>Crit'Air : <strong className="text-white">{vehicle.critAir}</strong></span>
                </div>
              </div>

              {/* 4 Tech Pillars */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400 block">Année & MEC</span>
                  <span className="text-xs font-bold text-white mt-0.5 block">{vehicle.year} ({vehicle.firstRegistrationDate})</span>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400 block">Kilométrage</span>
                  <span className="text-xs font-bold text-white mt-0.5 block tabular-nums">{Number(vehicle.mileage).toLocaleString('fr-FR')} km</span>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400 block">Carburant & Boîte</span>
                  <span className="text-xs font-bold text-white mt-0.5 block">{vehicle.fuel} · {vehicle.gearbox}</span>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400 block">Puissance</span>
                  <span className="text-xs font-bold text-white mt-0.5 block">{vehicle.powerDin} ch ({vehicle.powerFiscal} CV)</span>
                </div>
              </div>

              {/* Financial Box with internal breakdown & Mehdi mechanical costs */}
              <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-3">
                <div className="flex items-baseline justify-between border-b border-slate-800 pb-2">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Prix de Vente Affiché TTC</span>
                  <span className="text-2xl font-black text-amber-400 font-mono">
                    {Number(vehicle.sellingPrice).toLocaleString('fr-FR')} €
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[11px]">
                      {vehicle.businessType === 'depot_vente' ? 'Net Vendeur garanti :' : 'Prix Achat net :'}
                    </span>
                    <strong className="text-white font-mono">
                      {(vehicle.sellerDesiredPrice || vehicle.costs.purchasePrice).toLocaleString('fr-FR')} €
                    </strong>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[11px] flex items-center gap-1">
                      <Wrench className="w-3 h-3 text-amber-400" />
                      <span>Coût Révision (Atelier Mehdi) :</span>
                    </span>
                    <strong className="text-white font-mono">
                      {vehicle.costs.reconditioning.toLocaleString('fr-FR')} €
                    </strong>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[11px]">Frais Prépa & Detailing :</span>
                    <strong className="text-white font-mono">
                      {(vehicle.costs.transport + vehicle.costs.detailing + vehicle.costs.inspection + vehicle.costs.adminFees + vehicle.costs.warrantyCost).toLocaleString('fr-FR')} €
                    </strong>
                  </div>
                </div>

                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400">Coût de Revient Total Engagé : </span>
                    <strong className="text-white font-mono">{totalCost.toLocaleString('fr-FR')} €</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Marge Nette : </span>
                    <strong className={`font-mono text-sm ${margin >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      +{margin.toLocaleString('fr-FR')} € ({marginPct.toFixed(1)}%)
                    </strong>
                  </div>
                </div>
              </div>

            </div>

          </div>

          {/* Section 2: État de la vente en cours (Réservation ou Mandat Vendeur) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Left Box: État Réservation & Acheteur */}
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <BookmarkCheck className="w-4 h-4 text-blue-400" />
                  <span>État de la Vente & Réservation</span>
                </h4>
                {reservation && (
                  <span className="px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-400 font-bold uppercase">
                    Bon de Commande #{reservation.orderNumber}
                  </span>
                )}
              </div>

              {reservation ? (
                <div className="space-y-2 text-xs">
                  <div className="p-3 bg-slate-900 rounded-xl space-y-1">
                    <div className="font-bold text-white flex items-center justify-between">
                      <span>{reservation.name} {reservation.firstName || ''}</span>
                      <span className="text-[11px] text-slate-400 font-mono">{reservation.phone}</span>
                    </div>
                    {reservation.email && <div className="text-[11px] text-slate-400">{reservation.email}</div>}
                    {reservation.address && <div className="text-[11px] text-slate-400">{reservation.address}, {reservation.postalCodeCity}</div>}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2.5 bg-slate-900 rounded-xl">
                      <span className="text-[11px] text-slate-400 block">Acompte reçu :</span>
                      <strong className="text-emerald-400 font-mono">{reservation.depositAmount.toLocaleString('fr-FR')} €</strong>
                      <span className="text-[10px] text-slate-500 block">via {reservation.depositPaymentMethod}</span>
                    </div>
                    <div className="p-2.5 bg-slate-900 rounded-xl">
                      <span className="text-[11px] text-slate-400 block">Solde à la livraison :</span>
                      <strong className="text-amber-400 font-mono">{reservation.balanceRemaining.toLocaleString('fr-FR')} €</strong>
                      <span className="text-[10px] text-slate-500 block">Délai : {reservation.deliveryDeadlineDate || 'À fixer'}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-6 text-center bg-slate-900/60 rounded-xl space-y-2">
                  <p className="text-xs text-slate-400">Aucun bon de commande ni réservation enregistrée pour l'instant.</p>
                  <button
                    onClick={() => onOpenReservation(vehicle)}
                    className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold cursor-pointer"
                  >
                    + Réserver ce véhicule
                  </button>
                </div>
              )}
            </div>

            {/* Right Box: Propriétaire Vendeur & Mandat (si Dépôt-Vente) */}
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <User className="w-4 h-4 text-amber-400" />
                  <span>Client Propriétaire Vendeur</span>
                </h4>
                {vehicle.businessType === 'depot_vente' && (
                  <span className="px-2 py-0.5 rounded text-[10px] bg-amber-400/20 text-amber-300 font-bold uppercase">
                    Mandat Automobile
                  </span>
                )}
              </div>

              {vehicle.businessType === 'depot_vente' ? (
                <div className="space-y-2 text-xs">
                  <div className="p-3 bg-slate-900 rounded-xl space-y-1">
                    <div className="font-bold text-white flex items-center justify-between">
                      <span>{mandate?.mandantName || seller?.name || 'Vendeur non renseigné'}</span>
                      <span className="text-[11px] text-slate-400 font-mono">{mandate?.phone || seller?.phone || ''}</span>
                    </div>
                    <div className="text-[11px] text-slate-400">{mandate?.email || seller?.email || ''}</div>
                    <div className="text-[11px] text-slate-400">
                      {mandate?.address || seller?.address || ''} {mandate?.postalCodeCity || (seller ? `${seller.postalCode || ''} ${seller.city || ''}` : '')}
                    </div>
                  </div>

                  {onOpenSalesMandate && (
                    <button
                      onClick={() => onOpenSalesMandate(vehicle)}
                      className="w-full py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow"
                    >
                      <FileSignature className="w-4 h-4" />
                      <span>Ouvrir / Imprimer le Mandat de Vente Officiel (2 pages)</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="p-6 text-center bg-slate-900/60 rounded-xl space-y-1">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto" />
                  <div className="text-xs font-bold text-white">Véhicule Achat-Revente Direct</div>
                  <div className="text-[11px] text-slate-400">Propriété exclusive de la société TBD AUTOS. Aucun mandat requis.</div>
                </div>
              )}
            </div>

          </div>

          {/* Section 3: Administrative Status & Damaged Inspections */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Administrative Documents */}
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-emerald-400" />
                <span>Documents Réglementaires SIV</span>
              </h4>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-900 rounded-xl flex items-center justify-between">
                  <span className="text-slate-400">Carte Grise :</span>
                  <span className={`font-bold ${vehicle.documents.carteGrise === 'complet' ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {vehicle.documents.carteGrise === 'complet' ? '✓ Conforme' : 'En attente'}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl flex items-center justify-between">
                  <span className="text-slate-400">Non-Gage SIV :</span>
                  <span className={`font-bold ${vehicle.documents.certificatNonGage === 'complet' ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {vehicle.documents.certificatNonGage === 'complet' ? '✓ Conforme' : 'À vérifier'}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl flex items-center justify-between">
                  <span className="text-slate-400">Contrôle Tech. :</span>
                  <span className={`font-bold ${vehicle.documents.controleTechnique === 'complet' ? 'text-emerald-400' : 'text-slate-400'}`}>
                    {vehicle.documents.controleTechnique === 'complet' ? '✓ Valide' : 'À programmer'}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl flex items-center justify-between">
                  <span className="text-slate-400">Clés & Carnet :</span>
                  <span className="font-bold text-white">
                    {vehicle.documents.doubleDesCles ? '2 clés' : '1 clé'} · {vehicle.documents.carnetEntretien ? 'Carnet OK' : 'Sans'}
                  </span>
                </div>
              </div>
            </div>

            {/* Dommages signalés */}
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Défauts & Dommages Relevés ({vehicle.damages?.length || 0})</span>
                </h4>
              </div>

              {(vehicle.damages && vehicle.damages.length > 0) ? (
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {vehicle.damages.map(d => (
                    <div key={d.id} className="p-2 bg-slate-900 rounded-xl flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-white">{d.title}</span>
                        <span className="text-slate-400 text-[11px] block">{d.location} · {d.severity}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-mono text-amber-400 font-bold">{d.estimatedRepairCost || 0} €</span>
                        <span className={`text-[10px] block ${d.repaired ? 'text-emerald-400' : 'text-slate-500'}`}>
                          {d.repaired ? '✓ Réparé' : 'À charge'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-6 text-center bg-slate-900/60 rounded-xl text-xs text-slate-400">
                  Aucun dommage ni rayure signalée sur ce véhicule.
                </div>
              )}
            </div>

          </div>

          {/* Options & Équipements */}
          {vehicle.keyOptions && vehicle.keyOptions.length > 0 && (
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Options & Équipements de Série
              </h4>
              <div className="flex flex-wrap gap-2">
                {vehicle.keyOptions.map((opt, i) => (
                  <span key={i} className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300">
                    {opt}
                  </span>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
