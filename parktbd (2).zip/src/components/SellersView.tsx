import React, { useState } from 'react';
import { Seller, Vehicle, SellerType } from '../types';
import { 
  Users, 
  Building2, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  CreditCard, 
  FileText, 
  Plus, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  Trash2, 
  Edit3, 
  Eye, 
  Car, 
  ShieldCheck, 
  Download, 
  X, 
  Upload, 
  ExternalLink,
  ChevronRight,
  TrendingUp,
  Receipt
} from 'lucide-react';

interface SellersViewProps {
  sellers: Seller[];
  vehicles: Vehicle[];
  onAddSeller: (seller: Partial<Seller>) => Promise<Seller | void>;
  onUpdateSeller: (id: string, seller: Partial<Seller>) => Promise<Seller | void>;
  onDeleteSeller: (id: string) => Promise<boolean | void>;
  onOpenVehicleModal: (vehicle: Vehicle) => void;
  onOpenNewVehicleForSeller: (sellerId: string) => void;
}

export const SellersView: React.FC<SellersViewProps> = ({
  sellers,
  vehicles,
  onAddSeller,
  onUpdateSeller,
  onDeleteSeller,
  onOpenVehicleModal,
  onOpenNewVehicleForSeller
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'particulier' | 'professionnel'>('all');
  const [filterDocs, setFilterDocs] = useState<'all' | 'verified' | 'missing'>('all');

  // Modal state for Add/Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSeller, setEditingSeller] = useState<Seller | null>(null);

  // Document Viewer Lightbox Modal
  const [viewingDocument, setViewingDocument] = useState<{
    title: string;
    url?: string;
    type: string;
    sellerName: string;
    docNumber?: string;
  } | null>(null);

  // Form states
  const [formType, setFormType] = useState<SellerType>('particulier');
  const [formName, setFormName] = useState('');
  const [formCompanyName, setFormCompanyName] = useState('');
  const [formSiren, setFormSiren] = useState('');
  const [formSiret, setFormSiret] = useState('');
  const [formManagerName, setFormManagerName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formPostalCode, setFormPostalCode] = useState('');
  const [formCity, setFormCity] = useState('');
  const [formRib, setFormRib] = useState('');
  const [formIdType, setFormIdType] = useState<'cni' | 'passeport' | 'titre_sejour' | 'kbis' | 'statuts'>('cni');
  const [formIdNumber, setFormIdNumber] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formIdFile, setFormIdFile] = useState<{ name: string; url: string; size: string; type: string } | null>(null);
  const [formKbisFile, setFormKbisFile] = useState<{ name: string; url: string; size: string; type: string } | null>(null);

  const openAddModal = () => {
    setEditingSeller(null);
    setFormType('particulier');
    setFormName('');
    setFormCompanyName('');
    setFormSiren('');
    setFormSiret('');
    setFormManagerName('');
    setFormPhone('');
    setFormEmail('');
    setFormAddress('');
    setFormPostalCode('');
    setFormCity('');
    setFormRib('');
    setFormIdType('cni');
    setFormIdNumber('');
    setFormNotes('');
    setFormIdFile(null);
    setFormKbisFile(null);
    setIsModalOpen(true);
  };

  const openEditModal = (seller: Seller) => {
    setEditingSeller(seller);
    setFormType(seller.type);
    setFormName(seller.name);
    setFormCompanyName(seller.companyName || '');
    setFormSiren(seller.siren || '');
    setFormSiret(seller.siret || '');
    setFormManagerName(seller.managerName || '');
    setFormPhone(seller.phone);
    setFormEmail(seller.email);
    setFormAddress(seller.address);
    setFormPostalCode(seller.postalCode || '');
    setFormCity(seller.city || '');
    setFormRib(seller.rib || '');
    setFormIdType(seller.idDocumentType || (seller.type === 'professionnel' ? 'kbis' : 'cni'));
    setFormIdNumber(seller.idDocumentNumber || '');
    setFormNotes(seller.notes || '');
    setFormIdFile(seller.idDocumentFile ? {
      name: seller.idDocumentFile.name,
      url: seller.idDocumentFile.url || '',
      size: seller.idDocumentFile.size,
      type: seller.idDocumentFile.type
    } : null);
    setFormKbisFile(seller.kbisFile ? {
      name: seller.kbisFile.name,
      url: seller.kbisFile.url || '',
      size: seller.kbisFile.size,
      type: seller.kbisFile.type
    } : null);
    setIsModalOpen(true);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'id' | 'kbis') => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const docData = {
        name: file.name,
        url: reader.result as string,
        size: `${(file.size / (1024 * 1024)).toFixed(2)} Mo`,
        type: file.type || 'application/pdf',
        uploadDate: new Date().toISOString().slice(0, 10)
      };
      if (target === 'id') {
        setFormIdFile(docData);
      } else {
        setFormKbisFile(docData);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveSeller = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    const sellerPayload: Partial<Seller> = {
      type: formType,
      name: formName.trim(),
      companyName: formType === 'professionnel' ? formCompanyName.trim() : undefined,
      siren: formType === 'professionnel' ? formSiren.trim() : undefined,
      siret: formType === 'professionnel' ? formSiret.trim() : undefined,
      managerName: formType === 'professionnel' ? formManagerName.trim() : undefined,
      phone: formPhone.trim(),
      email: formEmail.trim(),
      address: formAddress.trim(),
      postalCode: formPostalCode.trim(),
      city: formCity.trim(),
      rib: formRib.trim(),
      idDocumentType: formIdType,
      idDocumentNumber: formIdNumber.trim(),
      notes: formNotes.trim(),
      idDocumentFile: formIdFile ? {
        name: formIdFile.name,
        url: formIdFile.url,
        size: formIdFile.size,
        type: formIdFile.type,
        uploadDate: new Date().toISOString().slice(0, 10)
      } : undefined,
      kbisFile: formKbisFile ? {
        name: formKbisFile.name,
        url: formKbisFile.url,
        size: formKbisFile.size,
        type: formKbisFile.type,
        uploadDate: new Date().toISOString().slice(0, 10)
      } : undefined
    };

    if (editingSeller) {
      await onUpdateSeller(editingSeller.id, sellerPayload);
    } else {
      await onAddSeller(sellerPayload);
    }

    setIsModalOpen(false);
    setEditingSeller(null);
  };

  // Helper to get vehicles for a seller
  const getVehiclesForSeller = (sellerId: string, sellerName: string) => {
    return vehicles.filter(v => 
      v.businessType === 'depot_vente' && 
      (v.sellerId === sellerId || (v.seller?.name && v.seller.name.toLowerCase() === sellerName.toLowerCase()))
    );
  };

  // Filtered sellers
  const filteredSellers = sellers.filter(seller => {
    const q = searchQuery.toLowerCase();
    const matchesSearch = 
      seller.name.toLowerCase().includes(q) ||
      (seller.companyName && seller.companyName.toLowerCase().includes(q)) ||
      seller.email.toLowerCase().includes(q) ||
      seller.phone.toLowerCase().includes(q) ||
      (seller.city && seller.city.toLowerCase().includes(q)) ||
      (seller.siren && seller.siren.toLowerCase().includes(q));

    const matchesType = filterType === 'all' || seller.type === filterType;

    const hasId = !!(seller.idDocumentFile || seller.idDocumentNumber);
    const hasKbis = seller.type === 'professionnel' ? !!seller.kbisFile : true;
    const isVerified = hasId && hasKbis;

    const matchesDocs = 
      filterDocs === 'all' || 
      (filterDocs === 'verified' && isVerified) || 
      (filterDocs === 'missing' && !isVerified);

    return matchesSearch && matchesType && matchesDocs;
  });

  // Calculate summary metrics
  const totalSellers = sellers.length;
  const totalParticuliers = sellers.filter(s => s.type === 'particulier').length;
  const totalPros = sellers.filter(s => s.type === 'professionnel').length;
  
  // Total depot-vente vehicles and financial values
  const depotVehicles = vehicles.filter(v => v.businessType === 'depot_vente');
  const totalNetSellersValue = depotVehicles.reduce((acc, v) => acc + (v.sellerDesiredPrice || v.costs.purchasePrice || 0), 0);
  const totalPotentialBrokerage = depotVehicles.reduce((acc, v) => {
    const desired = v.sellerDesiredPrice || v.costs.purchasePrice || 0;
    return acc + Math.max(0, v.sellingPrice - desired);
  }, 0);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              Vendeurs & Déposants (Dépôts-Vente)
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-400/10 text-amber-400 border border-amber-400/20">
              {sellers.length} enregistrés
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Gestion centralisée des propriétaires de véhicules en dépôt-vente chez <strong className="text-white">TBD AUTOS</strong>. 
            Contrôle d'identité (CNI / KBIS), mandat multi-véhicules et RIB pour versement net vendeur.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all cursor-pointer shadow-md hover:shadow-amber-500/10"
          >
            <Plus className="w-4 h-4" />
            Nouveau Vendeur Déposant
          </button>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Déposants Enregistrés</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-white tabular-nums mt-1">
            {totalSellers}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
            <span>{totalParticuliers} particuliers</span>
            <span>·</span>
            <span>{totalPros} professionnels</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Véhicules sous Mandat</span>
            <Car className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-extrabold text-white tabular-nums mt-1">
            {depotVehicles.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {depotVehicles.filter(v => v.status === 'en_stock').length} en exposition active
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Montant Net Vendeurs en Cours</span>
            <Receipt className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-400 tabular-nums mt-1">
            {totalNetSellersValue.toLocaleString('fr-FR')} €
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Sommes dues aux propriétaires à la vente
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Commissions Brutes TBD AUTOS</span>
            <TrendingUp className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold text-white tabular-nums mt-1">
            +{totalPotentialBrokerage.toLocaleString('fr-FR')} €
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Potentiel sur les dépôts actuels
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-slate-900/60 border border-slate-800 rounded-xl">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher par nom, société, SIREN, ville, email..."
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-400"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Type filter */}
          <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setFilterType('all')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                filterType === 'all' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Tous ({sellers.length})
            </button>
            <button
              onClick={() => setFilterType('particulier')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                filterType === 'particulier' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Particuliers
            </button>
            <button
              onClick={() => setFilterType('professionnel')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                filterType === 'professionnel' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Pros (Sociétés)
            </button>
          </div>

          {/* Docs status filter */}
          <select
            value={filterDocs}
            onChange={(e) => setFilterDocs(e.target.value as any)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300"
          >
            <option value="all">Tous justificatifs</option>
            <option value="verified">CNI / KBIS complet</option>
            <option value="missing">Justificatif manquant</option>
          </select>
        </div>
      </div>

      {/* Sellers List */}
      {filteredSellers.length === 0 ? (
        <div className="p-12 text-center bg-slate-900/40 border border-dashed border-slate-800 rounded-2xl space-y-3">
          <Users className="w-10 h-10 text-slate-600 mx-auto" />
          <div className="text-sm font-semibold text-slate-300">Aucun vendeur déposant trouvé</div>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {searchQuery ? 'Aucun résultat ne correspond à votre recherche.' : 'Enregistrez votre premier client vendeur pour démarrer le suivi des dépôts-vente.'}
          </p>
          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 rounded-lg"
          >
            <Plus className="w-3.5 h-3.5" /> Ajouter un vendeur
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredSellers.map((seller) => {
            const sellerVehicles = getVehiclesForSeller(seller.id, seller.name);
            const hasIdDoc = !!seller.idDocumentFile || !!seller.idDocumentNumber;
            const hasKbisDoc = seller.type === 'professionnel' ? !!seller.kbisFile : true;
            const isFullyVerified = hasIdDoc && hasKbisDoc;

            return (
              <div
                key={seller.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 transition-all shadow-sm space-y-4"
              >
                {/* Seller Top Bar: Identity & Quick Actions */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex items-start gap-3.5">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 font-bold text-base ${
                      seller.type === 'professionnel' 
                        ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' 
                        : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                    }`}>
                      {seller.type === 'professionnel' ? <Building2 className="w-5 h-5" /> : <User className="w-5 h-5" />}
                    </div>

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="text-base font-bold text-white">
                          {seller.name}
                        </h2>
                        
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          seller.type === 'professionnel'
                            ? 'bg-purple-950 text-purple-300 border border-purple-800'
                            : 'bg-blue-950 text-blue-300 border border-blue-800'
                        }`}>
                          {seller.type === 'professionnel' ? 'Professionnel' : 'Particulier'}
                        </span>

                        {isFullyVerified ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800/80">
                            <CheckCircle2 className="w-3 h-3" />
                            Dossier Justificatifs Conforme
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-950/80 text-amber-400 border border-amber-800/80">
                            <AlertTriangle className="w-3 h-3" />
                            Justificatif d'identité incomplet
                          </span>
                        )}
                      </div>

                      {seller.companyName && seller.type === 'professionnel' && (
                        <div className="text-xs text-slate-300 font-medium mt-0.5">
                          {seller.companyName} {seller.siren ? `· SIREN : ${seller.siren}` : ''}
                        </div>
                      )}

                      <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-slate-400 mt-1.5">
                        {seller.phone && (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3.5 h-3.5 text-slate-500" /> {seller.phone}
                          </span>
                        )}
                        {seller.email && (
                          <span className="flex items-center gap-1 font-mono">
                            <Mail className="w-3.5 h-3.5 text-slate-500" /> {seller.email}
                          </span>
                        )}
                        {(seller.city || seller.address) && (
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-500" /> 
                            {seller.address ? `${seller.address}, ` : ''}{seller.postalCode} {seller.city}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="flex items-center gap-2 self-start lg:self-center shrink-0">
                    <button
                      onClick={() => onOpenNewVehicleForSeller(seller.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                      title="Ajouter un véhicule confié en dépôt-vente par ce vendeur"
                    >
                      <Plus className="w-3.5 h-3.5 text-amber-400" />
                      <span>Confier Véhicule</span>
                    </button>

                    <button
                      onClick={() => openEditModal(seller)}
                      className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                      title="Modifier les informations"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        if (confirm(`Confirmez-vous la suppression du vendeur ${seller.name} ?`)) {
                          onDeleteSeller(seller.id);
                        }
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-400 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                      title="Supprimer ce vendeur"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Seller Body: 2 Columns (Documents & Identity Info VS Vehicles in Sale) */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 pt-3 border-t border-slate-800/80">
                  
                  {/* Left Column: Identity Documents (CNI / KBIS) & Banking (RIB) */}
                  <div className="lg:col-span-5 space-y-3 bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-xl">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                        Pièces d'Identité & Justificatifs
                      </span>
                      <button
                        onClick={() => openEditModal(seller)}
                        className="text-[11px] text-amber-400 hover:underline cursor-pointer"
                      >
                        Gérer pièces
                      </button>
                    </div>

                    <div className="space-y-2">
                      {/* CNI / Passport Card */}
                      <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2.5">
                          <FileText className="w-4 h-4 text-blue-400 shrink-0" />
                          <div>
                            <div className="font-semibold text-slate-200">
                              {seller.idDocumentType === 'passeport' ? 'Passeport' : 
                               seller.idDocumentType === 'titre_sejour' ? 'Titre de séjour' : 'Carte Nationale d\'Identité (CNI)'}
                            </div>
                            <div className="text-[11px] text-slate-500 font-mono">
                              {seller.idDocumentNumber ? `N° ${seller.idDocumentNumber}` : 'Numéro non renseigné'}
                            </div>
                          </div>
                        </div>

                        {seller.idDocumentFile ? (
                          <button
                            onClick={() => setViewingDocument({
                              title: `Pièce d'Identité - ${seller.name}`,
                              url: seller.idDocumentFile?.url,
                              type: seller.idDocumentFile?.type || 'application/pdf',
                              sellerName: seller.name,
                              docNumber: seller.idDocumentNumber
                            })}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-amber-300 bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/30 rounded cursor-pointer transition-colors"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Voir CNI</span>
                          </button>
                        ) : (
                          <span className="text-[10px] text-amber-400/80 bg-amber-950/40 px-2 py-0.5 rounded">
                            Scan à uploader
                          </span>
                        )}
                      </div>

                      {/* KBIS (if Pro) */}
                      {seller.type === 'professionnel' && (
                        <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2.5">
                            <Building2 className="w-4 h-4 text-purple-400 shrink-0" />
                            <div>
                              <div className="font-semibold text-slate-200">
                                Extrait Kbis & Immatriculation
                              </div>
                              <div className="text-[11px] text-slate-500 font-mono">
                                {seller.siren ? `SIREN ${seller.siren}` : 'RCS en cours'}
                              </div>
                            </div>
                          </div>

                          {seller.kbisFile ? (
                            <button
                              onClick={() => setViewingDocument({
                                title: `Extrait KBIS - ${seller.companyName || seller.name}`,
                                url: seller.kbisFile?.url,
                                type: seller.kbisFile?.type || 'application/pdf',
                                sellerName: seller.name,
                                docNumber: seller.siren
                              })}
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-purple-300 bg-purple-400/10 hover:bg-purple-400/20 border border-purple-400/30 rounded cursor-pointer transition-colors"
                            >
                              <Eye className="w-3 h-3" />
                              <span>Voir KBIS</span>
                            </button>
                          ) : (
                            <span className="text-[10px] text-rose-400/80 bg-rose-950/40 px-2 py-0.5 rounded">
                              KBIS manquant
                            </span>
                          )}
                        </div>
                      )}

                      {/* RIB / Banking */}
                      <div className="p-2.5 bg-slate-900/60 border border-slate-800/80 rounded-lg flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <CreditCard className="w-4 h-4 text-emerald-400 shrink-0" />
                          <div>
                            <span className="text-slate-400 block text-[10px] uppercase font-bold">Coordonnées Bancaires (IBAN)</span>
                            <span className="font-mono text-slate-200 text-[11px]">
                              {seller.rib ? seller.rib : 'IBAN non renseigné (à demander pour virement)'}
                            </span>
                          </div>
                        </div>
                      </div>

                      {seller.notes && (
                        <div className="text-[11px] text-slate-400 italic bg-slate-900/40 p-2 rounded border border-slate-800/60">
                          « {seller.notes} »
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right Column: Multiple Vehicles on Sale for this Seller */}
                  <div className="lg:col-span-7 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                        <Car className="w-3.5 h-3.5 text-amber-400" />
                        Véhicules Confiés en Dépôt-Vente ({sellerVehicles.length})
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {sellerVehicles.length > 1 ? 'Vendeur multi-véhicules actif' : ''}
                      </span>
                    </div>

                    {sellerVehicles.length === 0 ? (
                      <div className="p-6 text-center bg-slate-950/40 border border-dashed border-slate-800 rounded-xl space-y-2">
                        <Car className="w-6 h-6 text-slate-600 mx-auto" />
                        <div className="text-xs text-slate-400">Aucun véhicule confié actuellement pour ce vendeur.</div>
                        <button
                          onClick={() => onOpenNewVehicleForSeller(seller.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-slate-950 bg-amber-400 rounded cursor-pointer"
                        >
                          <Plus className="w-3 h-3" /> Associer un véhicule en mandat
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {sellerVehicles.map((car) => {
                          const netSeller = car.sellerDesiredPrice || car.costs.purchasePrice || 0;
                          const commGross = Math.max(0, car.sellingPrice - netSeller);

                          return (
                            <div
                              key={car.id}
                              className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs hover:border-slate-700 transition-colors"
                            >
                              <div className="flex items-center gap-3">
                                {car.images?.[0] ? (
                                  <img
                                    src={car.images[0]}
                                    alt={`${car.brand} ${car.model}`}
                                    className="w-12 h-9 object-cover rounded-lg border border-slate-800 shrink-0"
                                  />
                                ) : (
                                  <div className="w-12 h-9 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-600 shrink-0">
                                    <Car className="w-4 h-4" />
                                  </div>
                                )}

                                <div>
                                  <div className="font-bold text-white flex items-center gap-2">
                                    <span>{car.brand} {car.model}</span>
                                    <span className="font-mono text-[10px] text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                                      {car.registration}
                                    </span>
                                  </div>
                                  <div className="text-[11px] text-slate-400 mt-0.5">
                                    {car.version} · {car.year} · {Number(car.mileage).toLocaleString('fr-FR')} km
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-4 text-right">
                                <div>
                                  <div className="text-[10px] text-slate-500 uppercase font-semibold">Net Vendeur Souhaité</div>
                                  <div className="font-extrabold text-purple-300 tabular-nums text-xs">
                                    {netSeller.toLocaleString('fr-FR')} €
                                  </div>
                                </div>

                                <div>
                                  <div className="text-[10px] text-slate-500 uppercase font-semibold">Prix Public TTC</div>
                                  <div className="font-extrabold text-amber-400 tabular-nums text-xs">
                                    {car.sellingPrice.toLocaleString('fr-FR')} €
                                  </div>
                                </div>

                                <div>
                                  <div className="text-[10px] text-slate-500 uppercase font-semibold">Comm. TBD</div>
                                  <div className="font-extrabold text-emerald-400 tabular-nums text-xs">
                                    +{commGross.toLocaleString('fr-FR')} €
                                  </div>
                                </div>

                                <div className="pl-2 border-l border-slate-800">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold block ${
                                    car.status === 'en_stock' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                                    car.status === 'reserve' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                                    'bg-slate-800 text-slate-300'
                                  }`}>
                                    {car.status === 'en_stock' ? 'En stock' : car.status}
                                  </span>
                                </div>

                                <button
                                  onClick={() => onOpenVehicleModal(car)}
                                  className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg cursor-pointer transition-colors"
                                  title="Ouvrir la fiche véhicule"
                                >
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal 1: Add / Edit Seller Form */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6 flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-400/10 text-amber-400 flex items-center justify-center">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {editingSeller ? 'Modifier le Vendeur Déposant' : 'Nouveau Vendeur Déposant'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Fiche client propriétaire pour mandat de dépôt-vente automobile
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Form */}
            <form onSubmit={handleSaveSeller} className="p-6 overflow-y-auto space-y-5 flex-1">
              
              {/* Type Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">Type de Client Vendeur *</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormType('particulier')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-colors cursor-pointer ${
                      formType === 'particulier'
                        ? 'border-amber-400 bg-amber-400/10 text-white font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    <User className="w-5 h-5 text-amber-400" />
                    <div>
                      <div className="text-xs font-bold">Client Particulier</div>
                      <div className="text-[10px] text-slate-400">Propriétaire individuel (CNI requise)</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormType('professionnel')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-colors cursor-pointer ${
                      formType === 'professionnel'
                        ? 'border-purple-400 bg-purple-400/10 text-white font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Building2 className="w-5 h-5 text-purple-400" />
                    <div>
                      <div className="text-xs font-bold">Professionnel / Société</div>
                      <div className="text-[10px] text-slate-400">Entreprise, SARL, SAS (KBIS requis)</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Name & Contact */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {formType === 'professionnel' ? 'Nom du Représentant / Contact *' : 'Nom & Prénom du Vendeur *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="ex: Julien Martinez"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>

                {formType === 'professionnel' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Raison Sociale Société *</label>
                    <input
                      type="text"
                      required
                      value={formCompanyName}
                      onChange={(e) => setFormCompanyName(e.target.value)}
                      placeholder="ex: SARL Alpha Invest Auto"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-400"
                    />
                  </div>
                )}

                {formType === 'professionnel' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Numéro SIREN / SIRET</label>
                    <input
                      type="text"
                      value={formSiren}
                      onChange={(e) => setFormSiren(e.target.value)}
                      placeholder="ex: 849 321 456"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Téléphone de Contact *</label>
                  <input
                    type="tel"
                    required
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="06 12 34 56 78"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Adresse E-mail *</label>
                  <input
                    type="email"
                    required
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="julien.martinez@email.fr"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              {/* Address */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-300 mb-1">Adresse Postale</label>
                  <input
                    type="text"
                    value={formAddress}
                    onChange={(e) => setFormAddress(e.target.value)}
                    placeholder="14 Rue des Acacias"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Code Postal & Ville</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={formPostalCode}
                      onChange={(e) => setFormPostalCode(e.target.value)}
                      placeholder="69003"
                      className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-xs text-white"
                    />
                    <input
                      type="text"
                      value={formCity}
                      onChange={(e) => setFormCity(e.target.value)}
                      placeholder="Lyon"
                      className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-2 py-2 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Banking RIB / IBAN */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                  IBAN / RIB pour versement du prix de vente net
                </label>
                <input
                  type="text"
                  value={formRib}
                  onChange={(e) => setFormRib(e.target.value)}
                  placeholder="FR76 3000 4012 3456 7890 1234 567"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              {/* SECTION: Identity Documents (CNI & KBIS Upload) */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-4">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    Justificatifs d'Identité & KBIS
                  </h4>
                </div>

                {/* CNI / Passport Upload */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="block text-xs font-medium text-slate-300">
                      Pièce d'Identité (CNI / Passeport)
                    </label>
                    <div className="flex gap-2">
                      <select
                        value={formIdType}
                        onChange={(e) => setFormIdType(e.target.value as any)}
                        className="bg-slate-900 border border-slate-800 rounded-lg px-2 py-1.5 text-xs text-white"
                      >
                        <option value="cni">CNI</option>
                        <option value="passeport">Passeport</option>
                        <option value="titre_sejour">Titre séjour</option>
                      </select>
                      <input
                        type="text"
                        value={formIdNumber}
                        onChange={(e) => setFormIdNumber(e.target.value)}
                        placeholder="Numéro de pièce"
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                      />
                    </div>

                    <div className="pt-1">
                      {formIdFile ? (
                        <div className="p-2 bg-slate-900 border border-emerald-800/80 rounded-lg flex items-center justify-between text-xs">
                          <span className="truncate text-emerald-400 font-medium">{formIdFile.name} ({formIdFile.size})</span>
                          <button
                            type="button"
                            onClick={() => setFormIdFile(null)}
                            className="text-rose-400 hover:text-rose-300 ml-2"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <label className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg cursor-pointer">
                          <Upload className="w-3.5 h-3.5 text-amber-400" />
                          <span>Uploader Scan CNI (PDF / Image)</span>
                          <input
                            type="file"
                            accept=".pdf,image/*"
                            onChange={(e) => handleFileUpload(e, 'id')}
                            className="hidden"
                          />
                        </label>
                      )}
                    </div>
                  </div>

                  {/* KBIS Upload (if Pro) */}
                  {formType === 'professionnel' && (
                    <div className="space-y-2">
                      <label className="block text-xs font-medium text-slate-300">
                        Extrait KBIS (Moins de 3 mois)
                      </label>
                      <div className="text-[11px] text-slate-400">
                        Document officiel attestant de l'existence juridique de la société.
                      </div>

                      <div className="pt-2">
                        {formKbisFile ? (
                          <div className="p-2 bg-slate-900 border border-purple-800/80 rounded-lg flex items-center justify-between text-xs">
                            <span className="truncate text-purple-300 font-medium">{formKbisFile.name} ({formKbisFile.size})</span>
                            <button
                              type="button"
                              onClick={() => setFormKbisFile(null)}
                              className="text-rose-400 hover:text-rose-300 ml-2"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <label className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg cursor-pointer">
                            <Upload className="w-3.5 h-3.5 text-purple-400" />
                            <span>Uploader Scan KBIS (PDF / Image)</span>
                            <input
                              type="file"
                              accept=".pdf,image/*"
                              onChange={(e) => handleFileUpload(e, 'kbis')}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Internal Notes */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Notes Internes sur le Client Déposant</label>
                <textarea
                  rows={2}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="ex: Propriétaire exigeant, disponible le samedi matin pour signature..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors cursor-pointer shadow-md"
                >
                  {editingSeller ? 'Mettre à jour la fiche vendeur' : 'Enregistrer le vendeur déposant'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Document Viewer Lightbox (CNI / KBIS preview) */}
      {viewingDocument && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            
            {/* Viewer Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-400/10 text-amber-400 flex items-center justify-center">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {viewingDocument.title}
                  </h3>
                  <div className="text-xs text-slate-400">
                    Déposant : <strong className="text-white">{viewingDocument.sellerName}</strong>
                    {viewingDocument.docNumber ? ` · Réf: ${viewingDocument.docNumber}` : ''}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {viewingDocument.url && (
                  <a
                    href={viewingDocument.url}
                    download={`Document_${viewingDocument.sellerName.replace(/\s+/g, '_')}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Télécharger
                  </a>
                )}
                <button
                  onClick={() => setViewingDocument(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Viewer Body */}
            <div className="p-6 overflow-y-auto flex-1 bg-slate-950 flex items-center justify-center min-h-[400px]">
              {viewingDocument.url ? (
                viewingDocument.type?.includes('image') || viewingDocument.url.startsWith('data:image') || viewingDocument.url.includes('images.unsplash.com') ? (
                  <img
                    src={viewingDocument.url}
                    alt={viewingDocument.title}
                    className="max-w-full max-h-[70vh] object-contain rounded-xl border border-slate-800 shadow-lg"
                  />
                ) : (
                  <iframe
                    src={viewingDocument.url}
                    title={viewingDocument.title}
                    className="w-full h-[70vh] rounded-xl border border-slate-800 bg-white"
                  />
                )
              ) : (
                <div className="text-center p-8 space-y-3">
                  <FileText className="w-12 h-12 text-slate-600 mx-auto" />
                  <div className="text-sm font-bold text-slate-300">Aperçu du document non disponible directement</div>
                  <p className="text-xs text-slate-500 max-w-md">
                    Le document est bien enregistré sous la référence {viewingDocument.docNumber || 'indiquée'}.
                  </p>
                </div>
              )}
            </div>

            {/* Viewer Footer */}
            <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <CheckCircle2 className="w-4 h-4" /> Justificatif archivé pour conformité mandataire SIV & DGFiP
              </span>
              <button
                onClick={() => setViewingDocument(null)}
                className="px-4 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg"
              >
                Fermer l'aperçu
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
