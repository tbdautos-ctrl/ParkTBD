import React from 'react';
import { Vehicle, Appointment, FinancialStats } from '../types';
import { 
  TrendingUp, 
  Car, 
  Calendar, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  FileText, 
  Printer, 
  ArrowUpRight,
  ShieldAlert,
  ChevronRight,
  UserCheck
} from 'lucide-react';

interface DashboardViewProps {
  vehicles: Vehicle[];
  appointments: Appointment[];
  stats: FinancialStats;
  onOpenVehicle: (vehicle: Vehicle) => void;
  onOpenWindowSticker: (vehicle: Vehicle) => void;
  onOpenBrochure: (vehicle: Vehicle) => void;
  onOpenAiAd: (vehicle: Vehicle) => void;
  onNavigateToStock: () => void;
  onNavigateToAppointments: () => void;
  onNavigateToDocuments: () => void;
  onCompleteAppointment: (apt: Appointment) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  vehicles,
  appointments,
  stats,
  onOpenVehicle,
  onOpenWindowSticker,
  onOpenBrochure,
  onOpenAiAd,
  onNavigateToStock,
  onNavigateToAppointments,
  onNavigateToDocuments,
  onCompleteAppointment
}) => {
  // Urgent Administrative Alerts
  const missingCtCars = vehicles.filter(v => v.documents.controleTechnique === 'manquant' || v.documents.controleTechnique === 'en_attente');
  const missingNonGage = vehicles.filter(v => v.documents.certificatNonGage === 'manquant' || v.documents.certificatNonGage === 'en_attente');
  const missingMandat = vehicles.filter(v => v.businessType === 'depot_vente' && v.documents.mandatVente !== 'complet');

  // Upcoming appointments (sorted by date)
  const upcomingApts = appointments
    .filter(a => a.status === 'confirme' || a.status === 'en_attente')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 4);

  // Recent vehicles in stock
  const activeStock = vehicles.filter(v => v.status === 'en_stock' || v.status === 'en_preparation' || v.status === 'reserve');

  return (
    <div className="space-y-8 pb-12">
      
      {/* 1. Header greeting & quick insight */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Tableau de Bord Commercial
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Pilotage des flux d'achat-revente, rotation des stocks, marges nettes et essais clients.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <span className="text-slate-400">Véhicules actifs en parc : </span>
            <span className="font-bold text-amber-400 tabular-nums">{activeStock.length}</span>
          </div>
          <div className="px-3.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <span className="text-slate-400">Ventes ce mois : </span>
            <span className="font-bold text-emerald-400 tabular-nums">{stats.carsSoldMonth}</span>
          </div>
        </div>
      </div>

      {/* 2. Primary Financial KPI Strip (Strict tabular-nums per SaaS guidelines) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* KPI 1: Total Stock Value */}
        <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Valeur du Stock en Parc (TTC)</span>
            <Car className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-2 tabular-nums">
            {stats.totalStockValueTTC.toLocaleString('fr-FR')} €
          </div>
          <div className="flex items-center gap-2 mt-2 text-xs text-slate-400">
            <span>{stats.totalCarsInStock} véhicules</span>
            <span aria-hidden="true">·</span>
            <span>{stats.businessTypeBreakdown.achat_revente} stocks propres</span>
            <span aria-hidden="true">·</span>
            <span>{stats.businessTypeBreakdown.depot_vente} dépôts</span>
          </div>
        </div>

        {/* KPI 2: Total Cost Invested */}
        <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Capital Investi (Achats + Frais)</span>
            <TrendingUp className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-2 tabular-nums">
            {stats.totalCostInvested.toLocaleString('fr-FR')} €
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Achats, transport, révisions & carrosserie engagés
          </div>
        </div>

        {/* KPI 3: Potential Net Margin */}
        <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Marge Nette Potentielle</span>
            <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
              +{stats.averageMarginPercentage.toFixed(1)}%
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 tracking-tight mt-2 tabular-nums">
            +{stats.potentialNetMargin.toLocaleString('fr-FR')} €
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Moyenne de {(stats.potentialNetMargin / Math.max(1, stats.totalCarsInStock)).toFixed(0)} € / véhicule
          </div>
        </div>

        {/* KPI 4: Rotation & Days in Stock */}
        <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-2xl relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Rotation Moyenne du Parc</span>
            <Clock className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-2 tabular-nums">
            {stats.averageStockDays} <span className="text-base font-semibold text-slate-400">jours</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Objectif standard négoce : &lt; 45 jours
          </div>
        </div>

      </div>

      {/* 3. Section: Status Overview & Administrative Priority Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Status Pipeline Cards (8 cols) */}
        <div className="lg:col-span-8 p-6 bg-slate-900/70 border border-slate-800 rounded-2xl space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white">État du Stock par Statut</h2>
              <p className="text-xs text-slate-400">Distribution en temps réel de votre flotte automobile</p>
            </div>
            <button
              onClick={onNavigateToStock}
              className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
            >
              Voir l'inventaire complet <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl text-center">
              <span className="text-[11px] text-slate-400 block">En Arrivage</span>
              <span className="text-2xl font-black text-slate-200 tabular-nums block my-1">
                {stats.statusBreakdown.en_arrivage || 0}
              </span>
              <span className="text-[10px] text-slate-500">En convoyage</span>
            </div>

            <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl text-center">
              <span className="text-[11px] text-slate-400 block">En Préparation</span>
              <span className="text-2xl font-black text-amber-400 tabular-nums block my-1">
                {stats.statusBreakdown.en_preparation || 0}
              </span>
              <span className="text-[10px] text-slate-500">Atelier / Esthétique</span>
            </div>

            <div className="p-3 bg-slate-950/60 border border-emerald-900/40 bg-emerald-950/10 rounded-xl text-center">
              <span className="text-[11px] text-emerald-400 block font-medium">En Stock Parc</span>
              <span className="text-2xl font-black text-emerald-400 tabular-nums block my-1">
                {stats.statusBreakdown.en_stock || 0}
              </span>
              <span className="text-[10px] text-emerald-600">Disponibles vente</span>
            </div>

            <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl text-center">
              <span className="text-[11px] text-slate-400 block">Réservés</span>
              <span className="text-2xl font-black text-blue-400 tabular-nums block my-1">
                {stats.statusBreakdown.reserve || 0}
              </span>
              <span className="text-[10px] text-slate-500">Acompte reçu</span>
            </div>

            <div className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl text-center">
              <span className="text-[11px] text-slate-400 block">Vendus</span>
              <span className="text-2xl font-black text-purple-400 tabular-nums block my-1">
                {stats.statusBreakdown.vendu || 0}
              </span>
              <span className="text-[10px] text-slate-500">Historique clôturé</span>
            </div>
          </div>

          {/* Quick stock shortcuts */}
          <div className="pt-2 border-t border-slate-800/60 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
            <span>Régime TVA dominant : <strong className="text-slate-200">TVA sur marge d'occasion (Art 297A)</strong></span>
            <span>Dépôts-vente sous mandat : <strong className="text-slate-200">{stats.businessTypeBreakdown.depot_vente} véhicules</strong></span>
          </div>
        </div>

        {/* Administrative Alerts Column (4 cols) */}
        <div className="lg:col-span-4 p-6 bg-slate-900/70 border border-slate-800 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              Alertes Administratives
            </h2>
            <button
              onClick={onNavigateToDocuments}
              className="text-xs text-slate-400 hover:text-white cursor-pointer"
            >
              Auditer
            </button>
          </div>

          <div className="space-y-2.5">
            {missingCtCars.length > 0 && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-3">
                <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs">
                  <div className="font-bold text-amber-300">
                    Contrôle technique manquant ({missingCtCars.length})
                  </div>
                  <div className="text-slate-300 mt-0.5">
                    {missingCtCars.map(c => `${c.brand} ${c.model}`).join(', ')}
                  </div>
                </div>
              </div>
            )}

            {missingNonGage.length > 0 && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start gap-3">
                <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs">
                  <div className="font-bold text-rose-300">
                    Certificat de non-gage requis ({missingNonGage.length})
                  </div>
                  <div className="text-slate-300 mt-0.5">
                    Certificat SIV &lt; 15j à renouveler avant livraison.
                  </div>
                </div>
              </div>
            )}

            {missingMandat.length > 0 && (
              <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl flex items-start gap-3">
                <AlertTriangle className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs">
                  <div className="font-bold text-blue-300">
                    Mandat de vente en attente ({missingMandat.length})
                  </div>
                  <div className="text-slate-300 mt-0.5">
                    Obligatoire pour les véhicules en dépôt-vente.
                  </div>
                </div>
              </div>
            )}

            {missingCtCars.length === 0 && missingNonGage.length === 0 && missingMandat.length === 0 && (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <div className="text-xs text-slate-300">
                  <strong className="text-emerald-300 block">Dossiers administratifs à jour</strong>
                  Aucun blocage de carte grise ou certificat constaté.
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* 4. Section: Upcoming Appointments & Customer Test Drives */}
      <div className="p-6 bg-slate-900/70 border border-slate-800 rounded-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              Prochains Rendez-vous & Essais Clients
            </h2>
            <p className="text-xs text-slate-400">
              Essais routiers sur parc, livraisons programmées et visites commerciales
            </p>
          </div>
          <button
            onClick={onNavigateToAppointments}
            className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
          >
            Planning complet <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {upcomingApts.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">
            Aucun rendez-vous client prévu pour les prochaines 48 heures.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingApts.map((apt) => {
              const aptDate = new Date(apt.date);
              const formattedDate = aptDate.toLocaleDateString('fr-FR', {
                weekday: 'short',
                day: 'numeric',
                month: 'short',
                hour: '2-digit',
                minute: '2-digit'
              });

              return (
                <div
                  key={apt.id}
                  className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-amber-400 capitalize">{formattedDate}</span>
                      <span className="text-slate-400 text-[11px]">{apt.durationMinutes} min</span>
                    </div>

                    <div className="text-sm font-bold text-white mt-1">
                      {apt.clientName}
                    </div>
                    <div className="text-xs text-slate-400 font-medium truncate">
                      {apt.vehicleName}
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-500 mt-2">
                      <span>{apt.type === 'essai_routier' ? 'Essai Routier' : apt.type === 'livraison' ? 'Livraison' : 'Visite'}</span>
                      <span aria-hidden="true">·</span>
                      <span className={apt.driverLicenseChecked ? 'text-emerald-400' : 'text-amber-400'}>
                        {apt.driverLicenseChecked ? 'Permis vérifié' : 'Permis à vérifier'}
                      </span>
                    </div>

                    {apt.notes && (
                      <p className="text-[11px] text-slate-400 italic line-clamp-2 mt-2 bg-slate-900/60 p-2 rounded">
                        "{apt.notes}"
                      </p>
                    )}
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      Par {apt.assignedTo}
                    </span>
                    <button
                      onClick={() => onCompleteAppointment(apt)}
                      className="px-2.5 py-1 text-[11px] font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer"
                    >
                      Marquer effectué
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 5. Section: Recent Vehicles with Instant Actions (Affiche Pare-brise, Brochure, Annonce IA) */}
      <div className="p-6 bg-slate-900/70 border border-slate-800 rounded-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white">Véhicules Récents en Parc</h2>
            <p className="text-xs text-slate-400">
              Générez instantanément la fiche vitrine pare-brise, le PDF client ou l'annonce IA
            </p>
          </div>
          <button
            onClick={onNavigateToStock}
            className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
          >
            Tous les véhicules <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {vehicles.slice(0, 4).map((car) => {
            const photo = car.images?.[0] || car.mediaItems?.find(m => m.type === 'photo')?.url || null;
            const margin = car.sellingPrice - (car.costs.purchasePrice + car.costs.transport + car.costs.reconditioning + car.costs.detailing + car.costs.inspection + car.costs.adminFees + car.costs.warrantyCost);

            return (
              <div
                key={car.id}
                className="bg-slate-950/80 border border-slate-800 rounded-xl overflow-hidden flex flex-col justify-between group hover:border-slate-700 transition-all"
              >
                <div>
                  {/* Photo container */}
                  <div className="relative aspect-16/9 overflow-hidden bg-slate-900 flex items-center justify-center">
                    {photo ? (
                      <img
                        src={photo}
                        alt={`${car.brand} ${car.model}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-600 bg-slate-950">
                        <Car className="w-8 h-8 text-slate-700 mb-1" />
                        <span className="text-[10px] text-slate-500 font-medium">Aucune photo</span>
                      </div>
                    )}
                    <div className="absolute top-2 left-2 bg-slate-950/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-bold text-white font-mono">
                      {car.registration}
                    </div>
                    <div className="absolute top-2 right-2 bg-amber-500/90 text-slate-950 px-2 py-0.5 rounded text-[10px] font-bold uppercase">
                      {car.status === 'en_stock' ? 'En stock' : car.status === 'reserve' ? 'Réservé' : car.status}
                    </div>
                  </div>

                  <div className="p-4 space-y-2">
                    <div>
                      <div className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors truncate">
                        {car.brand} {car.model}
                      </div>
                      <div className="text-xs text-slate-400 truncate">
                        {car.version}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                      <span>{car.year} · {Number(car.mileage).toLocaleString('fr-FR')} km</span>
                      <span className="font-semibold text-white">{car.fuel}</span>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-baseline justify-between">
                      <div>
                        <div className="text-base font-extrabold text-white tabular-nums">
                          {Number(car.sellingPrice).toLocaleString('fr-FR')} €
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {car.monthlyEstimate ? `dès ${car.monthlyEstimate} €/mois` : 'Paiement comptant'}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-bold text-emerald-400 tabular-nums">
                          +{margin.toLocaleString('fr-FR')} €
                        </div>
                        <div className="text-[10px] text-slate-500">Marge nette estimée</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Instant Tools Toolbar */}
                <div className="p-3 pt-0 grid grid-cols-3 gap-1.5 border-t border-slate-900">
                  <button
                    onClick={() => onOpenWindowSticker(car)}
                    title="Fiche Vitrine Pare-Brise (Affiche Parc A4)"
                    className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-400 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Affiche Parc</span>
                  </button>

                  <button
                    onClick={() => onOpenBrochure(car)}
                    title="Brochure PDF Détaillée Client"
                    className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-400 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Fiche PDF</span>
                  </button>

                  <button
                    onClick={() => onOpenAiAd(car)}
                    title="Générateur d'Annonce IA (Leboncoin, La Centrale)"
                    className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-400 rounded-lg text-[10px] font-semibold flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Annonce IA</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
