import React, { useState } from 'react';
import { Vehicle, DocumentStatus, EmailDocType, VehicleDocumentFile, DocumentCategory } from '../types';
import { 
  FileCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  FileText, 
  Upload, 
  Search, 
  ShieldAlert,
  Car,
  Key,
  BookOpen,
  Mail,
  Send,
  FileSignature,
  Download
} from 'lucide-react';

interface DocumentsViewProps {
  vehicles: Vehicle[];
  onUpdateVehicleDocuments: (vehicleId: string, docs: any) => void;
  onUpdateVehicle?: (vehicleId: string, updates: Partial<Vehicle>) => void;
  onOpenVehicleModal: (vehicle: Vehicle) => void;
  onOpenSalesMandate?: (vehicle: Vehicle) => void;
  onOpenSendEmail?: (vehicle?: Vehicle, docType?: EmailDocType) => void;
}

export const DocumentsView: React.FC<DocumentsViewProps> = ({
  vehicles,
  onUpdateVehicleDocuments,
  onUpdateVehicle,
  onOpenVehicleModal,
  onOpenSalesMandate,
  onOpenSendEmail
}) => {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'incomplete' | 'ct_due' | 'mandat_due'>('all');

  const filteredVehicles = vehicles.filter((v) => {
    const matchesSearch = 
      v.brand.toLowerCase().includes(search.toLowerCase()) ||
      v.model.toLowerCase().includes(search.toLowerCase()) ||
      v.registration.toLowerCase().includes(search.toLowerCase());

    const hasIncomplete = 
      v.documents.carteGrise !== 'complet' ||
      v.documents.certificatNonGage !== 'complet' ||
      v.documents.certificatCession !== 'complet' ||
      (v.documents.controleTechnique !== 'complet' && v.documents.controleTechnique !== 'non_requis') ||
      (v.businessType === 'depot_vente' && v.documents.mandatVente !== 'complet');

    const ctDue = v.documents.controleTechnique === 'manquant' || v.documents.controleTechnique === 'en_attente';
    const mandatDue = v.businessType === 'depot_vente' && v.documents.mandatVente !== 'complet';

    if (filterType === 'incomplete') return matchesSearch && hasIncomplete;
    if (filterType === 'ct_due') return matchesSearch && ctDue;
    if (filterType === 'mandat_due') return matchesSearch && mandatDue;
    return matchesSearch;
  });

  const getStatusBadge = (status: DocumentStatus) => {
    switch (status) {
      case 'complet':
        return <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">✓ Conforme</span>;
      case 'en_attente':
        return <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">⏳ En attente</span>;
      case 'manquant':
        return <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded">✕ Manquant</span>;
      case 'non_requis':
        return <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-800 px-2 py-0.5 rounded">Non requis</span>;
    }
  };

  const handleQuickStatusChange = (vehicle: Vehicle, docKey: string, newStatus: DocumentStatus) => {
    const updatedDocs = {
      ...vehicle.documents,
      [docKey]: newStatus
    };
    onUpdateVehicleDocuments(vehicle.id, updatedDocs);
  };

  const handleUploadSpecificDoc = (car: Vehicle, category: DocumentCategory, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const immatLabel = car.registration.trim().toUpperCase() || 'VEHICULE';
      
      let docCategoryName = 'Document';
      let docStatusKey = 'autre';

      if (category === 'carte_grise') {
        docCategoryName = `Carte_Grise_${immatLabel}`;
        docStatusKey = 'carteGrise';
      } else if (category === 'non_gage') {
        docCategoryName = `Certificat_Non_Gage_${immatLabel}`;
        docStatusKey = 'certificatNonGage';
      } else if (category === 'cession') {
        docCategoryName = `Certificat_Cession_${immatLabel}`;
        docStatusKey = 'certificatCession';
      } else if (category === 'ct') {
        docCategoryName = `Controle_Technique_${immatLabel}`;
        docStatusKey = 'controleTechnique';
      } else if (category === 'mandat') {
        docCategoryName = `Mandat_Vente_${immatLabel}`;
        docStatusKey = 'mandatVente';
      }

      const newDoc: VehicleDocumentFile = {
        id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        name: `${docCategoryName}_${file.name}`,
        type: file.type || 'application/octet-stream',
        category,
        url: result,
        uploadDate: new Date().toISOString().slice(0, 10),
        size: `${(file.size / (1024 * 1024)).toFixed(2)} Mo`
      };

      const updatedDocs = {
        ...car.documents,
        ...(docStatusKey !== 'autre' ? { [docStatusKey]: 'complet' } : {})
      };

      const existingFiles = car.documentFiles || [];
      const updatedFiles = [newDoc, ...existingFiles.filter(f => f.category !== category)];

      if (onUpdateVehicle) {
        onUpdateVehicle(car.id, {
          documents: updatedDocs,
          documentFiles: updatedFiles
        });
      } else {
        onUpdateVehicleDocuments(car.id, updatedDocs);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Gestion des Documents Administratifs & SIV
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Suivi réglementaire : Cartes grises, certificats de non-gage, contrôles techniques, mandats et cessions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {onOpenSendEmail && (
            <button
              onClick={() => onOpenSendEmail()}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-sm cursor-pointer whitespace-nowrap"
            >
              <Mail className="w-4 h-4" />
              <span>Envoyer Facture & Docs (TBD AUTOS)</span>
            </button>
          )}
          <div className="hidden sm:block px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300">
            Expéditeur : <span className="font-mono text-amber-400 font-semibold">tbdautos@gmail.com</span>
          </div>
        </div>
      </div>

      {/* TBD AUTOS Quick Dispatch Helper Card */}
      <div className="p-4 bg-gradient-to-r from-slate-900 to-slate-900/60 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
            <Send className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-2">
              <span>Service d'Envoi Administratif & Facturation · TBD AUTOS</span>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded font-mono">
                tbdautos@gmail.com
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Transmettez vos factures d'achat acquittées, dossiers SIV complets ou mandats de dépôt-vente avec messages pré-inscrits et entièrement modifiables en direct.
            </p>
          </div>
        </div>

        {onOpenSendEmail && (
          <button
            onClick={() => onOpenSendEmail()}
            className="px-3 py-1.5 text-xs font-bold text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg transition-colors cursor-pointer shrink-0"
          >
            Nouveau message personnalisé
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              filterType === 'all' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-800'
            }`}
          >
            Tous les véhicules ({vehicles.length})
          </button>
          <button
            onClick={() => setFilterType('incomplete')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              filterType === 'incomplete' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-800'
            }`}
          >
            Dossiers incomplets
          </button>
          <button
            onClick={() => setFilterType('ct_due')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              filterType === 'ct_due' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-800'
            }`}
          >
            CT à programmer
          </button>
          <button
            onClick={() => setFilterType('mandat_due')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              filterType === 'mandat_due' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-800'
            }`}
          >
            Mandats dépôt-vente
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filtrer immat, marque..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* Vehicles Administrative Audit Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Véhicule & Immat</th>
                <th className="py-3.5 px-4">Carte Grise</th>
                <th className="py-3.5 px-4">Non-Gage (&lt;15j)</th>
                <th className="py-3.5 px-4">Cession (Cerfa)</th>
                <th className="py-3.5 px-4">Contrôle Tech.</th>
                <th className="py-3.5 px-4">Mandat Vente</th>
                <th className="py-3.5 px-4">Clés & Carnet</th>
                <th className="py-3.5 px-4 text-center">Fichiers & Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredVehicles.map((car) => {
                return (
                  <tr key={car.id} className="hover:bg-slate-800/50 transition-colors">
                    
                    {/* Vehicle */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-white">{car.brand} {car.model}</div>
                      <div className="text-[11px] font-mono text-amber-400 font-semibold">{car.registration}</div>
                      <div className="text-[10px] text-slate-500">{car.businessType === 'depot_vente' ? 'Dépôt-vente' : 'Achat-revente'}</div>
                    </td>

                    {/* Carte Grise */}
                    <td className="py-3.5 px-4">
                      <select
                        value={car.documents.carteGrise}
                        onChange={(e) => handleQuickStatusChange(car, 'carteGrise', e.target.value as DocumentStatus)}
                        className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200"
                      >
                        <option value="complet">Complet</option>
                        <option value="en_attente">En attente</option>
                        <option value="manquant">Manquant</option>
                      </select>
                      <div className="mt-1">{getStatusBadge(car.documents.carteGrise)}</div>

                      {/* Upload Carte Grise by nature */}
                      <div className="mt-1.5 space-y-1">
                        {car.documentFiles?.find(f => f.category === 'carte_grise') ? (
                          <a
                            href={car.documentFiles.find(f => f.category === 'carte_grise')?.url}
                            download={car.documentFiles.find(f => f.category === 'carte_grise')?.name}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] text-amber-400 hover:text-amber-300 font-mono truncate max-w-[130px]"
                            title="Télécharger / Voir la Carte Grise"
                          >
                            <FileText className="w-3 h-3 shrink-0" />
                            <span className="truncate">CG enregistrée</span>
                          </a>
                        ) : (
                          <label className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-amber-400 font-medium cursor-pointer">
                            <Upload className="w-3 h-3 text-amber-400" />
                            <span>Uploader CG</span>
                            <input
                              type="file"
                              accept=".pdf,image/*"
                              onChange={(e) => handleUploadSpecificDoc(car, 'carte_grise', e)}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>
                    </td>

                    {/* Non-Gage */}
                    <td className="py-3.5 px-4">
                      <select
                        value={car.documents.certificatNonGage}
                        onChange={(e) => handleQuickStatusChange(car, 'certificatNonGage', e.target.value as DocumentStatus)}
                        className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200"
                      >
                        <option value="complet">Complet</option>
                        <option value="en_attente">À renouveler</option>
                        <option value="manquant">Manquant</option>
                      </select>
                      <div className="mt-1">{getStatusBadge(car.documents.certificatNonGage)}</div>

                      {/* Upload Non-Gage by nature */}
                      <div className="mt-1.5 space-y-1">
                        {car.documentFiles?.find(f => f.category === 'non_gage') ? (
                          <a
                            href={car.documentFiles.find(f => f.category === 'non_gage')?.url}
                            download={car.documentFiles.find(f => f.category === 'non_gage')?.name}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] text-amber-400 hover:text-amber-300 font-mono truncate max-w-[130px]"
                            title="Télécharger / Voir le certificat Non-Gage"
                          >
                            <FileText className="w-3 h-3 shrink-0" />
                            <span className="truncate">Non-Gage OK</span>
                          </a>
                        ) : (
                          <label className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-amber-400 font-medium cursor-pointer">
                            <Upload className="w-3 h-3 text-amber-400" />
                            <span>Uploader Non-Gage</span>
                            <input
                              type="file"
                              accept=".pdf,image/*"
                              onChange={(e) => handleUploadSpecificDoc(car, 'non_gage', e)}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>
                    </td>

                    {/* Cession */}
                    <td className="py-3.5 px-4">
                      <select
                        value={car.documents.certificatCession}
                        onChange={(e) => handleQuickStatusChange(car, 'certificatCession', e.target.value as DocumentStatus)}
                        className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200"
                      >
                        <option value="complet">Signé</option>
                        <option value="en_attente">En attente</option>
                        <option value="manquant">Manquant</option>
                      </select>
                      <div className="mt-1">{getStatusBadge(car.documents.certificatCession)}</div>

                      {/* Upload Cession by nature */}
                      <div className="mt-1.5 space-y-1">
                        {car.documentFiles?.find(f => f.category === 'cession') ? (
                          <a
                            href={car.documentFiles.find(f => f.category === 'cession')?.url}
                            download={car.documentFiles.find(f => f.category === 'cession')?.name}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] text-amber-400 hover:text-amber-300 font-mono truncate max-w-[130px]"
                            title="Télécharger / Voir le Cerfa Cession"
                          >
                            <FileText className="w-3 h-3 shrink-0" />
                            <span className="truncate">Cerfa Cession</span>
                          </a>
                        ) : (
                          <label className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-amber-400 font-medium cursor-pointer">
                            <Upload className="w-3 h-3 text-amber-400" />
                            <span>Uploader Cession</span>
                            <input
                              type="file"
                              accept=".pdf,image/*"
                              onChange={(e) => handleUploadSpecificDoc(car, 'cession', e)}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>
                    </td>

                    {/* Contrôle Technique */}
                    <td className="py-3.5 px-4">
                      <select
                        value={car.documents.controleTechnique}
                        onChange={(e) => handleQuickStatusChange(car, 'controleTechnique', e.target.value as DocumentStatus)}
                        className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200"
                      >
                        <option value="complet">Valide (&lt;6m)</option>
                        <option value="en_attente">À programmer</option>
                        <option value="manquant">Manquant</option>
                        <option value="non_requis">Non requis</option>
                      </select>
                      <div className="mt-1">{getStatusBadge(car.documents.controleTechnique)}</div>

                      {/* Upload CT by nature */}
                      <div className="mt-1.5 space-y-1">
                        {car.documentFiles?.find(f => f.category === 'ct') ? (
                          <a
                            href={car.documentFiles.find(f => f.category === 'ct')?.url}
                            download={car.documentFiles.find(f => f.category === 'ct')?.name}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] text-amber-400 hover:text-amber-300 font-mono truncate max-w-[130px]"
                            title="Télécharger / Voir le Contrôle Technique"
                          >
                            <FileText className="w-3 h-3 shrink-0" />
                            <span className="truncate">Scan CT OK</span>
                          </a>
                        ) : (
                          <label className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-amber-400 font-medium cursor-pointer">
                            <Upload className="w-3 h-3 text-amber-400" />
                            <span>Uploader CT</span>
                            <input
                              type="file"
                              accept=".pdf,image/*"
                              onChange={(e) => handleUploadSpecificDoc(car, 'ct', e)}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>
                    </td>

                    {/* Mandat de vente */}
                    <td className="py-3.5 px-4">
                      {car.businessType === 'depot_vente' ? (
                        <div className="space-y-1.5">
                          <select
                            value={car.documents.mandatVente}
                            onChange={(e) => handleQuickStatusChange(car, 'mandatVente', e.target.value as DocumentStatus)}
                            className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200"
                          >
                            <option value="complet">Signé</option>
                            <option value="en_attente">En attente</option>
                            <option value="manquant">Manquant</option>
                          </select>
                          <div>{getStatusBadge(car.documents.mandatVente)}</div>

                          {/* Direct Action: Remplir & Imprimer Mandat */}
                          {onOpenSalesMandate && (
                            <button
                              type="button"
                              onClick={() => onOpenSalesMandate(car)}
                              className="w-full inline-flex items-center justify-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-400/10 hover:bg-amber-400/25 border border-amber-400/30 px-2 py-1 rounded cursor-pointer transition-colors"
                              title="Remplir, générer et imprimer l'exemplaire du mandat de vente à faire signer"
                            >
                              <FileSignature className="w-3 h-3 text-amber-400" />
                              <span>Mandat à signer</span>
                            </button>
                          )}

                          {/* Upload Mandat signed scan */}
                          <div>
                            {car.documentFiles?.find(f => f.category === 'mandat') ? (
                              <a
                                href={car.documentFiles.find(f => f.category === 'mandat')?.url}
                                download={car.documentFiles.find(f => f.category === 'mandat')?.name}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-flex items-center gap-1 text-[10px] text-amber-400 hover:text-amber-300 font-mono truncate max-w-[130px]"
                                title="Télécharger / Voir le Mandat de vente signé"
                              >
                                <FileText className="w-3 h-3 shrink-0" />
                                <span className="truncate">Mandat scanné</span>
                              </a>
                            ) : (
                              <label className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-amber-400 font-medium cursor-pointer">
                                <Upload className="w-3 h-3 text-amber-400" />
                                <span>Uploader Mandat</span>
                                <input
                                  type="file"
                                  accept=".pdf,image/*"
                                  onChange={(e) => handleUploadSpecificDoc(car, 'mandat', e)}
                                  className="hidden"
                                />
                              </label>
                            )}
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-500 text-[11px]">N/A (Achat direct)</span>
                      )}
                    </td>

                    {/* Clés & Carnet */}
                    <td className="py-3.5 px-4">
                      <div className="space-y-1 text-[11px]">
                        <div className="flex items-center gap-1.5">
                          <Key className={`w-3.5 h-3.5 ${car.documents.doubleDesCles ? 'text-emerald-400' : 'text-slate-500'}`} />
                          <span className={car.documents.doubleDesCles ? 'text-white' : 'text-slate-500'}>
                            {car.documents.doubleDesCles ? '2 clés' : '1 seule clé'}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <BookOpen className={`w-3.5 h-3.5 ${car.documents.carnetEntretien ? 'text-emerald-400' : 'text-slate-500'}`} />
                          <span className={car.documents.carnetEntretien ? 'text-white' : 'text-slate-500'}>
                            {car.documents.carnetEntretien ? 'Carnet OK' : 'Sans carnet'}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Actions & Files */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => onOpenVehicleModal(car)}
                          className="px-2.5 py-1 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Dossier ({car.documents.files?.length || 0})</span>
                        </button>

                        {onOpenSendEmail && (
                          <button
                            onClick={() => onOpenSendEmail(car, car.businessType === 'achat_revente' ? 'facture_achat' : 'mandat_depot_vente')}
                            className="px-2.5 py-1 text-xs font-bold text-amber-300 hover:text-white bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/30 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                            title="Envoyer la facture d'achat ou les documents par email (tbdautos@gmail.com)"
                          >
                            <Mail className="w-3.5 h-3.5 text-amber-400" />
                            <span>Envoyer</span>
                          </button>
                        )}
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
