import React, { useState } from 'react';
import { Appointment, Vehicle, AppointmentType, AppointmentStatus } from '../types';
import { 
  Calendar, 
  Plus, 
  User, 
  Phone, 
  Mail, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  ShieldCheck, 
  Car, 
  FileText,
  Search
} from 'lucide-react';

interface AppointmentsViewProps {
  appointments: Appointment[];
  vehicles: Vehicle[];
  onOpenAppointmentModal: (apt?: Appointment) => void;
  onUpdateAppointmentStatus: (id: string, status: AppointmentStatus) => void;
  onDeleteAppointment: (id: string) => void;
}

export const AppointmentsView: React.FC<AppointmentsViewProps> = ({
  appointments,
  vehicles,
  onOpenAppointmentModal,
  onUpdateAppointmentStatus,
  onDeleteAppointment
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [search, setSearch] = useState('');

  const filteredAppointments = appointments
    .filter(apt => {
      const matchesSearch = 
        apt.clientName.toLowerCase().includes(search.toLowerCase()) ||
        apt.vehicleName.toLowerCase().includes(search.toLowerCase()) ||
        apt.clientPhone.includes(search);

      const matchesType = filterType === 'all' || apt.type === filterType;
      const matchesStatus = filterStatus === 'all' || apt.status === filterStatus;

      return matchesSearch && matchesType && matchesStatus;
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const testDrivesCount = appointments.filter(a => a.type === 'essai_routier' && a.status === 'confirme').length;
  const deliveriesCount = appointments.filter(a => a.type === 'livraison' && a.status === 'confirme').length;

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Rendez-vous, Essais Routiers & Livraisons
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Planification des essais clients, vérification des permis de conduire et suivi des livraisons de véhicules.
          </p>
        </div>

        <button
          onClick={() => onOpenAppointmentModal()}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau Rendez-vous</span>
        </button>
      </div>

      {/* Mini Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block">Essais Routiers Confirmés</span>
            <span className="text-2xl font-extrabold text-amber-400 tabular-nums block mt-0.5">
              {testDrivesCount}
            </span>
          </div>
          <Car className="w-6 h-6 text-slate-600" />
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block">Livraisons Programmées</span>
            <span className="text-2xl font-extrabold text-emerald-400 tabular-nums block mt-0.5">
              {deliveriesCount}
            </span>
          </div>
          <CheckCircle2 className="w-6 h-6 text-slate-600" />
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block">Total Enregistrés</span>
            <span className="text-2xl font-extrabold text-white tabular-nums block mt-0.5">
              {appointments.length}
            </span>
          </div>
          <Calendar className="w-6 h-6 text-slate-600" />
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher client, véhicule, tél..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>

        <div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">Tous les types de visites</option>
            <option value="essai_routier">Essai Routier</option>
            <option value="visite_commerciale">Visite & Présentation</option>
            <option value="livraison">Livraison Client</option>
            <option value="expertise_reprise">Expertise Reprise</option>
          </select>
        </div>

        <div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">Tous les statuts</option>
            <option value="confirme">Confirmé</option>
            <option value="en_attente">En attente</option>
            <option value="effectue">Effectué</option>
            <option value="annule">Annulé</option>
          </select>
        </div>
      </div>

      {/* Appointments List */}
      {filteredAppointments.length === 0 ? (
        <div className="p-12 text-center bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
          <Calendar className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">Aucun rendez-vous trouvé</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Aucun rendez-vous ne correspond à vos critères de recherche.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredAppointments.map((apt) => {
            const aptDate = new Date(apt.date);
            const dateStr = aptDate.toLocaleDateString('fr-FR', {
              weekday: 'long',
              day: 'numeric',
              month: 'long',
              year: 'numeric'
            });
            const timeStr = aptDate.toLocaleTimeString('fr-FR', {
              hour: '2-digit',
              minute: '2-digit'
            });

            return (
              <div
                key={apt.id}
                className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 hover:border-slate-700 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-xs font-bold text-amber-400 capitalize block">
                        {dateStr} à {timeStr}
                      </span>
                      <h3 className="text-base font-extrabold text-white mt-0.5">
                        {apt.clientName}
                      </h3>
                      <div className="text-xs text-slate-400 font-medium">
                        Véhicule : <strong className="text-slate-200">{apt.vehicleName}</strong>
                      </div>
                    </div>

                    <span className={`px-2.5 py-1 rounded text-[11px] font-bold uppercase ${
                      apt.status === 'confirme' ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' :
                      apt.status === 'en_attente' ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30' :
                      apt.status === 'effectue' ? 'bg-blue-500/15 text-blue-400 border border-blue-500/30' :
                      'bg-slate-800 text-slate-400'
                    }`}>
                      {apt.status === 'confirme' ? 'Confirmé' :
                       apt.status === 'en_attente' ? 'En attente' :
                       apt.status === 'effectue' ? 'Effectué' : 'Annulé'}
                    </span>
                  </div>

                  {/* Contact details */}
                  <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-800/80 text-xs text-slate-400">
                    <div className="flex items-center gap-1.5 truncate">
                      <Phone className="w-3.5 h-3.5 text-slate-500" />
                      <a href={`tel:${apt.clientPhone}`} className="hover:text-amber-400 text-slate-300">
                        {apt.clientPhone}
                      </a>
                    </div>
                    {apt.clientEmail && (
                      <div className="flex items-center gap-1.5 truncate">
                        <Mail className="w-3.5 h-3.5 text-slate-500" />
                        <span className="truncate">{apt.clientEmail}</span>
                      </div>
                    )}
                  </div>

                  {/* Verification Badges */}
                  <div className="flex flex-wrap items-center gap-2 mt-3 pt-2 text-[11px]">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded font-medium ${
                      apt.driverLicenseChecked 
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}>
                      <ShieldCheck className="w-3 h-3" />
                      {apt.driverLicenseChecked ? 'Permis B vérifié' : 'Permis non vérifié'}
                    </span>

                    {apt.depositLeft && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded font-medium bg-blue-500/10 text-blue-400 border border-blue-500/20">
                        Caution CB enregistrée
                      </span>
                    )}

                    <span className="text-slate-500">
                      Conseiller : {apt.assignedTo}
                    </span>
                  </div>

                  {apt.notes && (
                    <div className="mt-3 p-2.5 bg-slate-950/70 border border-slate-800/80 rounded-lg text-xs text-slate-300 italic">
                      "{apt.notes}"
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                  <div className="flex items-center gap-2">
                    {apt.status !== 'effectue' && (
                      <button
                        onClick={() => onUpdateAppointmentStatus(apt.id, 'effectue')}
                        className="px-2.5 py-1 text-xs font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 rounded-lg transition-colors cursor-pointer"
                      >
                        ✓ Marquer effectué
                      </button>
                    )}
                    {apt.status !== 'annule' && (
                      <button
                        onClick={() => onUpdateAppointmentStatus(apt.id, 'annule')}
                        className="px-2.5 py-1 text-xs font-medium text-slate-400 hover:text-rose-400 bg-slate-800 rounded-lg transition-colors cursor-pointer"
                      >
                        Annuler
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onOpenAppointmentModal(apt)}
                      className="text-xs font-medium text-slate-400 hover:text-white cursor-pointer"
                    >
                      Modifier
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer le rendez-vous de ${apt.clientName} ?`)) {
                          onDeleteAppointment(apt.id);
                        }
                      }}
                      className="text-xs text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
