import React, { useState } from 'react';
import { Vehicle, Seller, SalesMandateInfo } from '../types';
import { Printer, X, Shield, FileText, CheckCircle2, User, Building2 } from 'lucide-react';

interface SalesMandateModalProps {
  vehicle: Vehicle | null;
  seller?: Seller | null;
  onClose: () => void;
  onSaveMandate?: (vehicleId: string, mandate: SalesMandateInfo) => void;
}

export const SalesMandateModal: React.FC<SalesMandateModalProps> = ({
  vehicle,
  seller,
  onClose,
  onSaveMandate
}) => {
  if (!vehicle) return null;

  const currentSeller = seller || vehicle.seller;
  const existingMandate = vehicle.salesMandate;

  // Editable fields with smart defaults
  const [mandantType, setMandantType] = useState<'particulier' | 'professionnel'>(
    existingMandate?.mandantType || currentSeller?.type || 'particulier'
  );
  const [mandantName, setMandantName] = useState(
    existingMandate?.mandantName || currentSeller?.name || ''
  );
  const [mandantFirstName, setMandantFirstName] = useState(
    existingMandate?.mandantFirstName || ''
  );
  const [sirenSiret, setSirenSiret] = useState(
    existingMandate?.sirenSiret || currentSeller?.siret || currentSeller?.siren || ''
  );
  const [representedBy, setRepresentedBy] = useState(
    existingMandate?.representedBy || currentSeller?.managerName || ''
  );
  const [address, setAddress] = useState(
    existingMandate?.address || currentSeller?.address || ''
  );
  const [postalCodeCity, setPostalCodeCity] = useState(
    existingMandate?.postalCodeCity || 
    (currentSeller ? `${currentSeller.postalCode || ''} ${currentSeller.city || ''}`.trim() : '')
  );
  const [phone, setPhone] = useState(
    existingMandate?.phone || currentSeller?.phone || ''
  );
  const [email, setEmail] = useState(
    existingMandate?.email || currentSeller?.email || ''
  );
  const [idDocNumber, setIdDocNumber] = useState(
    existingMandate?.idDocNumber || currentSeller?.idDocumentNumber || ''
  );
  const [idDocDeliveredDateBy, setIdDocDeliveredDateBy] = useState(
    existingMandate?.idDocDeliveredDateBy || 'Préfecture'
  );

  const [netSellerPrice, setNetSellerPrice] = useState<number>(
    existingMandate?.netSellerPrice ?? vehicle.sellerDesiredPrice ?? vehicle.costs.purchasePrice ?? 0
  );
  const [ctStatus, setCtStatus] = useState<'moins_6_mois' | 'a_effectuer_mandant' | 'a_effectuer_mandataire'>(
    existingMandate?.ctStatus || 'moins_6_mois'
  );
  const [carteGriseFormulaNumber, setCarteGriseFormulaNumber] = useState(
    existingMandate?.carteGriseFormulaNumber || ''
  );
  const [doubleKeys, setDoubleKeys] = useState<boolean>(
    existingMandate?.doubleKeys ?? vehicle.documents?.doubleDesCles ?? true
  );
  const [contractDurationDays, setContractDurationDays] = useState<number>(
    existingMandate?.contractDurationDays || 30
  );
  const [signaturePlace, setSignaturePlace] = useState(
    existingMandate?.signaturePlace || 'Villenave d\'Ornon'
  );
  const [signatureDate, setSignatureDate] = useState(
    existingMandate?.signatureDate || new Date().toISOString().slice(0, 10)
  );

  const handlePrint = () => {
    // Save updated mandate info if handler provided
    if (onSaveMandate) {
      onSaveMandate(vehicle.id, {
        mandantType,
        mandantName,
        mandantFirstName,
        sirenSiret,
        representedBy,
        address,
        postalCodeCity,
        phone,
        email,
        idDocNumber,
        idDocDeliveredDateBy,
        netSellerPrice,
        ctStatus,
        carteGriseFormulaNumber,
        doubleKeys,
        contractDurationDays,
        signatureDate,
        signaturePlace
      });
    }
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-8 flex flex-col">
        
        {/* Screen Controls Header (hidden on print) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-amber-400" />
              <span>Mandat de Vente Automobile Officiel (Dépôt-Vente)</span>
            </h2>
            <p className="text-xs text-slate-400">
              {vehicle.brand} {vehicle.model} ({vehicle.registration}) · Modèle officiel 2 pages avec cadre juridique & RGPD.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimer / Enregistrer PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Canvas */}
        <div className="p-6 sm:p-10 bg-white text-slate-950 font-sans text-xs leading-relaxed max-h-[85vh] overflow-y-auto print:max-h-none print:overflow-visible print:p-0">
          
          {/* ================= PAGE 1 ================= */}
          <div className="space-y-4 print:min-h-[297mm] print:p-8 flex flex-col justify-between">
            <div>
              {/* Dealership Official Header */}
              <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <div className="w-10 h-10 rounded-lg bg-slate-950 text-amber-400 flex items-center justify-center font-black text-xl tracking-tighter">
                    T
                  </div>
                  <div className="text-xs font-bold text-slate-800 uppercase tracking-wider mt-1">
                    Courtage & Dépôt-Vente Automobile
                  </div>
                </div>

                <div className="text-right text-[11px] text-slate-700 space-y-0.5">
                  <div className="font-extrabold text-sm text-slate-950 uppercase tracking-tight">TBD AUTOS</div>
                  <div>Siège social : Résidence Sarcignan, Chemin Gaston</div>
                  <div>33140 Villenave d'Ornon</div>
                  <div className="font-mono text-[10px]">SIRET : 937 534 097 00012</div>
                  <div className="font-mono text-[10px]">Courriel : tbdautos@gmail.com</div>
                </div>
              </div>

              {/* Title Strip */}
              <div className="mt-4 border-y-2 border-slate-950 py-2.5 bg-slate-100 text-center">
                <h1 className="text-sm font-black tracking-widest uppercase text-slate-950">
                  MANDAT DE VENTE AUTOMOBILE
                </h1>
              </div>

              {/* 1. LE MANDATAIRE */}
              <div className="mt-3 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1 text-xs">
                  1. LE MANDATAIRE
                </div>
                <div className="p-2.5 text-[10.5px] text-slate-700 leading-relaxed">
                  <strong>TBD AUTOS</strong>, immatriculée sous le SIRET <strong>937 534 097 00012</strong>, dont le siège est situé Résidence Sarcignan, Chemin Gaston, 33140 Villenave d'Ornon, représentée par son dirigeant, ci-après dénommée le « <strong>Mandataire</strong> ».
                </div>
              </div>

              {/* 2. LE MANDANT (PROPRIÉTAIRE DU VÉHICULE) */}
              <div className="mt-3 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1 text-xs flex justify-between items-center">
                  <span>2. LE MANDANT (PROPRIÉTAIRE DU VÉHICULE)</span>
                  <div className="flex items-center gap-4 text-[10px] font-normal">
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={mandantType === 'particulier'} 
                        onChange={() => setMandantType('particulier')}
                        className="accent-amber-400 no-print" 
                      />
                      <span>PARTICULIER</span>
                    </label>
                    <label className="inline-flex items-center gap-1 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={mandantType === 'professionnel'} 
                        onChange={() => setMandantType('professionnel')}
                        className="accent-amber-400 no-print" 
                      />
                      <span>PROFESSIONNEL</span>
                    </label>
                  </div>
                </div>

                <div className="p-3 grid grid-cols-2 gap-x-4 gap-y-2 text-[10.5px]">
                  <div>
                    <span className="text-slate-500 block">Nom / Raison Sociale :</span>
                    <strong className="text-slate-900 text-xs">{mandantName || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Prénom (si particulier) :</span>
                    <strong className="text-slate-900 text-xs">{mandantFirstName || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">N° SIREN / SIRET (si pro) :</span>
                    <strong className="text-slate-900 font-mono">{sirenSiret || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Représenté par (si pro) :</span>
                    <strong className="text-slate-900">{representedBy || '—'}</strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 block">Adresse / Siège Social :</span>
                    <strong className="text-slate-900">{address || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Code Postal & Ville :</span>
                    <strong className="text-slate-900">{postalCodeCity || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Téléphone :</span>
                    <strong className="text-slate-900">{phone || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Adresse e-mail :</span>
                    <strong className="text-slate-900">{email || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Pièce d'identité N° & Délivrée le / par :</span>
                    <strong className="text-slate-900">{idDocNumber ? `${idDocNumber} (${idDocDeliveredDateBy})` : '—'}</strong>
                  </div>
                </div>
              </div>

              {/* 3. DÉSIGNATION DU VÉHICULE */}
              <div className="mt-3 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1 text-xs">
                  3. DÉSIGNATION DU VÉHICULE
                </div>

                <div className="p-3 grid grid-cols-3 gap-x-4 gap-y-2 text-[10.5px]">
                  <div>
                    <span className="text-slate-500 block">Marque :</span>
                    <strong className="text-slate-900 text-xs uppercase">{vehicle.brand}</strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 block">Modèle & Finition :</span>
                    <strong className="text-slate-900 text-xs">{vehicle.model} {vehicle.version}</strong>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Immatriculation :</span>
                    <strong className="text-slate-900 font-mono text-xs">{vehicle.registration}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">N° de Châssis (VIN) :</span>
                    <strong className="text-slate-900 font-mono text-[10px]">{vehicle.vin || '—'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">1ère Mise en circulation :</span>
                    <strong className="text-slate-900">{vehicle.firstRegistrationDate || `${vehicle.year}-01-01`}</strong>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Kilométrage compteur :</span>
                    <strong className="text-slate-900 tabular-nums">{Number(vehicle.mileage).toLocaleString('fr-FR')} km</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Énergie / Carburant :</span>
                    <strong className="text-slate-900">{vehicle.fuel}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Boîte de vitesse :</span>
                    <strong className="text-slate-900">{vehicle.gearbox}</strong>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Puissance (Ch / CV) :</span>
                    <strong className="text-slate-900">{vehicle.powerDin} ch ({vehicle.powerFiscal} CV)</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Couleur :</span>
                    <strong className="text-slate-900">{vehicle.colorExterior}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Double des clés :</span>
                    <strong className="text-slate-900">{doubleKeys ? 'Oui' : 'Non'}</strong>
                  </div>

                  <div className="col-span-3">
                    <span className="text-slate-500 block">N° Formule Carte Grise :</span>
                    <strong className="text-slate-900 font-mono">{carteGriseFormulaNumber || '—'}</strong>
                  </div>
                </div>
              </div>

              {/* 4. PRIX NET VENDEUR & CONDITIONS */}
              <div className="mt-3 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1 text-xs">
                  4. PRIX NET VENDEUR & CONDITIONS
                </div>

                <div className="p-3 space-y-2.5 text-[10.5px]">
                  <div className="flex items-center justify-between p-2.5 bg-amber-50 border border-amber-200 rounded-lg">
                    <div>
                      <span className="text-slate-600 block text-xs">Prix Net Vendeur garanti au Mandant :</span>
                      <span className="text-[10px] text-slate-500">Montant net garanti reversé sans frais cachés après encaissement</span>
                    </div>
                    <strong className="text-slate-950 font-black text-base tabular-nums">
                      {netSellerPrice.toLocaleString('fr-FR')} € TTC
                    </strong>
                  </div>

                  <div className="flex flex-wrap items-center justify-between pt-1">
                    <span className="font-semibold text-slate-700">Contrôle Technique :</span>
                    <div className="flex items-center gap-3">
                      <label className="inline-flex items-center gap-1 cursor-pointer">
                        <input type="checkbox" checked={ctStatus === 'moins_6_mois'} onChange={() => setCtStatus('moins_6_mois')} className="accent-slate-900" />
                        <span>Moins de 6 mois</span>
                      </label>
                      <label className="inline-flex items-center gap-1 cursor-pointer">
                        <input type="checkbox" checked={ctStatus === 'a_effectuer_mandant'} onChange={() => setCtStatus('a_effectuer_mandant')} className="accent-slate-900" />
                        <span>À effectuer par le Mandant</span>
                      </label>
                      <label className="inline-flex items-center gap-1 cursor-pointer">
                        <input type="checkbox" checked={ctStatus === 'a_effectuer_mandataire'} onChange={() => setCtStatus('a_effectuer_mandataire')} className="accent-slate-900" />
                        <span>À effectuer par le Mandataire</span>
                      </label>
                    </div>
                  </div>

                  <p className="text-[9px] text-slate-500 italic border-t border-slate-200 pt-1.5">
                    * Note : Le prix net vendeur représente la somme exacte qui sera reversée au Mandant lors de la transaction finale, nette de tout frais administratif direct imputable au vendeur.
                  </p>
                </div>
              </div>
            </div>

            {/* Footer Page 1 */}
            <div className="pt-2 border-t border-slate-300 flex justify-between text-[9px] text-slate-500 uppercase tracking-wider">
              <span>TBD AUTOS — Mandat de Vente Automobile</span>
              <span>Page 1 / 2</span>
            </div>
          </div>

          {/* ================= PAGE 2 ================= */}
          <div className="space-y-4 print:min-h-[297mm] print:p-8 flex flex-col justify-between mt-8 print:mt-0 print:break-before-page border-t-2 border-dashed border-slate-300 pt-8 print:border-none print:pt-0">
            <div>
              {/* Header Mini Page 2 */}
              <div className="flex justify-between items-center pb-2 border-b border-slate-300 text-[10px] text-slate-500">
                <span className="font-bold text-slate-800">TBD AUTOS — Conditions Générales du Mandat</span>
                <span>Immatriculation : {vehicle.registration}</span>
              </div>

              {/* 5. OBJET ET POUVOIRS DU MANDAT */}
              <div className="mt-3 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1 text-xs">
                  5. OBJET ET POUVOIRS DU MANDAT
                </div>
                <div className="p-3 text-[9.5px] leading-relaxed text-slate-700 space-y-1.5">
                  <p>
                    Le Mandant confie au Mandataire, qui l'accepte, le pouvoir exclusif d'accomplir en son nom et pour son compte l'ensemble des démarches nécessaires à la vente du véhicule désigné en Page 1.
                  </p>
                  <p className="font-semibold">À ce titre, le Mandataire est autorisé à :</p>
                  <ul className="list-disc pl-4 space-y-0.5">
                    <li>Rédiger, publier et diffuser les annonces commerciales sur tout support de son choix.</li>
                    <li>Présenter le véhicule aux acquéreurs potentiels et organiser les visites / essais.</li>
                    <li>Négocier la vente dans la limite du prix net vendeur stipulé au présent contrat.</li>
                    <li>Encaisser le montant total de la transaction sur compte séquestre/dédié avant reversement au Mandant.</li>
                    <li>Effectuer les démarches administratives d'immatriculation (SIV) liées au changement de propriétaire.</li>
                  </ul>
                </div>
              </div>

              {/* 6. DURÉE ET DÉNONCIATION */}
              <div className="mt-3 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1 text-xs">
                  6. DURÉE ET DÉNONCIATION
                </div>
                <div className="p-3 text-[9.5px] leading-relaxed text-slate-700">
                  Le présent mandat est conclu pour une durée ferme de <strong>{contractDurationDays} jours</strong> à compter de sa signature. À l'échéance de cette période, il se poursuivra par tacite reconduction par périodes d'un mois, sauf dénonciation par l'une ou l'autre des parties par lettre recommandée avec accusé de réception ou courriel avec accusé de lecture, moyennant un préavis de 7 jours.
                </div>
              </div>

              {/* 7. CADRE JURIDIQUE ET PROTECTION DU CLIENT (RGPD) */}
              <div className="mt-3 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1 text-xs">
                  7. CADRE JURIDIQUE ET PROTECTION DU CLIENT (RGPD)
                </div>
                <div className="p-3 text-[9.5px] leading-relaxed text-slate-700 space-y-1.5 text-justify">
                  <p>
                    <strong>Cadre Légal :</strong> Le présent contrat est régi par les articles 1984 et suivants du Code Civil relatifs au mandat. Le Mandant garantit être le propriétaire légitime du véhicule, que celui-ci est libre de tout gage, opposition, privilège ou nantissement, et qu'il n'a subit aucun dommage majeur non révélé.
                  </p>
                  <p>
                    <strong>Protection de l'Identité et des Données Personnelles (RGPD) :</strong> Les données à caractère personnel collectées font l'objet d'un traitement sécurisé par TBD AUTOS, conformément au Règlement Général sur la Protection des Données (RGPD) et à la loi Informatique et Libertés. L'identité du Mandant, ses coordonnées ainsi que les documents d'immatriculation sont strictement confidentiels et ne seront sous aucun prétexte divulgués à des tiers non autorisés ou au futur acquéreur avant la finalisation ferme de la transaction. Le Mandant dispose d'un droit d'accès, de rectification et de suppression de ses données sur simple demande à tbdautos@gmail.com.
                  </p>
                </div>
              </div>

              {/* 8. VALIDATION ET SIGNATURES DES PARTIES */}
              <div className="mt-4 border border-slate-300 rounded-lg overflow-hidden">
                <div className="bg-slate-900 text-white font-bold px-3 py-1 text-xs">
                  8. VALIDATION ET SIGNATURES DES PARTIES
                </div>

                <div className="p-3 space-y-2">
                  <p className="text-[10px] text-slate-600">
                    Fait à <span className="underline font-semibold">{signaturePlace}</span>, le <span className="underline font-semibold">{new Date(signatureDate).toLocaleDateString('fr-FR')}</span>, en deux exemplaires originaux.
                  </p>

                  <div className="grid grid-cols-2 gap-4 pt-1">
                    {/* Mandant Signature Box */}
                    <div className="border border-slate-300 rounded p-3 min-h-[120px] flex flex-col justify-between bg-slate-50/50">
                      <div>
                        <div className="font-bold text-xs text-slate-900 uppercase">LE MANDANT</div>
                        <div className="text-[10px] text-slate-600">({mandantName} {mandantFirstName})</div>
                        <div className="text-[9px] text-slate-500 italic mt-0.5">
                          Mention manuscrite « Bon pour pouvoir » + Signature
                        </div>
                      </div>
                      <div className="border-b border-dashed border-slate-300 pt-6 text-center text-[9px] text-slate-400">
                        Signature du mandant
                      </div>
                    </div>

                    {/* Mandataire TBD AUTOS Box */}
                    <div className="border border-slate-300 rounded p-3 min-h-[120px] flex flex-col justify-between bg-slate-50/50">
                      <div>
                        <div className="font-bold text-xs text-slate-900 uppercase">LE MANDATAIRE</div>
                        <div className="text-[10px] font-semibold text-slate-800">TBD AUTOS</div>
                        <div className="text-[9px] text-slate-500 italic mt-0.5">
                          Signature et cachet de l'entreprise
                        </div>
                      </div>
                      <div className="border-b border-dashed border-slate-300 pt-6 text-center text-[9px] text-slate-400">
                        Cachet & Signature TBD AUTOS
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Page 2 */}
            <div className="pt-2 border-t border-slate-300 flex justify-between text-[9px] text-slate-500 uppercase tracking-wider">
              <span>TBD AUTOS — SIRET 937 534 097 00012</span>
              <span>Page 2 / 2</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
