import React, { useState } from 'react';
import { Vehicle } from '../types';
import { 
  X, 
  Car, 
  Calendar, 
  Gauge, 
  Fuel, 
  Cog, 
  ShieldCheck, 
  CheckCircle2, 
  Printer, 
  FileText, 
  Edit3, 
  Sparkles, 
  Award, 
  ChevronLeft, 
  ChevronRight, 
  Key, 
  BookOpen, 
  AlertCircle,
  PhoneCall,
  MapPin,
  Mail,
  Zap,
  BookmarkCheck
} from 'lucide-react';

interface VehicleShowModalProps {
  vehicle: Vehicle | null;
  onClose: () => void;
  onOpenReservation: (vehicle: Vehicle) => void;
  onOpenEdit?: (vehicle: Vehicle) => void;
  onOpenWindowSticker?: (vehicle: Vehicle) => void;
  onOpenBrochure?: (vehicle: Vehicle) => void;
}

export const VehicleShowModal: React.FC<VehicleShowModalProps> = ({
  vehicle,
  onClose,
  onOpenReservation,
  onOpenEdit,
  onOpenWindowSticker,
  onOpenBrochure
}) => {
  if (!vehicle) return null;

  // Photo gallery state
  const photos = [
    ...(vehicle.images || []),
    ...(vehicle.mediaItems?.filter(m => m.type === 'photo').map(m => m.url) || [])
  ].filter((url, idx, self) => url && self.indexOf(url) === idx);

  const [activePhotoIndex, setActivePhotoIndex] = useState(0);

  const handlePrevPhoto = () => {
    setActivePhotoIndex((prev) => (prev > 0 ? prev - 1 : photos.length - 1));
  };

  const handleNextPhoto = () => {
    setActivePhotoIndex((prev) => (prev < photos.length - 1 ? prev + 1 : 0));
  };

  // Warranty calculation
  const warrantyMonths = vehicle.warrantyInitialMonths ?? (vehicle.costs.warrantyCost > 0 ? 12 : 3);

  // Delivery pack calculations
  const carteGriseEstimated = vehicle.powerFiscal ? vehicle.powerFiscal * 45 : 250;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-8 flex flex-col">
        
        {/* Top Bar for Client Presentation */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/90">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-sm">
              T
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                  TBD AUTOS · Fiche Présentation Client
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                  vehicle.status === 'en_stock' ? 'bg-emerald-500/20 text-emerald-400' :
                  vehicle.status === 'reserve' ? 'bg-blue-500/20 text-blue-400' :
                  vehicle.status === 'en_preparation' ? 'bg-amber-400/20 text-amber-300' :
                  vehicle.status === 'vendu' ? 'bg-purple-500/20 text-purple-300' : 'bg-slate-800 text-slate-300'
                }`}>
                  {vehicle.status === 'en_stock' ? 'Disponible en parc' :
                   vehicle.status === 'reserve' ? 'Réservé' :
                   vehicle.status === 'en_preparation' ? 'En préparation' :
                   vehicle.status === 'vendu' ? 'Vendu' : vehicle.status}
                </span>
              </div>
              <h2 className="text-lg font-black text-white tracking-tight uppercase">
                {vehicle.brand} {vehicle.model}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Direct Reservation button */}
            <button
              onClick={() => onOpenReservation(vehicle)}
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer"
            >
              <BookmarkCheck className="w-4 h-4" />
              <span>Réserver ce véhicule</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Presentation Body View */}
        <div className="p-6 sm:p-8 space-y-8 overflow-y-auto max-h-[85vh]">
          
          {/* Main Visual & Photo Carousel */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Photo Gallery Column */}
            <div className="lg:col-span-7 space-y-3">
              <div className="relative aspect-16/10 rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center group shadow-xl">
                {photos.length > 0 ? (
                  <img
                    src={photos[activePhotoIndex]}
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-102"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-slate-600">
                    <Car className="w-16 h-16 text-slate-700 mb-2" />
                    <span className="text-xs text-slate-500">Aucune photo pour ce véhicule</span>
                  </div>
                )}

                {/* Carousel Controls */}
                {photos.length > 1 && (
                  <>
                    <button
                      onClick={handlePrevPhoto}
                      className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-slate-950/70 hover:bg-slate-950 text-white flex items-center justify-center backdrop-blur-sm transition-all cursor-pointer shadow-md"
                      title="Photo précédente"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={handleNextPhoto}
                      className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-slate-950/70 hover:bg-slate-950 text-white flex items-center justify-center backdrop-blur-sm transition-all cursor-pointer shadow-md"
                      title="Photo suivante"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                    <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur-sm text-white text-[11px] font-mono font-bold">
                      {activePhotoIndex + 1} / {photos.length}
                    </div>
                  </>
                )}

                {/* Badge Immatriculation & Carburant */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-lg text-xs font-mono font-bold text-white border border-slate-800">
                    {vehicle.registration}
                  </span>
                  <span className="bg-amber-400/90 text-slate-950 px-2.5 py-0.5 rounded-lg text-xs font-black uppercase shadow-sm">
                    {vehicle.fuel}
                  </span>
                </div>
              </div>

              {/* Thumbnail Strip */}
              {photos.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
                  {photos.map((p, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActivePhotoIndex(idx)}
                      className={`relative w-20 h-14 rounded-lg overflow-hidden border-2 shrink-0 transition-all cursor-pointer ${
                        activePhotoIndex === idx ? 'border-amber-400 ring-2 ring-amber-400/30' : 'border-slate-800 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={p} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Pricing & Key Information Column */}
            <div className="lg:col-span-5 space-y-4">
              
              <div>
                <span className="text-xs font-semibold text-slate-400 block uppercase tracking-wider">
                  Finition & Version
                </span>
                <h3 className="text-xl font-bold text-white mt-0.5">
                  {vehicle.version || `${vehicle.brand} ${vehicle.model}`}
                </h3>
              </div>

              {/* Price Box */}
              <div className="p-5 bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl space-y-3 shadow-lg">
                <div className="flex items-baseline justify-between">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Prix de Vente TTC</span>
                  <span className="text-3xl font-black text-amber-400 tabular-nums">
                    {Number(vehicle.sellingPrice).toLocaleString('fr-FR')} €
                  </span>
                </div>

                <div className="p-2.5 bg-amber-400/10 border border-amber-400/20 rounded-xl text-xs font-semibold text-amber-300 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>✨ Frais de préparation & nettoyage de base INCLUS dans le prix ✨</span>
                </div>

                {/* Delivery Packs Options */}
                <div className="pt-2 border-t border-slate-800/80 space-y-2">
                  <span className="text-[11px] font-bold text-slate-400 uppercase block">
                    Packs de livraison au choix (en supplément) :
                  </span>
                  
                  <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-white">Pack 1 — 150 €</div>
                      <div className="text-[11px] text-slate-400">Nettoyage complet pro + 20 litres carburant</div>
                    </div>
                    <span className="font-mono font-bold text-amber-400">+150 €</span>
                  </div>

                  <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-white">Pack 2 — Clés en main</div>
                      <div className="text-[11px] text-slate-400">Plein complet + démarches administratives + carte grise</div>
                    </div>
                    <span className="font-mono font-bold text-amber-400">250 € + CG</span>
                  </div>
                </div>

                {/* Policy Note */}
                <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-[11px] text-slate-400 italic">
                  Note : Aucune négociation par téléphone. Les échanges sur le prix se font uniquement sur place devant le véhicule.
                </div>

                {/* Call to action */}
                <button
                  onClick={() => onOpenReservation(vehicle)}
                  className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl transition-transform active:scale-98 cursor-pointer mt-2"
                >
                  <BookmarkCheck className="w-4 h-4" />
                  <span>Réserver ce véhicule maintenant</span>
                </button>
              </div>

              {/* Warranty Banner */}
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3">
                <ShieldCheck className="w-8 h-8 text-emerald-400 shrink-0" />
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>Garantie Commerciale Incluse ({warrantyMonths} mois)</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] bg-emerald-500/20 text-emerald-300 uppercase">
                      TBD AUTOS SÉCURITÉ
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-300 mt-0.5">
                    Couverture Moteur, Boîte et Pont avec assistance 24/7. Extension possible jusqu'à 24 mois.
                  </div>
                </div>
              </div>

            </div>

          </div>

          {/* Technical Specs 4-Box Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center gap-3">
              <Calendar className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <span className="text-[11px] text-slate-400 block">Année & MEC</span>
                <span className="text-sm font-bold text-white">{vehicle.year} ({vehicle.firstRegistrationDate || 'N/A'})</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center gap-3">
              <Gauge className="w-5 h-5 text-blue-400 shrink-0" />
              <div>
                <span className="text-[11px] text-slate-400 block">Kilométrage Garanti</span>
                <span className="text-sm font-bold text-white tabular-nums">{Number(vehicle.mileage).toLocaleString('fr-FR')} km</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center gap-3">
              <Cog className="w-5 h-5 text-purple-400 shrink-0" />
              <div>
                <span className="text-[11px] text-slate-400 block">Boîte de Vitesses</span>
                <span className="text-sm font-bold text-white capitalize">{vehicle.gearbox}</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center gap-3">
              <Zap className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <span className="text-[11px] text-slate-400 block">Puissance</span>
                <span className="text-sm font-bold text-white">{vehicle.powerDin} ch ({vehicle.powerFiscal} CV)</span>
              </div>
            </div>
          </div>

          {/* Points Forts & Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Left: 🌟 Les + du véhicule */}
            <div className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                🌟 Les + du Véhicule TBD AUTOS
              </h4>

              <div className="space-y-2">
                <div className="flex items-start gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Véhicule sélectionné, contrôlé et révisé dans nos ateliers partenaires.</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Kilométrage garanti certifié avec traçabilité administrative SIV & HistoVec.</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Garantie nationale {warrantyMonths} mois incluse, valable dans tout le réseau en France.</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Contrôle technique favorable de moins de 6 mois et certificat de non-gage vierge.</span>
                </div>
              </div>
            </div>

            {/* Right: Équipements & Options Clés */}
            <div className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                Équipements & Options Principaux
              </h4>

              {(vehicle.keyOptions && vehicle.keyOptions.length > 0) ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {vehicle.keyOptions.map((opt, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0"></span>
                      <span className="truncate">{opt}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-500 italic">
                  Équipements de série correspondant à la finition constructeur.
                </p>
              )}
            </div>

          </div>

          {/* Dossier de bord & Transparence */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 text-slate-300">
                <Key className={`w-4 h-4 ${vehicle.documents.doubleDesCles ? 'text-emerald-400' : 'text-slate-500'}`} />
                <span>{vehicle.documents.doubleDesCles ? 'Double des clés présent' : '1 clé disponible'}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <BookOpen className={`w-4 h-4 ${vehicle.documents.carnetEntretien ? 'text-emerald-400' : 'text-slate-500'}`} />
                <span>{vehicle.documents.carnetEntretien ? 'Carnet d\'entretien & factures' : 'Sans carnet'}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Certificat de situation administrative (Non-Gage) OK</span>
              </div>
            </div>

            <div className="text-slate-400 font-mono text-[11px]">
              VIN : <span className="text-white">{vehicle.vin}</span>
            </div>
          </div>

          {/* Bottom Toolbar for Staff */}
          <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {onOpenWindowSticker && (
                <button
                  onClick={() => onOpenWindowSticker(vehicle)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-400" />
                  <span>Affiche Vitrine A4</span>
                </button>
              )}

              {onOpenBrochure && (
                <button
                  onClick={() => onOpenBrochure(vehicle)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-blue-400" />
                  <span>Dossier PDF Client</span>
                </button>
              )}

              {onOpenEdit && (
                <button
                  onClick={() => onOpenEdit(vehicle)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5 text-purple-400" />
                  <span>Modifier la fiche</span>
                </button>
              )}
            </div>

            <button
              onClick={() => onOpenReservation(vehicle)}
              className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold rounded-xl text-xs flex items-center gap-2 shadow-lg cursor-pointer"
            >
              <BookmarkCheck className="w-4 h-4" />
              <span>Établir le Bon de Commande</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
