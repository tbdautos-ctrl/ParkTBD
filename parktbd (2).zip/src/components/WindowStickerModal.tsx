import React from 'react';
import { Vehicle } from '../types';
import { Printer, X, Shield, Sparkles, Phone, MapPin, QrCode, Fuel, Gauge, Calendar, Cog, Mail } from 'lucide-react';

interface WindowStickerModalProps {
  vehicle: Vehicle | null;
  onClose: () => void;
}

export const WindowStickerModal: React.FC<WindowStickerModalProps> = ({ vehicle, onClose }) => {
  if (!vehicle) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      {/* Container - Controls visible only on screen */}
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        
        {/* Modal Screen Action Header (hidden when printing) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div>
            <h2 className="text-lg font-bold text-white">Fiche Affiche Parc (Pare-brise A4)</h2>
            <p className="text-xs text-slate-400">
              Format d'affichage pour pare-brise de véhicule en exposition avec prix géant et options en valeur.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Imprimer l'Affiche (Format A4)
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Canvas (Previewed on screen, perfect on paper) */}
        <div className="p-8 bg-white text-slate-900 font-sans printable-window-sticker">
          
          {/* Top Dealership Brand Header */}
          <div className="flex items-center justify-between pb-6 border-b-2 border-slate-900">
            <div>
              <div className="text-3xl font-extrabold tracking-tight text-slate-950 uppercase">
                TBD AUTOS
              </div>
              <div className="text-xs font-semibold tracking-wider text-slate-600 uppercase mt-0.5">
                Négoce Automobile & Courtage Sélectionné · PARKTBD
              </div>
            </div>
            <div className="text-right text-xs text-slate-700">
              <div className="flex items-center justify-end gap-1 text-slate-900 font-mono font-semibold">
                <Mail className="w-3.5 h-3.5" /> tbdautos@gmail.com
              </div>
            </div>
          </div>

          {/* Main Title: Brand & Model */}
          <div className="mt-6">
            <div className="text-xs font-bold text-amber-700 uppercase tracking-widest">
              {vehicle.businessType === 'depot_vente' ? 'Dépôt-Vente Sélectionné' : 'Occasion Révisée & Garantie'}
            </div>
            <h1 className="text-4xl md:text-5xl font-black text-slate-950 tracking-tight leading-tight uppercase mt-1">
              {vehicle.brand} <span className="text-slate-800">{vehicle.model}</span>
            </h1>
            <p className="text-lg md:text-xl font-semibold text-slate-700 mt-1">
              {vehicle.version}
            </p>
          </div>

          {/* Technical Specs Strip */}
          <div className="grid grid-cols-4 gap-3 my-6 p-4 bg-slate-100 rounded-xl border border-slate-300 text-center">
            <div className="border-r border-slate-300 pr-2">
              <div className="flex items-center justify-center gap-1 text-slate-500 text-xs font-medium uppercase mb-0.5">
                <Calendar className="w-3.5 h-3.5" /> Année
              </div>
              <div className="text-2xl font-black text-slate-900 tabular-nums">
                {vehicle.year}
              </div>
            </div>
            <div className="border-r border-slate-300 pr-2">
              <div className="flex items-center justify-center gap-1 text-slate-500 text-xs font-medium uppercase mb-0.5">
                <Gauge className="w-3.5 h-3.5" /> Kilométrage
              </div>
              <div className="text-2xl font-black text-slate-900 tabular-nums">
                {Number(vehicle.mileage).toLocaleString('fr-FR')} <span className="text-sm font-semibold text-slate-600">km</span>
              </div>
            </div>
            <div className="border-r border-slate-300 pr-2">
              <div className="flex items-center justify-center gap-1 text-slate-500 text-xs font-medium uppercase mb-0.5">
                <Fuel className="w-3.5 h-3.5" /> Énergie
              </div>
              <div className="text-lg font-black text-slate-900 truncate">
                {vehicle.fuel}
              </div>
            </div>
            <div>
              <div className="flex items-center justify-center gap-1 text-slate-500 text-xs font-medium uppercase mb-0.5">
                <Cog className="w-3.5 h-3.5" /> Boîte
              </div>
              <div className="text-lg font-black text-slate-900 truncate">
                {vehicle.gearbox}
              </div>
            </div>
          </div>

          {/* Giant Price Box (Hero Windshield Element) */}
          <div className="p-6 bg-slate-950 text-white rounded-2xl text-center shadow-md my-4">
            <div className="text-xs font-semibold uppercase tracking-widest text-slate-400">
              Prix de vente TTC clés en main
            </div>
            <div className="text-5xl md:text-6xl font-black tracking-tight text-white my-1 tabular-nums">
              {Number(vehicle.sellingPrice).toLocaleString('fr-FR')} €
            </div>
            {vehicle.monthlyEstimate > 0 && (
              <div className="inline-block mt-1 px-4 py-1 bg-amber-400 text-slate-950 font-bold rounded-full text-sm">
                Ou dès {vehicle.monthlyEstimate} € / mois en financement sans apport
              </div>
            )}
          </div>

          {/* Key Options & Equipment List */}
          <div className="my-6">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">
              <Sparkles className="w-4 h-4 text-amber-600" />
              Équipements & Options Clés Inclus
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-2.5">
              {(vehicle.keyOptions || []).slice(0, 6).map((opt, i) => (
                <div key={i} className="flex items-start gap-2.5 text-sm font-semibold text-slate-800">
                  <span className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-xs font-bold mt-0.5">
                    ✓
                  </span>
                  <span>{opt}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Warranty & Guarantee Box */}
          <div className="p-4 bg-emerald-50 border-2 border-emerald-600 rounded-xl flex items-center justify-between my-4">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-emerald-700 flex-shrink-0" />
              <div>
                <div className="text-xs font-bold text-emerald-900 uppercase tracking-wide">
                  Tranquillité Totale
                </div>
                <div className="text-base font-extrabold text-emerald-950">
                  {vehicle.guarantee || 'Garantie 12 Mois Pièces et Main d’œuvre'}
                </div>
              </div>
            </div>
            <div className="text-right text-xs font-semibold text-emerald-800">
              Contrôlé 100 points · Révision à jour
            </div>
          </div>

          {/* Bottom QR Code & Lot Footnote */}
          <div className="mt-6 pt-4 border-t border-slate-300 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-slate-100 border border-slate-400 rounded-lg p-1 flex items-center justify-center">
                <QrCode className="w-12 h-12 text-slate-800" />
              </div>
              <div className="text-xs text-slate-600">
                <div className="font-bold text-slate-900">Scannez pour la fiche complète</div>
                <div>Photos HD, carnet d'entretien & calcul de financement</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Réf : {vehicle.registration} · VIN : {vehicle.vin}</div>
              </div>
            </div>
            <div className="text-right text-xs text-slate-600">
              <div className="font-bold text-slate-900">Emplacement Parc : {vehicle.location}</div>
              <div>Essai routier sur rendez-vous avec un conseiller</div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
