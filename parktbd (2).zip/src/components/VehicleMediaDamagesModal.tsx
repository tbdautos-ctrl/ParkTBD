import React, { useState } from 'react';
import { 
  Vehicle, 
  VehicleMediaItem, 
  VehicleDocumentFile, 
  VehicleDamageItem, 
  DocumentCategory,
  PhotoLocationTag 
} from '../types';
import { 
  X, 
  Camera, 
  Video, 
  Upload, 
  Trash2, 
  FileText, 
  AlertTriangle, 
  CheckCircle2, 
  Wrench, 
  Plus,
  DollarSign,
  ArrowLeft,
  ArrowRight,
  Star,
  Tag
} from 'lucide-react';

interface VehicleMediaDamagesModalProps {
  vehicle: Vehicle | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateVehicle: (vehicleId: string, updates: Partial<Vehicle>) => void;
}

export const VehicleMediaDamagesModal: React.FC<VehicleMediaDamagesModalProps> = ({
  vehicle,
  isOpen,
  onClose,
  onUpdateVehicle
}) => {
  const [activeTab, setActiveTab] = useState<'media' | 'docs' | 'damages'>('media');

  // Media
  const [mediaList, setMediaList] = useState<VehicleMediaItem[]>(
    vehicle?.mediaItems || vehicle?.images?.map((img, i) => ({
      id: `med-${i}`,
      type: 'photo' as const,
      url: img,
      title: i === 0 ? 'Photo principale' : `Photo #${i + 1}`,
      createdAt: new Date().toISOString()
    })) || []
  );
  const [mediaTitleInput, setMediaTitleInput] = useState('');

  // Documents
  const [docList, setDocList] = useState<VehicleDocumentFile[]>(
    vehicle?.documentFiles || vehicle?.documents?.files?.map(f => ({
      id: f.id,
      name: f.name,
      type: f.type,
      category: 'autre' as DocumentCategory,
      url: f.url || '#',
      uploadDate: f.uploadDate,
      size: f.size
    })) || []
  );
  const [selectedCategory, setSelectedCategory] = useState<DocumentCategory>('carte_grise');
  const [docNoteInput, setDocNoteInput] = useState('');

  // Damages
  const [damageList, setDamageList] = useState<VehicleDamageItem[]>(vehicle?.damages || []);
  const [dmgTitle, setDmgTitle] = useState('');
  const [dmgLocation, setDmgLocation] = useState('');
  const [dmgSeverity, setDmgSeverity] = useState<'mineur' | 'moyen' | 'important'>('mineur');
  const [dmgCost, setDmgCost] = useState<number>(0);
  const [dmgRepaired, setDmgRepaired] = useState(false);
  const [dmgMediaUrl, setDmgMediaUrl] = useState<string | null>(null);

  // Sync back to vehicle
  const syncChanges = (newMedia = mediaList, newDocs = docList, newDamages = damageList) => {
    if (!vehicle) return;
    const imagesArray = newMedia.filter(m => m.type === 'photo').map(m => m.url);
    if (imagesArray.length === 0 && vehicle.images?.length) {
      imagesArray.push(...vehicle.images);
    }

    onUpdateVehicle(vehicle.id, {
      mediaItems: newMedia,
      documentFiles: newDocs,
      damages: newDamages,
      images: imagesArray,
      documents: {
        ...vehicle.documents,
        files: newDocs.map(d => ({
          id: d.id,
          name: d.name,
          type: d.type,
          uploadDate: d.uploadDate,
          size: d.size,
          url: d.url
        }))
      }
    });
  };

  // Upload Media
  const handleUploadMedia = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach(file => {
      const isVideo = file.type.startsWith('video');
      const reader = new FileReader();
      reader.onload = () => {
        const newItem: VehicleMediaItem = {
          id: `med-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          type: isVideo ? 'video' : 'photo',
          url: reader.result as string,
          title: mediaTitleInput || file.name,
          createdAt: new Date().toISOString()
        };
        const updated = [newItem, ...mediaList];
        setMediaList(updated);
        syncChanges(updated, docList, damageList);
        setMediaTitleInput('');
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDeleteMedia = (id: string) => {
    const updated = mediaList.filter(m => m.id !== id);
    setMediaList(updated);
    syncChanges(updated, docList, damageList);
  };

  const handleMoveMedia = (idx: number, direction: 'left' | 'right') => {
    const targetIdx = direction === 'left' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= mediaList.length) return;
    const newMedia = [...mediaList];
    const [moved] = newMedia.splice(idx, 1);
    newMedia.splice(targetIdx, 0, moved);
    setMediaList(newMedia);
    syncChanges(newMedia, docList, damageList);
  };

  const handleSetPrimaryMedia = (idx: number) => {
    if (idx === 0) return;
    const newMedia = [...mediaList];
    const [moved] = newMedia.splice(idx, 1);
    newMedia.unshift(moved);
    setMediaList(newMedia);
    syncChanges(newMedia, docList, damageList);
  };

  const handleUpdateLocationTag = (id: string, locationTag: PhotoLocationTag) => {
    const updated = mediaList.map(m => m.id === id ? { ...m, locationTag } : m);
    setMediaList(updated);
    syncChanges(updated, docList, damageList);
  };

  // Upload Doc
  const handleUploadDoc = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = () => {
        const newDoc: VehicleDocumentFile = {
          id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          name: file.name,
          type: file.type || 'application/octet-stream',
          category: selectedCategory,
          url: reader.result as string,
          uploadDate: new Date().toISOString().slice(0, 10),
          size: `${(file.size / (1024 * 1024)).toFixed(2)} Mo`,
          notes: docNoteInput || undefined
        };
        const updated = [newDoc, ...docList];
        setDocList(updated);
        syncChanges(mediaList, updated, damageList);
        setDocNoteInput('');
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDeleteDoc = (id: string) => {
    const updated = docList.filter(d => d.id !== id);
    setDocList(updated);
    syncChanges(mediaList, updated, damageList);
  };

  // Damage handlers
  const handleDamagePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setDmgMediaUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAddDamage = () => {
    if (!dmgTitle.trim()) return;

    const newDmg: VehicleDamageItem = {
      id: `dmg-${Date.now()}`,
      title: dmgTitle.trim(),
      location: dmgLocation.trim() || 'Carrosserie',
      severity: dmgSeverity,
      estimatedRepairCost: Number(dmgCost) || 0,
      repaired: dmgRepaired,
      mediaUrl: dmgMediaUrl || undefined,
      mediaType: 'photo',
      createdAt: new Date().toISOString()
    };

    const updated = [newDmg, ...damageList];
    setDamageList(updated);
    syncChanges(mediaList, docList, updated);

    // Reset
    setDmgTitle('');
    setDmgLocation('');
    setDmgCost(0);
    setDmgRepaired(false);
    setDmgMediaUrl(null);
  };

  const handleDeleteDamage = (id: string) => {
    const updated = damageList.filter(d => d.id !== id);
    setDamageList(updated);
    syncChanges(mediaList, docList, updated);
  };

  const handleToggleRepaired = (id: string) => {
    const updated = damageList.map(d => d.id === id ? { ...d, repaired: !d.repaired } : d);
    setDamageList(updated);
    syncChanges(mediaList, docList, updated);
  };

  if (!isOpen || !vehicle) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-4 sm:my-6 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70 shrink-0">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span>Médias, Documents & Dommages</span>
              <span className="text-amber-400 font-mono text-xs">({vehicle.registration})</span>
            </h2>
            <p className="text-xs text-slate-400">
              {vehicle.brand} {vehicle.model} ({vehicle.version}) · Modifiez, ajoutez ou supprimez vos fichiers en direct.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-800 bg-slate-950/40 shrink-0 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('media')}
            className={`px-4 py-2 font-semibold rounded-t-lg transition-colors border-b-2 cursor-pointer flex items-center gap-2 ${
              activeTab === 'media' ? 'border-amber-400 text-amber-400 bg-slate-800/50' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>Photos & Vidéos ({mediaList.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('docs')}
            className={`px-4 py-2 font-semibold rounded-t-lg transition-colors border-b-2 cursor-pointer flex items-center gap-2 ${
              activeTab === 'docs' ? 'border-amber-400 text-amber-400 bg-slate-800/50' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Documents Scannés ({docList.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('damages')}
            className={`px-4 py-2 font-semibold rounded-t-lg transition-colors border-b-2 cursor-pointer flex items-center gap-2 ${
              activeTab === 'damages' ? 'border-amber-400 text-amber-400 bg-slate-800/50' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Dommages & Défauts ({damageList.length})</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* TAB 1: MEDIA */}
          {activeTab === 'media' && (
            <div className="space-y-6">
              
              {/* Upload Action Strip */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3">
                <input
                  type="text"
                  value={mediaTitleInput}
                  onChange={(e) => setMediaTitleInput(e.target.value)}
                  placeholder="Légende (ex: Intérieur cuir, Profil droit...)"
                  className="w-full sm:flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                />

                <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg cursor-pointer shrink-0 shadow">
                  <Upload className="w-4 h-4" />
                  <span>Importer Photos / Vidéos</span>
                  <input
                    type="file"
                    accept="image/*,video/*"
                    multiple
                    onChange={handleUploadMedia}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Media Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {mediaList.map((item, idx) => (
                  <div
                    key={item.id}
                    className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col group hover:border-slate-700 transition-colors"
                  >
                    <div className="aspect-16/9 bg-slate-900 relative">
                      {item.type === 'video' ? (
                        <video src={item.url} controls className="w-full h-full object-cover" />
                      ) : (
                        <img src={item.url} alt={item.title || 'Photo'} className="w-full h-full object-cover" />
                      )}

                      {/* Position & Primary Badge */}
                      <div className="absolute top-2 left-2 flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          idx === 0 
                            ? 'bg-amber-400 text-slate-950 shadow-sm' 
                            : 'bg-slate-950/80 text-white'
                        }`}>
                          {idx === 0 ? '★ Couverture #1' : `#${idx + 1}`}
                        </span>

                        {item.locationTag && (
                          <span className="bg-slate-900/90 text-slate-300 border border-slate-700/80 px-1.5 py-0.5 rounded text-[9px] font-medium">
                            {item.locationTag === 'avant_3_4' ? 'Avant 3/4' :
                             item.locationTag === 'arriere_3_4' ? 'Arrière 3/4' :
                             item.locationTag === 'profil' ? 'Profil' :
                             item.locationTag === 'interieur_poste' ? 'Poste de conduite' :
                             item.locationTag === 'sieges' ? 'Sièges' :
                             item.locationTag === 'compteur' ? 'Compteur' :
                             item.locationTag === 'moteur' ? 'Moteur' :
                             item.locationTag === 'coffre' ? 'Coffre' :
                             item.locationTag === 'jantes' ? 'Jantes' : 'Détail'}
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => handleDeleteMedia(item.id)}
                        className="absolute top-2 right-2 p-1.5 bg-rose-600/90 hover:bg-rose-600 text-white rounded-lg cursor-pointer transition-colors shadow"
                        title="Supprimer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                      {/* Reordering bar at bottom of image */}
                      <div className="absolute bottom-2 inset-x-2 flex items-center justify-between gap-1.5 bg-slate-950/85 backdrop-blur-sm p-1 rounded-lg border border-slate-800 text-slate-300">
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => handleMoveMedia(idx, 'left')}
                            className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                              idx === 0 ? 'text-slate-600 cursor-not-allowed' : 'hover:bg-slate-800 text-white hover:text-amber-400'
                            }`}
                            title="Déplacer vers la gauche (position précédente)"
                          >
                            <ArrowLeft className="w-3.5 h-3.5" />
                          </button>
                          <span className="text-[10px] font-mono text-slate-400 font-bold">
                            {idx + 1}/{mediaList.length}
                          </span>
                          <button
                            type="button"
                            disabled={idx === mediaList.length - 1}
                            onClick={() => handleMoveMedia(idx, 'right')}
                            className={`p-1 rounded text-xs transition-colors cursor-pointer ${
                              idx === mediaList.length - 1 ? 'text-slate-600 cursor-not-allowed' : 'hover:bg-slate-800 text-white hover:text-amber-400'
                            }`}
                            title="Déplacer vers la droite (position suivante)"
                          >
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {idx !== 0 && (
                          <button
                            type="button"
                            onClick={() => handleSetPrimaryMedia(idx)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold text-amber-300 hover:text-amber-200 bg-amber-400/15 hover:bg-amber-400/25 rounded cursor-pointer transition-colors"
                            title="Mettre en 1ère position (Photo principale de couverture)"
                          >
                            <Star className="w-3 h-3 text-amber-400" />
                            <span>Mettre en #1</span>
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="p-3 space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-xs font-semibold text-white truncate flex-1">{item.title || `Photo ${idx + 1}`}</div>
                        <span className="text-[10px] text-slate-500 shrink-0">
                          {new Date(item.createdAt).toLocaleDateString('fr-FR')}
                        </span>
                      </div>

                      {/* Location / Angle on Vehicle Selector */}
                      <div>
                        <label className="block text-[10px] font-medium text-slate-400 mb-1 flex items-center gap-1">
                          <Tag className="w-3 h-3 text-amber-400" /> Emplacement / Angle du véhicule
                        </label>
                        <select
                          value={item.locationTag || 'avant_3_4'}
                          onChange={(e) => handleUpdateLocationTag(item.id, e.target.value as PhotoLocationTag)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-slate-200 focus:outline-none focus:ring-1 focus:ring-amber-400"
                        >
                          <option value="avant_3_4">Avant 3/4 (Vue principale)</option>
                          <option value="arriere_3_4">Arrière 3/4</option>
                          <option value="profil">Profil latéral</option>
                          <option value="interieur_poste">Poste de conduite / Tableau de bord</option>
                          <option value="sieges">Sellerie & Sièges avant/arrière</option>
                          <option value="compteur">Compteur & Tableau de bord</option>
                          <option value="moteur">Compartiment Moteur</option>
                          <option value="coffre">Coffre à bagages</option>
                          <option value="jantes">Jantes & Pneumatiques</option>
                          <option value="autre">Autre détail carrosserie</option>
                        </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: DOCUMENTS */}
          {activeTab === 'docs' && (
            <div className="space-y-6">
              
              {/* Doc Upload */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Type de document</label>
                    <select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value as DocumentCategory)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="carte_grise">Carte Grise</option>
                      <option value="mandat">Mandat de vente (Dépôt-vente)</option>
                      <option value="non_gage">Certificat Non-Gage</option>
                      <option value="ct">Contrôle Technique</option>
                      <option value="cession">Certificat de Cession</option>
                      <option value="facture">Facture d'achat / entretien</option>
                      <option value="autre">Autre document</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Précision / Note</label>
                    <input
                      type="text"
                      value={docNoteInput}
                      onChange={(e) => setDocNoteInput(e.target.value)}
                      placeholder="ex: Mandat signé, PV de contrôle vierge..."
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg cursor-pointer shadow">
                    <Upload className="w-4 h-4" />
                    <span>Sélectionner & Uploader le Scan (PDF / Image)</span>
                    <input
                      type="file"
                      accept=".pdf,image/*"
                      multiple
                      onChange={handleUploadDoc}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Doc List */}
              <div className="space-y-2">
                {docList.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-amber-400 shrink-0" />
                      <div>
                        <div className="font-bold text-white flex items-center gap-2">
                          {doc.name}
                          <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded text-slate-300 uppercase">
                            {doc.category}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {doc.uploadDate} · {doc.size} {doc.notes ? `· ${doc.notes}` : ''}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {doc.url && doc.url !== '#' && (
                        <a
                          href={doc.url}
                          download={doc.name}
                          target="_blank"
                          rel="noreferrer"
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs cursor-pointer"
                        >
                          Télécharger / Visualiser
                        </a>
                      )}
                      <button
                        onClick={() => handleDeleteDoc(doc.id)}
                        className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* TAB 3: DAMAGES */}
          {activeTab === 'damages' && (
            <div className="space-y-6">
              
              {/* Add Damage Form */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Défaut / Dommage *</label>
                    <input
                      type="text"
                      value={dmgTitle}
                      onChange={(e) => setDmgTitle(e.target.value)}
                      placeholder="ex: Rayure aile arrière gauche"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Emplacement</label>
                    <input
                      type="text"
                      value={dmgLocation}
                      onChange={(e) => setDmgLocation(e.target.value)}
                      placeholder="ex: Aile ARG, Jante AVD..."
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Gravité</label>
                    <select
                      value={dmgSeverity}
                      onChange={(e) => setDmgSeverity(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="mineur">Mineur</option>
                      <option value="moyen">Moyen</option>
                      <option value="important">Important</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Coût estimé réparation (€)</label>
                    <input
                      type="number"
                      value={dmgCost}
                      onChange={(e) => setDmgCost(Number(e.target.value))}
                      placeholder="0"
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="flex items-center gap-2 px-3 py-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg text-xs text-slate-300 cursor-pointer">
                      <Camera className="w-3.5 h-3.5 text-amber-400" />
                      <span className="truncate">{dmgMediaUrl ? 'Photo jointe ✓' : 'Prendre/Joindre photo'}</span>
                      <input
                        type="file"
                        accept="image/*,video/*"
                        onChange={handleDamagePhotoUpload}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={dmgRepaired}
                        onChange={(e) => setDmgRepaired(e.target.checked)}
                        className="w-4 h-4 rounded text-amber-500"
                      />
                      Déjà réparé
                    </label>

                    <button
                      type="button"
                      onClick={handleAddDamage}
                      className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-lg cursor-pointer"
                    >
                      + Ajouter
                    </button>
                  </div>
                </div>
              </div>

              {/* Damage List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {damageList.map((dmg) => (
                  <div
                    key={dmg.id}
                    className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-start justify-between gap-3"
                  >
                    {dmg.mediaUrl && (
                      <div className="w-14 h-14 rounded-lg overflow-hidden bg-slate-900 shrink-0 border border-slate-800">
                        <img src={dmg.mediaUrl} alt={dmg.title} className="w-full h-full object-cover" />
                      </div>
                    )}

                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{dmg.title}</span>
                        <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded text-slate-300 uppercase">
                          {dmg.severity}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">Emplacement : {dmg.location}</div>
                      <div className="flex items-center gap-2 text-xs pt-1">
                        <span className="font-bold text-amber-400 tabular-nums">
                          {dmg.estimatedRepairCost > 0 ? `${dmg.estimatedRepairCost} €` : 'Non chiffré'}
                        </span>
                        <button
                          onClick={() => handleToggleRepaired(dmg.id)}
                          className={`text-[10px] px-2 py-0.5 rounded cursor-pointer ${
                            dmg.repaired ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {dmg.repaired ? '✓ Réparé' : 'À réparer'}
                        </button>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteDamage(dmg.id)}
                      className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-950/70 shrink-0">
          <span className="text-xs text-slate-500">
            Modifications enregistrées automatiquement en direct sur le véhicule
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg cursor-pointer"
          >
            Fermer
          </button>
        </div>

      </div>
    </div>
  );
};
