import React, { useState, useEffect, useCallback } from 'react';
import { 
  Vehicle, 
  Appointment, 
  UserAccount, 
  FinancialStats,
  VehicleStatus,
  BusinessType,
  SentEmailRecord,
  EmailDocType,
  Seller,
  ReservationBuyerInfo,
  SalesMandateInfo
} from './types';
import { api } from './services/api';
import { Navbar, NavTab } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { StockView } from './components/StockView';
import { AppointmentsView } from './components/AppointmentsView';
import { DocumentsView } from './components/DocumentsView';
import { SellersView } from './components/SellersView';
import { MarginsView } from './components/MarginsView';
import { UsersView } from './components/UsersView';
import { VehicleModal } from './components/VehicleModal';
import { VehicleShowModal } from './components/VehicleShowModal';
import { ReservationModal } from './components/ReservationModal';
import { OrderFormModal } from './components/OrderFormModal';
import { SalesMandateModal } from './components/SalesMandateModal';
import { WindowStickerModal } from './components/WindowStickerModal';
import { ClientBrochureModal } from './components/ClientBrochureModal';
import { AiAdGeneratorModal } from './components/AiAdGeneratorModal';
import { AppointmentModal } from './components/AppointmentModal';
import { VehicleMediaDamagesModal } from './components/VehicleMediaDamagesModal';
import { SendDocumentEmailModal } from './components/SendDocumentEmailModal';
import { VehicleDetailSheetModal } from './components/VehicleDetailSheetModal';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [emails, setEmails] = useState<SentEmailRecord[]>([]);
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncConnected, setSyncConnected] = useState<boolean>(false);

  // Active Current User (Daniel Balogun by default)
  const [currentUser, setCurrentUser] = useState({
    name: 'Daniel Balogun',
    role: 'admin',
    email: 'danielbalogun01@gmail.com'
  });

  // Modals state
  const [vehicleModalOpen, setVehicleModalOpen] = useState(false);
  const [selectedVehicleForEdit, setSelectedVehicleForEdit] = useState<Vehicle | null>(null);

  const [windowStickerVehicle, setWindowStickerVehicle] = useState<Vehicle | null>(null);
  const [brochureVehicle, setBrochureVehicle] = useState<Vehicle | null>(null);
  const [aiAdVehicle, setAiAdVehicle] = useState<Vehicle | null>(null);
  const [mediaDamagesVehicle, setMediaDamagesVehicle] = useState<Vehicle | null>(null);

  // Vehicle Presentation Mode & Show Modal state
  const [showVehicle, setShowVehicle] = useState<Vehicle | null>(null);
  const [detailSheetVehicle, setDetailSheetVehicle] = useState<Vehicle | null>(null);

  // Reservation & Bon de Commande states
  const [reservationVehicle, setReservationVehicle] = useState<Vehicle | null>(null);
  const [orderFormVehicle, setOrderFormVehicle] = useState<Vehicle | null>(null);

  // Sales Mandate state (Dépôt-vente)
  const [salesMandateVehicle, setSalesMandateVehicle] = useState<Vehicle | null>(null);

  const [appointmentModalOpen, setAppointmentModalOpen] = useState(false);
  const [selectedAppointmentForEdit, setSelectedAppointmentForEdit] = useState<Appointment | null>(null);

  // Email Document Modal state (TBD AUTOS)
  const [sendEmailModalOpen, setSendEmailModalOpen] = useState(false);
  const [selectedVehicleForEmail, setSelectedVehicleForEmail] = useState<Vehicle | null>(null);
  const [initialDocTypeForEmail, setInitialDocTypeForEmail] = useState<EmailDocType>('facture_achat');

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Fetch all data
  const fetchData = useCallback(async () => {
    setIsSyncing(true);
    try {
      const [carsData, aptsData, usersData, emailsData, sellersData] = await Promise.all([
        api.getCars(),
        api.getAppointments(),
        api.getUsers(),
        api.getEmails(),
        api.getSellers()
      ]);

      setVehicles(carsData);
      setAppointments(aptsData);
      setUsers(usersData);
      setEmails(emailsData);
      setSellers(sellersData);

      // Save to localStorage as backup
      localStorage.setItem('parktbd_cars', JSON.stringify(carsData));
      localStorage.setItem('parktbd_appointments', JSON.stringify(aptsData));
      localStorage.setItem('parktbd_users', JSON.stringify(usersData));
      localStorage.setItem('parktbd_emails', JSON.stringify(emailsData));
      localStorage.setItem('parktbd_sellers', JSON.stringify(sellersData));
    } catch (err) {
      console.error('Erreur chargement données', err);
    } finally {
      setIsLoading(false);
      setIsSyncing(false);
    }
  }, []);

  // Initial load & SSE real-time sync subscription
  useEffect(() => {
    fetchData();

    // Server-Sent Events setup for real-time live synchronization across devices
    let eventSource: EventSource | null = null;
    try {
      eventSource = new EventSource('/api/sync/events');

      eventSource.addEventListener('connected', () => {
        setSyncConnected(true);
      });

      eventSource.addEventListener('vehicle_created', (e) => {
        const newVehicle: Vehicle = JSON.parse(e.data);
        setVehicles(prev => [newVehicle, ...prev.filter(v => v.id !== newVehicle.id)]);
        showToast(`Nouveau véhicule synchronisé : ${newVehicle.brand} ${newVehicle.model}`);
      });

      eventSource.addEventListener('vehicle_updated', (e) => {
        const updatedVehicle: Vehicle = JSON.parse(e.data);
        setVehicles(prev => prev.map(v => v.id === updatedVehicle.id ? updatedVehicle : v));
      });

      eventSource.addEventListener('vehicle_deleted', (e) => {
        const { id } = JSON.parse(e.data);
        setVehicles(prev => prev.filter(v => v.id !== id));
      });

      eventSource.addEventListener('seller_created', (e) => {
        const newSeller: Seller = JSON.parse(e.data);
        setSellers(prev => [newSeller, ...prev.filter(s => s.id !== newSeller.id)]);
        showToast(`Nouveau vendeur synchronisé : ${newSeller.name}`);
      });

      eventSource.addEventListener('seller_updated', (e) => {
        const updatedSeller: Seller = JSON.parse(e.data);
        setSellers(prev => prev.map(s => s.id === updatedSeller.id ? updatedSeller : s));
      });

      eventSource.addEventListener('seller_deleted', (e) => {
        const { id } = JSON.parse(e.data);
        setSellers(prev => prev.filter(s => s.id !== id));
      });

      eventSource.addEventListener('appointment_created', (e) => {
        const newApt: Appointment = JSON.parse(e.data);
        setAppointments(prev => [newApt, ...prev.filter(a => a.id !== newApt.id)]);
        showToast(`Nouveau rendez-vous client synchronisé : ${newApt.clientName}`);
      });

      eventSource.addEventListener('appointment_updated', (e) => {
        const updatedApt: Appointment = JSON.parse(e.data);
        setAppointments(prev => prev.map(a => a.id === updatedApt.id ? updatedApt : a));
      });

      eventSource.addEventListener('appointment_deleted', (e) => {
        const { id } = JSON.parse(e.data);
        setAppointments(prev => prev.filter(a => a.id !== id));
      });

      eventSource.addEventListener('email_sent', (e) => {
        const newEmail: SentEmailRecord = JSON.parse(e.data);
        setEmails(prev => [newEmail, ...prev.filter(item => item.id !== newEmail.id)]);
        showToast(`E-mail transmis depuis TBD AUTOS à ${newEmail.recipientName}`);
      });

      eventSource.addEventListener('email_deleted', (e) => {
        const { id } = JSON.parse(e.data);
        setEmails(prev => prev.filter(item => item.id !== id));
      });

      eventSource.addEventListener('database_reset', () => {
        fetchData();
        showToast('Base de données synchronisée');
      });

      eventSource.onerror = () => {
        setSyncConnected(false);
      };
    } catch (err) {
      console.warn('SSE non supporté ou indisponible, mode polling activé', err);
    }

    return () => {
      if (eventSource) {
        eventSource.close();
      }
    };
  }, [fetchData]);

  // Financial Stats Calculation
  const stats: FinancialStats = React.useMemo(() => {
    const totalCarsInStock = vehicles.filter(v => v.status !== 'vendu' && v.status !== 'livre').length;
    
    const activeVehicles = vehicles.filter(v => v.status !== 'vendu' && v.status !== 'livre');
    
    const totalStockValueTTC = activeVehicles.reduce((acc, v) => acc + (Number(v.sellingPrice) || 0), 0);
    
    const totalCostInvested = activeVehicles.reduce((acc, v) => {
      const c = v.costs;
      const vehicleCost = (c.purchasePrice || 0) + (c.transport || 0) + (c.reconditioning || 0) + 
                          (c.detailing || 0) + (c.inspection || 0) + (c.adminFees || 0) + (c.warrantyCost || 0);
      return acc + vehicleCost;
    }, 0);

    const potentialGrossMargin = totalStockValueTTC - totalCostInvested;
    const potentialNetMargin = Math.round(potentialGrossMargin * 0.92); // estimation après frais de structure légers
    const averageMarginPercentage = totalCostInvested > 0 ? (potentialGrossMargin / totalCostInvested) * 100 : 0;

    const soldVehicles = vehicles.filter(v => v.status === 'vendu');
    const realizedMarginMonth = soldVehicles.reduce((acc, v) => {
      const c = v.costs;
      const totalCost = (c.purchasePrice || 0) + (c.transport || 0) + (c.reconditioning || 0) + 
                        (c.detailing || 0) + (c.inspection || 0) + (c.adminFees || 0) + (c.warrantyCost || 0);
      return acc + ((v.soldPrice || v.sellingPrice) - totalCost);
    }, 0);

    const statusBreakdown: Record<VehicleStatus, number> = {
      en_arrivage: 0,
      en_preparation: 0,
      en_stock: 0,
      reserve: 0,
      vendu: 0,
      livre: 0
    };
    vehicles.forEach(v => {
      if (statusBreakdown[v.status] !== undefined) {
        statusBreakdown[v.status]++;
      }
    });

    const businessTypeBreakdown: Record<BusinessType, number> = {
      achat_revente: vehicles.filter(v => v.businessType === 'achat_revente').length,
      depot_vente: vehicles.filter(v => v.businessType === 'depot_vente').length
    };

    return {
      totalCarsInStock,
      totalStockValueTTC,
      totalCostInvested,
      potentialGrossMargin,
      potentialNetMargin,
      averageMarginPercentage,
      averageStockDays: 32, // Rotation moyenne du parc
      carsSoldMonth: soldVehicles.length,
      realizedMarginMonth,
      statusBreakdown,
      businessTypeBreakdown
    };
  }, [vehicles]);

  // Vehicle handlers
  const handleSaveVehicle = async (vehicleData: Partial<Vehicle>) => {
    try {
      if (selectedVehicleForEdit) {
        const updated = await api.updateCar(selectedVehicleForEdit.id, vehicleData);
        setVehicles(prev => prev.map(v => v.id === updated.id ? updated : v));
        showToast(`Véhicule mis à jour : ${updated.brand} ${updated.model}`);
      } else {
        const created = await api.createCar(vehicleData);
        setVehicles(prev => [created, ...prev]);
        showToast(`Véhicule ajouté au stock : ${created.brand} ${created.model}`);
      }
      setVehicleModalOpen(false);
      setSelectedVehicleForEdit(null);
    } catch (err) {
      console.error('Erreur sauvegarde véhicule', err);
      showToast('Erreur lors de la sauvegarde du véhicule');
    }
  };

  const handleDeleteVehicle = async (id: string) => {
    try {
      await api.deleteCar(id);
      setVehicles(prev => prev.filter(v => v.id !== id));
      showToast('Véhicule retiré du stock');
    } catch (err) {
      console.error('Erreur suppression véhicule', err);
    }
  };

  const handleUpdateVehicleDocuments = async (vehicleId: string, docs: any) => {
    try {
      const updated = await api.updateCar(vehicleId, { documents: docs });
      setVehicles(prev => prev.map(v => v.id === updated.id ? updated : v));
      showToast('Documents administratifs mis à jour');
    } catch (err) {
      console.error('Erreur mise à jour documents', err);
    }
  };

  const handleQuickUpdateVehicle = async (vehicleId: string, updates: Partial<Vehicle>) => {
    try {
      const updated = await api.updateCar(vehicleId, updates);
      setVehicles(prev => prev.map(v => v.id === vehicleId ? updated : v));
      if (mediaDamagesVehicle?.id === vehicleId) {
        setMediaDamagesVehicle(updated);
      }
      if (showVehicle?.id === vehicleId) {
        setShowVehicle(updated);
      }
      showToast('Véhicule mis à jour avec succès');
    } catch (err) {
      console.error('Erreur mise à jour véhicule', err);
    }
  };

  const handleConfirmReservation = async (vehicleId: string, reservation: ReservationBuyerInfo) => {
    try {
      const updated = await api.updateCar(vehicleId, {
        reservation,
        status: 'reserve',
        buyerName: reservation.name,
        buyerPhone: reservation.phone
      });
      setVehicles(prev => prev.map(v => v.id === vehicleId ? updated : v));
      setReservationVehicle(null);
      setOrderFormVehicle(updated);
      showToast(`Véhicule réservé avec succès ! Bon de commande généré pour ${reservation.name}`);
    } catch (err: any) {
      console.error('Erreur réservation', err);
      showToast(`Erreur : ${err.message || 'Impossible d\'enregistrer la réservation'}`);
    }
  };

  const handleSaveSalesMandate = async (vehicleId: string, mandate: SalesMandateInfo) => {
    try {
      const car = vehicles.find(v => v.id === vehicleId);
      const updatedDocs = car ? { ...car.documents, mandatVente: 'complet' as const } : undefined;
      const updated = await api.updateCar(vehicleId, {
        salesMandate: mandate,
        ...(updatedDocs ? { documents: updatedDocs } : {})
      });
      setVehicles(prev => prev.map(v => v.id === vehicleId ? updated : v));
      if (salesMandateVehicle?.id === vehicleId) {
        setSalesMandateVehicle(updated);
      }
      showToast('Mandat de vente enregistré et prêt pour signature !');
    } catch (err: any) {
      console.error('Erreur mandat', err);
      showToast(`Erreur : ${err.message || 'Impossible d\'enregistrer le mandat'}`);
    }
  };

  // Appointment handlers
  const handleSaveAppointment = async (aptData: Partial<Appointment>) => {
    try {
      if (selectedAppointmentForEdit) {
        const updated = await api.updateAppointment(selectedAppointmentForEdit.id, aptData);
        setAppointments(prev => prev.map(a => a.id === updated.id ? updated : a));
        showToast(`Rendez-vous mis à jour pour ${updated.clientName}`);
      } else {
        const created = await api.createAppointment(aptData);
        setAppointments(prev => [created, ...prev]);
        showToast(`Rendez-vous planifié pour ${created.clientName}`);
      }
      setAppointmentModalOpen(false);
      setSelectedAppointmentForEdit(null);
    } catch (err) {
      console.error('Erreur rendez-vous', err);
    }
  };

  const handleUpdateAppointmentStatus = async (id: string, status: any) => {
    try {
      const updated = await api.updateAppointment(id, { status });
      setAppointments(prev => prev.map(a => a.id === updated.id ? updated : a));
      showToast(`Statut du rendez-vous actualisé`);
    } catch (err) {
      console.error('Erreur maj statut rendez-vous', err);
    }
  };

  const handleDeleteAppointment = async (id: string) => {
    try {
      await api.deleteAppointment(id);
      setAppointments(prev => prev.filter(a => a.id !== id));
      showToast('Rendez-vous supprimé');
    } catch (err) {
      console.error('Erreur suppression rendez-vous', err);
    }
  };

  // User handlers
  const handleAddUser = async (userData: Partial<UserAccount>) => {
    try {
      const created = await api.createUser(userData);
      setUsers(prev => [...prev, created]);
      showToast(`Collaborateur ajouté : ${created.name}`);
    } catch (err) {
      console.error('Erreur ajout utilisateur', err);
    }
  };

  const handleUpdateUser = async (id: string, userData: Partial<UserAccount>) => {
    try {
      const updated = await api.updateUser(id, userData);
      setUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
      showToast(`Profil mis à jour : ${updated.name}`);
    } catch (err) {
      console.error('Erreur maj utilisateur', err);
    }
  };

  const handleDeleteUser = async (id: string) => {
    try {
      await api.deleteUser(id);
      setUsers(prev => prev.filter(u => u.id !== id));
      showToast('Collaborateur supprimé');
    } catch (err) {
      console.error('Erreur suppression utilisateur', err);
    }
  };

  // Email Document Handlers (TBD AUTOS - tbdautos@gmail.com)
  const handleOpenSendEmail = (vehicle?: Vehicle | null, docType: EmailDocType = 'facture_achat') => {
    setSelectedVehicleForEmail(vehicle || null);
    setInitialDocTypeForEmail(docType);
    setSendEmailModalOpen(true);
  };

  const handleSendEmail = async (emailData: Partial<SentEmailRecord>) => {
    try {
      const created = await api.sendEmail(emailData);
      setEmails(prev => [created, ...prev.filter(e => e.id !== created.id)]);
      showToast(`Document transmis avec succès depuis tbdautos@gmail.com !`);
    } catch (err: any) {
      console.error('Erreur envoi email', err);
      showToast(`Erreur d'envoi : ${err.message || 'vérifiez la connexion'}`);
      throw err;
    }
  };

  const handleDeleteEmail = async (id: string) => {
    try {
      await api.deleteEmail(id);
      setEmails(prev => prev.filter(e => e.id !== id));
      showToast('Entrée du journal supprimée');
    } catch (err) {
      console.error('Erreur suppression email', err);
    }
  };

  // Sellers Handlers (Dépôt-vente)
  const handleAddSeller = async (sellerData: Partial<Seller>) => {
    try {
      const created = await api.createSeller(sellerData);
      setSellers(prev => [created, ...prev.filter(s => s.id !== created.id)]);
      showToast(`Vendeur ${created.name} enregistré avec succès`);
      return created;
    } catch (err: any) {
      console.error('Erreur création vendeur', err);
      showToast(`Erreur : ${err.message || 'Impossible d\'enregistrer le vendeur'}`);
    }
  };

  const handleUpdateSeller = async (id: string, sellerData: Partial<Seller>) => {
    try {
      const updated = await api.updateSeller(id, sellerData);
      setSellers(prev => prev.map(s => s.id === id ? updated : s));
      showToast(`Fiche vendeur ${updated.name} mise à jour`);
      return updated;
    } catch (err: any) {
      console.error('Erreur mise à jour vendeur', err);
      showToast(`Erreur : ${err.message || 'Impossible de mettre à jour le vendeur'}`);
    }
  };

  const handleDeleteSeller = async (id: string) => {
    try {
      await api.deleteSeller(id);
      setSellers(prev => prev.filter(s => s.id !== id));
      showToast('Fiche vendeur supprimée');
      return true;
    } catch (err: any) {
      console.error('Erreur suppression vendeur', err);
      showToast('Impossible de supprimer le vendeur');
      return false;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Toast Notification Container */}
      {toastMessage && (
        <div className="toast-container fixed bottom-6 right-6 z-50 px-4 py-2.5 bg-slate-900 border border-amber-500/40 text-amber-300 text-xs font-semibold rounded-xl shadow-2xl flex items-center gap-2 animate-bounce">
          <span className="w-2 h-2 rounded-full bg-amber-400"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Bar Navigation */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenNewVehicle={() => {
          setSelectedVehicleForEdit(null);
          setVehicleModalOpen(true);
        }}
        onOpenSendEmail={() => handleOpenSendEmail(null, 'facture_achat')}
        syncConnected={syncConnected}
        currentUser={currentUser}
        onRefreshData={fetchData}
        isSyncing={isSyncing}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {isLoading ? (
          <div className="py-24 text-center space-y-3">
            <div className="w-8 h-8 border-2 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto"></div>
            <div className="text-xs text-slate-400 font-medium">Chargement du parc automobile ParkTBD...</div>
          </div>
        ) : (
          <>
            {currentTab === 'dashboard' && (
              <DashboardView
                vehicles={vehicles}
                appointments={appointments}
                stats={stats}
                onOpenVehicle={(v) => {
                  setShowVehicle(v);
                }}
                onOpenWindowSticker={setWindowStickerVehicle}
                onOpenBrochure={setBrochureVehicle}
                onOpenAiAd={setAiAdVehicle}
                onNavigateToStock={() => setCurrentTab('stock')}
                onNavigateToAppointments={() => setCurrentTab('appointments')}
                onNavigateToDocuments={() => setCurrentTab('documents')}
                onCompleteAppointment={(apt) => handleUpdateAppointmentStatus(apt.id, 'effectue')}
              />
            )}

            {currentTab === 'stock' && (
              <StockView
                vehicles={vehicles}
                onOpenVehicleModal={(v) => {
                  setSelectedVehicleForEdit(v || null);
                  setVehicleModalOpen(true);
                }}
                onOpenVehicleShow={setShowVehicle}
                onOpenVehicleDetail={setDetailSheetVehicle}
                onOpenReservation={setReservationVehicle}
                onOpenSalesMandate={setSalesMandateVehicle}
                onOpenWindowSticker={setWindowStickerVehicle}
                onOpenBrochure={setBrochureVehicle}
                onOpenAiAd={setAiAdVehicle}
                onOpenMediaDamages={setMediaDamagesVehicle}
                onOpenSendEmail={handleOpenSendEmail}
                onDeleteVehicle={handleDeleteVehicle}
              />
            )}

            {currentTab === 'appointments' && (
              <AppointmentsView
                appointments={appointments}
                vehicles={vehicles}
                onOpenAppointmentModal={(apt) => {
                  setSelectedAppointmentForEdit(apt || null);
                  setAppointmentModalOpen(true);
                }}
                onUpdateAppointmentStatus={handleUpdateAppointmentStatus}
                onDeleteAppointment={handleDeleteAppointment}
              />
            )}

            {currentTab === 'documents' && (
              <DocumentsView
                vehicles={vehicles}
                onUpdateVehicleDocuments={handleUpdateVehicleDocuments}
                onUpdateVehicle={handleQuickUpdateVehicle}
                onOpenVehicleModal={(v) => {
                  setSelectedVehicleForEdit(v);
                  setVehicleModalOpen(true);
                }}
                onOpenSalesMandate={setSalesMandateVehicle}
                onOpenSendEmail={handleOpenSendEmail}
              />
            )}

            {currentTab === 'sellers' && (
              <SellersView
                sellers={sellers}
                vehicles={vehicles}
                onAddSeller={handleAddSeller}
                onUpdateSeller={handleUpdateSeller}
                onDeleteSeller={handleDeleteSeller}
                onOpenVehicleModal={(v) => {
                  setSelectedVehicleForEdit(v);
                  setVehicleModalOpen(true);
                }}
                onOpenNewVehicleForSeller={(sellerId) => {
                  setSelectedVehicleForEdit(null);
                  setVehicleModalOpen(true);
                }}
              />
            )}

            {currentTab === 'margins' && (
              <MarginsView
                vehicles={vehicles}
                stats={stats}
                onOpenVehicleModal={(v) => {
                  setSelectedVehicleForEdit(v);
                  setVehicleModalOpen(true);
                }}
                onOpenSendEmail={handleOpenSendEmail}
              />
            )}

            {currentTab === 'team' && (
              <UsersView
                users={users}
                currentUser={currentUser}
                onAddUser={handleAddUser}
                onUpdateUser={handleUpdateUser}
                onDeleteUser={handleDeleteUser}
                onSwitchUser={(u) => {
                  setCurrentUser({
                    name: u.name,
                    role: u.role,
                    email: u.email
                  });
                  showToast(`Session active changée pour : ${u.name}`);
                }}
              />
            )}
          </>
        )}
      </main>

      {/* Global Modals */}
      {vehicleModalOpen && (
        <VehicleModal
          isOpen={vehicleModalOpen}
          vehicle={selectedVehicleForEdit}
          onClose={() => {
            setVehicleModalOpen(false);
            setSelectedVehicleForEdit(null);
          }}
          onSave={handleSaveVehicle}
          onOpenSendEmail={handleOpenSendEmail}
          sellers={sellers}
          onQuickAddSeller={handleAddSeller}
          onOpenSalesMandate={(v) => setSalesMandateVehicle(v)}
        />
      )}

      {/* Fiche Véhicule Détaillée (État de la Vente, Marges & Coûts) */}
      {detailSheetVehicle && (
        <VehicleDetailSheetModal
          vehicle={detailSheetVehicle}
          onClose={() => setDetailSheetVehicle(null)}
          onOpenEdit={(v) => {
            setDetailSheetVehicle(null);
            setSelectedVehicleForEdit(v);
            setVehicleModalOpen(true);
          }}
          onOpenShowcase={(v) => {
            setDetailSheetVehicle(null);
            setShowVehicle(v);
          }}
          onOpenReservation={(v) => {
            setDetailSheetVehicle(null);
            setReservationVehicle(v);
          }}
          onOpenSalesMandate={(v) => {
            setDetailSheetVehicle(null);
            setSalesMandateVehicle(v);
          }}
          onOpenWindowSticker={(v) => {
            setDetailSheetVehicle(null);
            setWindowStickerVehicle(v);
          }}
          onOpenBrochure={(v) => {
            setDetailSheetVehicle(null);
            setBrochureVehicle(v);
          }}
          onOpenSendEmail={handleOpenSendEmail}
        />
      )}

      {/* Mode Présentation Client / Show Modal */}
      {showVehicle && (
        <VehicleShowModal
          vehicle={showVehicle}
          onClose={() => setShowVehicle(null)}
          onOpenReservation={(v) => {
            setShowVehicle(null);
            setReservationVehicle(v);
          }}
          onOpenEdit={(v) => {
            setShowVehicle(null);
            setSelectedVehicleForEdit(v);
            setVehicleModalOpen(true);
          }}
          onOpenWindowSticker={(v) => {
            setShowVehicle(null);
            setWindowStickerVehicle(v);
          }}
          onOpenBrochure={(v) => {
            setShowVehicle(null);
            setBrochureVehicle(v);
          }}
        />
      )}

      {/* Reservation & Order Form Modals */}
      {reservationVehicle && (
        <ReservationModal
          vehicle={reservationVehicle}
          onClose={() => setReservationVehicle(null)}
          onConfirmReservation={handleConfirmReservation}
        />
      )}

      {orderFormVehicle && (
        <OrderFormModal
          vehicle={orderFormVehicle}
          reservation={orderFormVehicle.reservation}
          onClose={() => setOrderFormVehicle(null)}
        />
      )}

      {/* Mandat de Vente Modal (Dépôt-vente) */}
      {salesMandateVehicle && (
        <SalesMandateModal
          vehicle={salesMandateVehicle}
          seller={salesMandateVehicle.seller}
          onClose={() => setSalesMandateVehicle(null)}
          onSaveMandate={handleSaveSalesMandate}
        />
      )}

      {windowStickerVehicle && (
        <WindowStickerModal
          vehicle={windowStickerVehicle}
          onClose={() => setWindowStickerVehicle(null)}
        />
      )}

      {brochureVehicle && (
        <ClientBrochureModal
          vehicle={brochureVehicle}
          onClose={() => setBrochureVehicle(null)}
        />
      )}

      {aiAdVehicle && (
        <AiAdGeneratorModal
          vehicle={aiAdVehicle}
          onClose={() => setAiAdVehicle(null)}
          onSaveDescription={(vehicleId, desc) => {
            api.updateCar(vehicleId, { aiDescription: desc });
            setVehicles(prev => prev.map(v => v.id === vehicleId ? { ...v, aiDescription: desc } : v));
          }}
        />
      )}

      {mediaDamagesVehicle && (
        <VehicleMediaDamagesModal
          vehicle={mediaDamagesVehicle}
          isOpen={true}
          onClose={() => setMediaDamagesVehicle(null)}
          onUpdateVehicle={handleQuickUpdateVehicle}
        />
      )}

      {appointmentModalOpen && (
        <AppointmentModal
          isOpen={appointmentModalOpen}
          appointment={selectedAppointmentForEdit}
          vehicles={vehicles}
          onClose={() => {
            setAppointmentModalOpen(false);
            setSelectedAppointmentForEdit(null);
          }}
          onSave={handleSaveAppointment}
        />
      )}

      {sendEmailModalOpen && (
        <SendDocumentEmailModal
          isOpen={sendEmailModalOpen}
          onClose={() => {
            setSendEmailModalOpen(false);
            setSelectedVehicleForEmail(null);
          }}
          vehicles={vehicles}
          initialVehicle={selectedVehicleForEmail}
          initialDocType={initialDocTypeForEmail}
          sentEmails={emails}
          onSendEmail={handleSendEmail}
          onDeleteEmail={handleDeleteEmail}
        />
      )}

      {/* Quiet Footer */}
      <footer className="no-print mt-auto border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-300">PARKTBD</span>
            <span>· Logiciel de Contrôle de Stock & Négoce pour <strong className="text-amber-400">TBD AUTOS</strong></span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>Expéditeur : <strong className="font-mono text-slate-300">tbdautos@gmail.com</strong></span>
            <span>· Synchronisation temps réel multi-appareils</span>
            <span>· Conforme SIV & TVA sur marge</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
