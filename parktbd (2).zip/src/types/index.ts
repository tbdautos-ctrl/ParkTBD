export type DocumentStatus = 'complet' | 'en_attente' | 'manquant' | 'non_requis';

export type VehicleStatus = 
  | 'en_arrivage' 
  | 'en_preparation' 
  | 'en_stock' 
  | 'reserve' 
  | 'vendu' 
  | 'livre';

export type BusinessType = 'achat_revente' | 'depot_vente';

export type FuelType = 'Essence' | 'Diesel' | 'Hybride' | 'Hybride Rechargeable' | 'Électrique';

export type GearboxType = 'Automatique' | 'Manuelle';

export interface VehicleCosts {
  purchasePrice: number;       // Prix d'achat pour stock propre (achat-revente)
  transport: number;           // Convoyage / Transport
  reconditioning: number;      // Révision, vidange, freins, mécanique
  detailing: number;           // Carrosserie, débosselage, nettoyage pro
  inspection: number;          // Contrôle Technique
  adminFees: number;           // Frais de dossier, carte grise garage
  warrantyCost: number;        // Coût garantie commerciale souscrite (Opteven, etc.)
  customCosts: { label: string; amount: number }[];
}

export interface VehicleDocumentRecord {
  id: string;
  name: string;
  type: string;
  uploadDate: string;
  size: string;
  url?: string;
}

export type PhotoLocationTag = 
  | 'avant_3_4' 
  | 'arriere_3_4' 
  | 'profil' 
  | 'interieur_poste' 
  | 'sieges' 
  | 'compteur' 
  | 'moteur' 
  | 'coffre' 
  | 'jantes' 
  | 'autre';

export interface VehicleMediaItem {
  id: string;
  type: 'photo' | 'video';
  url: string;                 // URL ou DataURL
  title?: string;
  locationTag?: PhotoLocationTag; // Emplacement / angle de la photo sur le véhicule
  order?: number;              // Position ordonnée dans la galerie
  createdAt: string;
}

export type DocumentCategory = 
  | 'carte_grise' 
  | 'non_gage' 
  | 'cession' 
  | 'ct' 
  | 'mandat' 
  | 'facture' 
  | 'autre';

export interface VehicleDocumentFile {
  id: string;
  name: string;
  type: string;                // 'application/pdf', 'image/jpeg', 'image/png'
  category: DocumentCategory;
  url: string;                 // URL ou DataURL base64 pour affichage / téléchargement
  uploadDate: string;
  size: string;
  notes?: string;
}

export interface VehicleDamageItem {
  id: string;
  title: string;               // ex: "Rayure aile arrière droite", "Jante avant frottée"
  location: string;            // ex: "Aile ARD", "Jante AVD", "Pare-brise"
  severity: 'mineur' | 'moyen' | 'important';
  mediaUrl?: string;           // Photo ou vidéo du dommage
  mediaType?: 'photo' | 'video';
  estimatedRepairCost: number; // Coût estimé de réparation (€)
  repaired: boolean;           // true si réparé en carrosserie, false si vendu en l'état
  notes?: string;
  createdAt: string;
}

export interface AdministrativeDocuments {
  carteGrise: DocumentStatus;
  certificatCession: DocumentStatus;
  certificatNonGage: DocumentStatus;
  controleTechnique: DocumentStatus;
  bonCommande: DocumentStatus;
  factureAchat: DocumentStatus;
  factureVente: DocumentStatus;
  mandatVente: DocumentStatus;       // Obligatoire pour dépôt-vente
  doubleDesCles: boolean;
  carnetEntretien: boolean;
  notes?: string;
  files: VehicleDocumentRecord[];
}

export interface Vehicle {
  id: string;
  vin: string;
  registration: string;              // Immatriculation ex: "AB-123-CD"
  brand: string;                     // ex: Audi, Porsche, Peugeot
  model: string;                     // ex: RS3, Macan, 3008
  version: string;                   // ex: "2.5 TFSI 400 Quattro S tronic 7"
  year: number;
  firstRegistrationDate: string;     // YYYY-MM-DD
  mileage: number;                   // km
  fuel: FuelType;
  gearbox: GearboxType;
  powerDin: number;                  // ch
  powerFiscal: number;               // CV fiscaux
  co2?: number;                      // g/km
  critAir: number;                   // 0, 1, 2, 3...
  colorExterior: string;
  colorInterior: string;
  doors: number;
  seats: number;

  businessType: BusinessType;
  sellerId?: string;                 // Référence au vendeur déposant (si dépôt-vente)
  seller?: Seller;                   // Fiche vendeur associée (informations, CNI, KBIS)
  sellerDesiredPrice?: number;       // Montant net souhaité par le client vendeur (si dépôt-vente)
  status: VehicleStatus;
  location: string;                  // ex: "Showroom Principal", "Emplacement A12"

  // Financials
  costs: VehicleCosts;
  sellingPrice: number;              // Prix de vente TTC affiché
  brokerageFee?: number;             // Commission si dépôt-vente
  tvaRegime: 'marge' | 'standard';   // Régime TVA sur marge ou TVA normale
  tvaRate: number;                   // Taux de TVA fisc français : 20, 10, 8.5, 5.5, 2.1, 0 (défaut 20%)
  monthlyEstimate: number;           // ex: 429€ / mois en LOA/crédit

  // Commercial attributes & Warranties
  guarantee: string;                 // Libellé commercial de la garantie
  warrantyInitialMonths: number;     // Durée garantie commerciale initiale : 1 à 12 mois
  warrantyExtensionMonths: number;   // Supplément extension de garantie : 0 ou 4 à 36 mois
  warrantyExtensionCost?: number;    // Coût du supplément d'extension
  warrantyProvider?: string;         // Prestataire (Opteven, Cirano, TBD Garantie, etc.)
  keyOptions: string[];              // 4-6 options mises en valeur
  detailedEquipment: { category: string; items: string[] }[];
  history: {
    origin: string;                  // ex: "Origine France", "Première main concession"
    firstOwner: boolean;
    serviceBookComplete: boolean;
    lastServiceDate?: string;
    lastServiceKm?: number;
  };

  // Administration & Media
  documents: AdministrativeDocuments;
  images: string[];
  mediaItems?: VehicleMediaItem[];           // Photos & vidéos du véhicule
  documentFiles?: VehicleDocumentFile[];     // Documents scannés / uploadés
  damages?: VehicleDamageItem[];             // Dommages & état des lieux carrosserie

  aiDescription?: string;

  // Reservation details & Bon de commande
  reservation?: ReservationBuyerInfo;

  // Mandat de vente automobile (Dépôt-vente)
  salesMandate?: SalesMandateInfo;

  entryDate: string;                 // Date d'entrée en stock
  saleDate?: string;
  soldPrice?: number;
  buyerName?: string;
  buyerPhone?: string;
  createdAt: string;
  updatedAt: string;
}

export type BuyerType = 'particulier' | 'professionnel';

export interface ReservationBuyerInfo {
  buyerType: BuyerType;
  name: string;                   // Nom / Raison Sociale
  firstName?: string;             // Prénom (si particulier)
  sirenSiret?: string;            // N° SIREN / SIRET (si pro)
  phone: string;
  email: string;
  address: string;
  postalCodeCity: string;
  orderNumber: string;            // ex: "BDC-2026-0042"
  orderDate: string;              // Date du bon de commande (YYYY-MM-DD)
  deliveryDeadlineDate?: string;  // Date limite de livraison

  // Détail financier bon de commande
  vehiclePriceTTC: number;        // Prix de vente du véhicule d'occasion TTC
  adminPrepFees: number;          // Frais de dossier / Préparation véhicule (€ TTC)
  regFeesCarteGrise: number;      // Frais d'immatriculation / Carte Grise estimation (€ TTC)
  totalPriceToPayTTC: number;     // PRIX TOTAL A PAYER TTC
  depositAmount: number;          // Acompte versé à la commande (€)
  depositDate: string;            // Date du versement de l'acompte
  depositPaymentMethod: 'virement' | 'cheque_banque' | 'carte_bancaire' | 'especes';
  balanceRemaining: number;       // SOLDE RESTANT À PAYER À LA LIVRAISON
  deliveryPackChosen?: 'aucun' | 'pack_1' | 'pack_2';
}

export interface SalesMandateInfo {
  mandantType: 'particulier' | 'professionnel';
  mandantName: string;
  mandantFirstName?: string;
  sirenSiret?: string;
  representedBy?: string;
  address: string;
  postalCodeCity: string;
  phone: string;
  email: string;
  idDocNumber?: string;
  idDocDeliveredDateBy?: string;
  netSellerPrice: number;
  ctStatus: 'moins_6_mois' | 'a_effectuer_mandant' | 'a_effectuer_mandataire';
  carteGriseFormulaNumber?: string;
  doubleKeys: boolean;
  contractDurationDays: number;   // 30 jours ferme par défaut
  signatureDate: string;
  signaturePlace: string;
}

export type AppointmentType = 
  | 'essai_routier' 
  | 'visite_commerciale' 
  | 'livraison' 
  | 'expertise_reprise';

export type AppointmentStatus = 'confirme' | 'en_attente' | 'effectue' | 'annule';

export interface Appointment {
  id: string;
  vehicleId: string;
  vehicleName: string;
  clientName: string;
  clientPhone: string;
  clientEmail: string;
  type: AppointmentType;
  date: string;                      // ISO string or YYYY-MM-DDTHH:mm
  durationMinutes: number;
  status: AppointmentStatus;
  driverLicenseChecked: boolean;
  depositLeft: boolean;
  notes: string;
  assignedTo: string;
  createdAt: string;
}

export type UserRole = 'admin' | 'commercial' | 'gestionnaire_parc' | 'comptable';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  active: boolean;
  createdAt: string;
}

export interface FinancialStats {
  totalCarsInStock: number;
  totalStockValueTTC: number;
  totalCostInvested: number;
  potentialGrossMargin: number;
  potentialNetMargin: number;
  averageMarginPercentage: number;
  averageStockDays: number;
  carsSoldMonth: number;
  realizedMarginMonth: number;
  statusBreakdown: Record<VehicleStatus, number>;
  businessTypeBreakdown: Record<BusinessType, number>;
}

export type EmailDocType = 
  | 'facture_achat' 
  | 'facture_vente' 
  | 'dossier_administratif' 
  | 'mandat_depot_vente' 
  | 'fiche_technique_brochure' 
  | 'certificat_non_gage' 
  | 'autre';

export interface SentEmailRecord {
  id: string;
  from: string;               // 'tbdautos@gmail.com'
  fromName: string;           // 'TBD AUTOS'
  to: string;
  recipientName: string;
  vehicleId?: string;
  vehicleName?: string;
  docType: EmailDocType;
  subject: string;
  message: string;
  attachments: { name: string; size?: string; url?: string }[];
  sentAt: string;
  status: 'envoye' | 'erreur';
}

export type SellerType = 'particulier' | 'professionnel';

export interface SellerDocumentRecord {
  name: string;
  type: string;
  uploadDate: string;
  size: string;
  url?: string;
}

export interface Seller {
  id: string;
  type: SellerType;
  name: string;
  companyName?: string;
  siren?: string;
  siret?: string;
  managerName?: string;
  phone: string;
  email: string;
  address: string;
  postalCode?: string;
  city?: string;
  idDocumentType?: 'cni' | 'passeport' | 'titre_sejour' | 'kbis' | 'statuts';
  idDocumentNumber?: string;
  idDocumentFile?: SellerDocumentRecord;
  kbisFile?: SellerDocumentRecord;
  rib?: string;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

