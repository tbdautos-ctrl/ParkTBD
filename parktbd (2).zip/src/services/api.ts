import { Vehicle, Appointment, UserAccount, SentEmailRecord, Seller } from '../types';

export const api = {
  async getCars(): Promise<Vehicle[]> {
    try {
      const res = await fetch('/api/cars');
      if (!res.ok) throw new Error('Erreur réseau');
      return await res.json();
    } catch (err) {
      console.warn('Fallback local pour getCars', err);
      const local = localStorage.getItem('parktbd_cars');
      return local ? JSON.parse(local) : [];
    }
  },

  async createCar(car: Partial<Vehicle>): Promise<Vehicle> {
    const res = await fetch('/api/cars', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(car),
    });
    if (!res.ok) throw new Error('Erreur création véhicule');
    return await res.json();
  },

  async updateCar(id: string, car: Partial<Vehicle>): Promise<Vehicle> {
    const res = await fetch(`/api/cars/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(car),
    });
    if (!res.ok) throw new Error('Erreur mise à jour véhicule');
    return await res.json();
  },

  async deleteCar(id: string): Promise<boolean> {
    const res = await fetch(`/api/cars/${id}`, { method: 'DELETE' });
    return res.ok;
  },

  async getAppointments(): Promise<Appointment[]> {
    try {
      const res = await fetch('/api/appointments');
      if (!res.ok) throw new Error('Erreur réseau');
      return await res.json();
    } catch (err) {
      console.warn('Fallback local pour appointments', err);
      const local = localStorage.getItem('parktbd_appointments');
      return local ? JSON.parse(local) : [];
    }
  },

  async createAppointment(apt: Partial<Appointment>): Promise<Appointment> {
    const res = await fetch('/api/appointments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(apt),
    });
    if (!res.ok) throw new Error('Erreur création rendez-vous');
    return await res.json();
  },

  async updateAppointment(id: string, apt: Partial<Appointment>): Promise<Appointment> {
    const res = await fetch(`/api/appointments/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(apt),
    });
    if (!res.ok) throw new Error('Erreur mise à jour rendez-vous');
    return await res.json();
  },

  async deleteAppointment(id: string): Promise<boolean> {
    const res = await fetch(`/api/appointments/${id}`, { method: 'DELETE' });
    return res.ok;
  },

  async getUsers(): Promise<UserAccount[]> {
    try {
      const res = await fetch('/api/users');
      if (!res.ok) throw new Error('Erreur réseau');
      return await res.json();
    } catch (err) {
      console.warn('Fallback local pour users', err);
      const local = localStorage.getItem('parktbd_users');
      return local ? JSON.parse(local) : [];
    }
  },

  async createUser(user: Partial<UserAccount>): Promise<UserAccount> {
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user),
    });
    if (!res.ok) throw new Error('Erreur création utilisateur');
    return await res.json();
  },

  async updateUser(id: string, user: Partial<UserAccount>): Promise<UserAccount> {
    const res = await fetch(`/api/users/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user),
    });
    if (!res.ok) throw new Error('Erreur mise à jour utilisateur');
    return await res.json();
  },

  async deleteUser(id: string): Promise<boolean> {
    const res = await fetch(`/api/users/${id}`, { method: 'DELETE' });
    return res.ok;
  },

  async getEmails(): Promise<SentEmailRecord[]> {
    try {
      const res = await fetch('/api/emails');
      if (!res.ok) throw new Error('Erreur réseau');
      return await res.json();
    } catch (err) {
      console.warn('Fallback local pour emails', err);
      const local = localStorage.getItem('parktbd_emails');
      return local ? JSON.parse(local) : [];
    }
  },

  async sendEmail(email: Partial<SentEmailRecord>): Promise<SentEmailRecord> {
    const res = await fetch('/api/emails', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(email),
    });
    if (!res.ok) throw new Error('Erreur lors de l\'enregistrement de l\'envoi');
    return await res.json();
  },

  async deleteEmail(id: string): Promise<boolean> {
    const res = await fetch(`/api/emails/${id}`, { method: 'DELETE' });
    return res.ok;
  },

  async getSellers(): Promise<Seller[]> {
    try {
      const res = await fetch('/api/sellers');
      if (!res.ok) throw new Error('Erreur réseau');
      return await res.json();
    } catch (err) {
      console.warn('Fallback local pour vendeurs', err);
      const local = localStorage.getItem('parktbd_sellers');
      return local ? JSON.parse(local) : [];
    }
  },

  async createSeller(seller: Partial<Seller>): Promise<Seller> {
    const res = await fetch('/api/sellers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(seller),
    });
    if (!res.ok) throw new Error('Erreur lors de la création du vendeur');
    return await res.json();
  },

  async updateSeller(id: string, seller: Partial<Seller>): Promise<Seller> {
    const res = await fetch(`/api/sellers/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(seller),
    });
    if (!res.ok) throw new Error('Erreur lors de la modification du vendeur');
    return await res.json();
  },

  async deleteSeller(id: string): Promise<boolean> {
    const res = await fetch(`/api/sellers/${id}`, { method: 'DELETE' });
    return res.ok;
  },

  async generateAiAd(vehicle: Vehicle, platform: string, tone: string): Promise<{ text: string; provider: string }> {
    const res = await fetch('/api/generate-description', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ vehicle, platform, tone }),
    });
    if (!res.ok) throw new Error('Erreur lors de la génération de l\'annonce');
    return await res.json();
  },

  async resetDemo(): Promise<void> {
    await fetch('/api/reset-demo', { method: 'POST' });
  }
};
